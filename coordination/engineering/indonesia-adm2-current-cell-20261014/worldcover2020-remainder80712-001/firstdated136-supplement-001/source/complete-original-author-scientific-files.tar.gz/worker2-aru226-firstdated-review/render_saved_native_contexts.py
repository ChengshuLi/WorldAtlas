from pathlib import Path
import json,gzip,math,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from functools import lru_cache
ROOT=Path('/Users/chengshuli/Documents/Codex/2026-10-14/task');BASE=ROOT/'idn-physical-dated778-plan-001/worker6-metadata';RAW=BASE/'first-raw-native-observation-001';OUT=ROOT/'idn-physical-dated778-plan-001/worker2-aru226-firstdated-review';(OUT/'views').mkdir(exist_ok=True)
rows=[]
for p in RAW.glob('*/point-observations.jsonl'):
 rows +=[json.loads(l)for l in p.read_text().splitlines()if json.loads(l)['original_key']['owner']==22734]
rows.sort(key=lambda r:r['point_index']);assert len(rows)==226
@lru_cache(maxsize=24)
def block(item,band,br,bc):
 p=RAW/item/band/f'block-{br:02}-{bc:02}.npz'
 if not p.exists():return None
 with np.load(p)as z:return z['values'],z['mask']
def crop(r,band):
 x,y,w,h=r['planned_native_context'][band]['actual_available_context_window'];bh,bw=r['assets'][band]['actual_header']['block_shapes'][0];val=np.zeros((h,w),np.uint16);mask=np.zeros((h,w),np.uint8)
 for br in range(y//bh,(y+h-1)//bh+1):
  for bc in range(x//bw,(x+w-1)//bw+1):
   b=block(r['item_id'],band,br,bc)
   if b is None:continue
   a,m=b;by,bx=br*bh,bc*bw;ya,yb=max(y,by),min(y+h,by+a.shape[0]);xa,xb=max(x,bx),min(x+w,bx+a.shape[1]);val[ya-y:yb-y,xa-x:xb-x]=a[ya-by:yb-by,xa-bx:xb-bx];mask[ya-y:yb-y,xa-x:xb-x]=m[ya-by:yb-by,xa-bx:xb-bx]
 return val,mask
colors=np.array([[0,0,0],[255,0,0],[50,50,50],[110,70,40],[30,145,35],[205,170,75],[35,70,200],[150,150,150],[210,210,210],[255,255,255],[100,230,255],[250,130,230]],np.uint8)
def mark(im,r,band,scale):
 d=ImageDraw.Draw(im);fr,fc=r['assets'][band]['native_fractional_pixel'];x,y,_,_=r['planned_native_context'][band]['actual_available_context_window'];cx=(fc-x)*scale;cy=(fr-y)*scale
 # Open fractional marker: centre remains unobscured, no pixel recentering.
 for color,width in [('black',3),('yellow',1)]:
  for ax,ay,bx,by in [(-8,0,-3,0),(3,0,8,0),(0,-8,0,-3),(0,3,0,8)]:d.line((cx+ax,cy+ay,cx+bx,cy+by),fill=color,width=width)
 return im
views=[]
for index,r in enumerate(rows):
 assert r['processing_baseline']=='02.13'and not r['normalization_contract_unchanged']['PB05_metadata_contradiction_retained']
 v={};m={}
 for band in ['red','green','blue','nir','scl']:v[band],m[band]=crop(r,band)
 def rgb(bands):
  raw=np.stack([v[k]for k in bands],axis=-1);reflectance=raw.astype(float)*0.0001 # single metadata scale, offset0
  px=np.uint8(np.round(np.clip(reflectance/0.30,0,1)**(1/2.2)*255));valid=np.all(np.stack([m[k]>0 for k in bands]),axis=0);px[~valid]=[255,0,255];return mark(Image.fromarray(px).resize((98,98),Image.Resampling.NEAREST),r,'red',2)
 scl=colors[np.clip(v['scl'],0,11)];scl[m['scl']==0]=[255,0,255];scl=mark(Image.fromarray(scl).resize((100,100),Image.Resampling.NEAREST),r,'scl',4)
 card=Image.new('RGB',(336,152),'#eeeeee');draw=ImageDraw.Draw(card);key=r['original_key'];draw.text((3,2),f"{index:03} p{r['point_index']} {key['y']}/{key['x']}",fill='black');draw.text((3,15),f"{r['acquisition_datetime'][:10]} SCL{r['assets']['scl']['raw_value']} DN {r['assets']['red']['raw_value']}/{r['assets']['nir']['raw_value']}",fill='black')
 card.paste(rgb(['red','green','blue']),(3,42));card.paste(rgb(['nir','red','green']),(111,42));card.paste(scl,(222,42));draw.text((3,29),'RGB10m       NIR/R/G10m      SCL20m',fill='black')
 views.append(card)
 record={'review_index':index,'point_index':r['point_index'],'original_key':key,'item_id':r['item_id'],'acquisition_datetime':r['acquisition_datetime'],'processing_baseline':r['processing_baseline'],'RGB_and_NIR_display':'PB02declaredreflectance=rawDN*0.0001+0 exactlyonce;fixed0..0.30displayclip,gamma1/2.2;nearestpixel enlargement;notclassification','fractional_marker':'actualfractionalpixelrelativeintegerwindow,openmarkercentreunobscured;notrecentered','raw_assets':r['assets']}
 (OUT/f'point-{index:03}-observation.json').write_text(json.dumps(record,separators=(',',':'))+'\n')
for start in range(0,len(rows),16):
 page=Image.new('RGB',(1344,4*152+35),'white');d=ImageDraw.Draw(page);d.text((8,5),'Aru226 actual first-date contexts | RGB49x49 10m / NIR-R-G49x49 10m / SCL25x25 20m | magenta=missing mask | no automatic SCL class',fill='black')
 for j,c in enumerate(views[start:start+16]):page.paste(c,((j%4)*336,35+(j//4)*152))
 page.save(OUT/'views'/f'aru226-native-context-{start//16+1:02}.png')
(OUT/'ordered226-original-observations.jsonl').write_text(''.join(json.dumps(r,separators=(',',':'))+'\n'for r in rows));(OUT/'view-inventory.json').write_text(json.dumps({'scope':226,'processing_baseline_counts':{'02.13':226},'PB05_points':0,'pages':[str(p.relative_to(OUT))for p in sorted((OUT/'views').glob('*.png'))],'renderer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'no_remote_or_new_geometry_or_native_calls':True},separators=(',',':'))+'\n');print('rendered',len(views),'points',math.ceil(len(views)/16),'pages')
