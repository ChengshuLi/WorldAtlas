from pathlib import Path
p=Path('/Users/chengshuli/Documents/Codex/2026-10-14/task/idn-physical-dated778-plan-001/worker2-aru226-firstdated-review/render_saved_native_contexts.py')
exec(p.read_text().split('views=[]')[0])
indices=[8,11,12,15,16,17,18,21,25,27,28,29,30,33,35,37,39,42,49,51,53,57,58,59,64,65,68,69,70,72,77,78,79,83,85,86,89,92,93,96,97,98,99,100,101,105,111,114,117,125,127,129,131,133,136,140,144,145,146,147,149,151,154,155,158,159,160,161,162,163,164,165,167,169,172,173,174,175,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,194,195,198,199,200,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225]
cards=[]
for i in indices:
 r=rows[i];v={b:crop(r,b)[0]for b in ['red','green','blue','nir']};card=Image.new('RGB',(620,205),'#eeeeee');d=ImageDraw.Draw(card);d.text((3,2),f"{i} p{r['point_index']} {r['original_key']} RGB / NIR-R-G / RGB9 / NIR9",fill='black')
 for k,bands in enumerate([['red','green','blue'],['nir','red','green']]):
  raw=np.stack([v[b]for b in bands],axis=-1);px=np.uint8(np.round(np.clip(raw.astype(float)*0.0001/0.30,0,1)**(1/2.2)*255));im=mark(Image.fromarray(px).resize((196,196),Image.Resampling.NEAREST),r,'red',4);card.paste(im,(k*200,18))
  fr,fc=r['assets']['red']['native_fractional_pixel'];x,y,_,_=r['planned_native_context']['red']['actual_available_context_window'];cr,cc=math.floor(fr)-y,math.floor(fc)-x;small=Image.fromarray(px[cr-4:cr+5,cc-4:cc+5]).resize((144,144),Image.Resampling.NEAREST);sd=ImageDraw.Draw(small)
  for j in range(0,145,16):sd.line((j,0,j,144),fill='#808080');sd.line((0,j,144,j),fill='#808080')
  cx=(4+fc-math.floor(fc))*16;cy=(4+fr-math.floor(fr))*16
  for color,width in [('black',3),('yellow',1)]:
   for a,b,c,e in [(-7,0,-2,0),(2,0,7,0),(0,-7,0,-2),(0,2,0,7)]:sd.line((cx+a,cy+b,cx+c,cy+e),fill=color,width=width)
  card.paste(small,(405+k*0,22+k*84)) if False else None
  # two central panels each96x96 (nativepixels10.667 display); keep full144 separate stack at right
  small=small.resize((96,96),Image.Resampling.NEAREST);card.paste(small,(405+k*104,70))
 cards.append(card)
(OUT/'zoom').mkdir(exist_ok=True)
for s in range(0,len(cards),8):
 im=Image.new('RGB',(1240,820),'white')
 for j,c in enumerate(cards[s:s+8]):im.paste(c,((j%2)*620,(j//2)*205))
 im.save(OUT/'zoom'/f'candidate-{s//8+1:02}.png')
print('zoom',len(indices),'candidates',math.ceil(len(cards)/8),'pages')
