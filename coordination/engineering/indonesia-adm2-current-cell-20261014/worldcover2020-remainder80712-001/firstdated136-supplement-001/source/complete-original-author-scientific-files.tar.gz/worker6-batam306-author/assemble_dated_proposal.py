"""Bind existing manual interpretations to saved records; no source/raster access."""
import collections
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/chengshuli/Documents/Codex/2026-10-14/task')
OUT = ROOT / 'idn-physical-dated778-plan-001/worker6-batam306-author'
SOURCE = ROOT / 'idn-physical-dated778-plan-001/worker6-metadata'

def pin(path):
    b = path.read_bytes()
    return {'file': str(path.relative_to(ROOT)), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def load_lines(path):
    op = gzip.open if path.suffix == '.gz' else open
    with op(path, 'rt') as f:
        return [json.loads(l) for l in f]

def key(r):
    k = r['original_key']
    return (k['owner'], k['y'], k['x'])

def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def write_gz(name, records):
    raw = b''.join((json.dumps(r, ensure_ascii=False, separators=(',', ':'))+'\n').encode() for r in records)
    with (OUT / name).open('wb') as f:
        with gzip.GzipFile(fileobj=f, mode='wb', filename='', mtime=0) as z:
            z.write(raw)
    return dict(pin(OUT / name), decoded_bytes=len(raw), decoded_sha256=hashlib.sha256(raw).hexdigest())

inventory_file = SOURCE / 'exact778-original-source-coordinate-current-reason.jsonl.gz'
inventory = {key(r): r for r in load_lines(inventory_file) if r['original_key']['owner'] == 22727}
assert len(inventory) == 306
annual_file = ROOT / 'idn-physical-largest-residuals-001/worker1-source/batam1486-followup-proposal-001/proposed-batam1486-dispositions.jsonl.gz'
annual = {key(r): r for r in load_lines(annual_file) if key(r) in inventory}
assert set(annual) == set(inventory)
assert all(not r['proposed_bounded_answer'] for r in annual.values())
raw = {}
raw_files = {}
for p in sorted((SOURCE / 'first-raw-native-observation-001').glob('*/point-observations.jsonl')):
    rs = load_lines(p)
    relevant = [r for r in rs if key(r) in inventory]
    if relevant:
        pp = pin(p)
        for line, r in enumerate(rs, 1):
            if key(r) in inventory:
                assert key(r) not in raw
                raw[key(r)] = r
                raw_files[key(r)] = dict(pp, line_1based=line)
assert set(raw) == set(inventory)

wide = {}
all_view_pins = []
inventories = []
for sub in ['native-centre-review', 'native-rawDN-PB05-review', 'native-detail-review']:
    p = OUT / sub / 'contact-inventory.json'
    d = json.loads(p.read_text())
    inventories.append(pin(p))
    for page in d['pages']:
        png = OUT / page['file']
        actual = pin(png)
        assert actual['bytes'] == page['bytes'] and actual['sha256'] == page['sha256']
        all_view_pins.append(actual)
        for panel in page['panels']:
            view = {'file': str(png.relative_to(ROOT)), 'bytes': actual['bytes'], 'sha256': actual['sha256'],
                    'page_1based': page['page_1based'], 'panel_1based': panel['panel_1based'], 'native_panel_metadata_unchanged': panel}
            if sub != 'native-detail-review':
                assert panel['point_index'] not in wide
                wide[panel['point_index']] = view
            else:
                pass
detail_inv = json.loads((OUT/'native-detail-review/contact-inventory.json').read_text())
detail = {}
for page in detail_inv['pages']:
    for panel in page['panels']:
        detail[panel['point_index']] = {'file': str((OUT/page['file']).relative_to(ROOT)), 'sha256':page['sha256'],
                                      'page_1based':page['page_1based'], 'panel_1based':panel['panel_1based'],
                                      'native_panel_metadata_unchanged':panel}
manual_file = OUT/'manual-final-dated-centre-decisions.json'
manual = json.loads(manual_file.read_text())['decisions']
assert len(wide)==306 and len(detail)==len(manual)==109
assert set(map(int,manual))==set(detail)
held = load_lines(ROOT/'idn-physical-residual41305-policy-001/worker6-untouched9393-assessment/prospective-specific-residual778-owner-y-x.jsonl.gz')
held_keys = set(map(tuple, held))
assert len(held_keys)==778 and set(inventory)<=held_keys

meaning = {
 'V': ('dated-visible-vegetation-canopy-body', 'a coherent visible vegetation/canopy body', 'Visible canopy does not establish dry ground or understorey, wetland status, plant species, or whole-cell land.'),
 'W': ('dated-visible-water-body', 'a visibly coherent water body', 'Visible water does not establish persistence, depth, water kind, a named river, bank/thalweg, tide, title, or whole-cell water.'),
 'L': ('dated-visible-exposed-constructed-body', 'a visible exposed or constructed surface patch', 'The visible exposed/constructed patch does not identify material, tidal dryness, building use, or whole-cell/native binary LAND.'),
 'A': ('dated-exact-centre-body-unresolved', None, 'The dated source does not support a reliable exact-centre body assignment; no annual fallback is used.')}
rows=[]
for k in sorted(inventory):
    inv=inventory[k]; a=annual[k]; r=raw[k]; idx=r['point_index']
    assert inv['original_point_index']==a['point_index']==idx
    assert inv['centre_unchanged']==a['centre_unchanged']==r['centre_unchanged']
    assert inv['source_native_association']==a['source_native_association']
    assert inv['original_record_unchanged']==a['original_record_unchanged']
    assert wide[idx]['native_panel_metadata_unchanged']['original_key']==r['original_key']
    assert all(r['assets'][b]['native_valid_mask']==255 and not r['assets'][b]['nodata_match'] for b in ['red','green','blue','nir'])
    d=manual.get(str(idx), {'label':'A', 'reason':'Actual wide RGB and false-colour context remains cloud/haze obscured or locally low-contrast at the marked centre; a coherent ground, canopy or water placement is not sufficiently resolved.'})
    label=d['label']; positive=label!='A'; cat,body,limit=meaning[label]
    if positive: assert idx in detail
    pb05=r['normalization_contract_unchanged']['PB05_metadata_contradiction_retained']
    answer=None
    if positive:
        answer={'dated_visible_body': 'At the unchanged marked centre, the '+r['acquisition_datetime']+' acquisition supports '+body+'.',
                'source_version_location': 'This unchanged coordinate retains the original source-version candidate/member association with '+inv['source_native_association']['original_ADM2_claim']['name']+'; this is not a new jurisdiction, current owner, or selected geographic portion finding.',
                'actual_geographic_placement_reason':d['reason']}
    rows.append({'original_key':r['original_key'], 'point_index':idx, 'centre_unchanged':r['centre_unchanged'],
       'original_record_unchanged':inv['original_record_unchanged'], 'source_native_association':inv['source_native_association'],
       'original_annual_held_scientific_record_unchanged':a, 'original_held_inventory_record_unchanged':inv,
       'actual_first_dated_raw_observation_unchanged':r, 'actual_dated_source_record_locator':raw_files[k],
       'proposed_bounded_answer':positive, 'manual_label':label, 'category':cat, 'actual_answer':answer,
       'actual_geographic_interpretation':d['reason'], 'remaining_physical_question':None if positive else d['reason'],
       'wide_actual_centre_view':wide[idx], 'detail_actual_centre_view':detail.get(idx),
       'display_and_radiometric_limits':{'PB05_absolute_radiometric_hold_retained':pb05,
         'display_contract':'Fixed uncalibrated RAW-DN RGB/FCC only; no gain, offset, absolute BOA units, indices or spectral threshold.' if pb05 else 'Declared PB02 reflectance=rawDN*0.0001 with offset0 exactly once, fixed display ranges; no classifier.',
         'quantitative_radiometry_claim':False, 'SCL_or_masks_used_as_automatic_body_truth':False},
       'separate_unadopted_questions':[limit, 'Finite native10m source support and local registration/mixed-edge uncertainty remain; this is a dated appearance at the marked coordinate, not a survey precision statement.',
          'The original selected geographic portion, parent, other source claims, jurisdiction and ownership holds remain literal and unchanged. No selected-footprint inclusion is established.',
          'No annual persistence, current surface, legal title, exact tide, binary native authority, accepted repair, or whole-cell closure is inferred.'],
       'original_holds_changed':False, 'annual_held_record_reinterpreted_or_overwritten':False,
       'credit_scope':'proposed bounded first-dated visible body plus original source-version association only',
       'completed_question_credit_proposed':1 if positive else 0, 'formal_broader_original_question_closure':False,
       'root_adoption':None, 'authority_or_repair_credit':0})
assert len(rows)==306 and len({key(r) for r in rows})==306
counts=collections.Counter(r['manual_label'] for r in rows)
assert counts=={'V':58,'W':9,'L':3,'A':236},counts
positive=[list(key(r)) for r in rows if r['proposed_bounded_answer']]
unknown=[list(key(r)) for r in rows if not r['proposed_bounded_answer']]
assert len(positive)==70 and len(unknown)==236 and not set(map(tuple,positive))&set(map(tuple,unknown))
proposal=write_gz('proposed-batam306-firstdated-body-location-dispositions.jsonl.gz',rows)
pospin=write_gz('proposed-answer70-owner-y-x.jsonl.gz',positive)
unkpin=write_gz('remaining-unknown236-owner-y-x.jsonl.gz',unknown)
summary={'status':'author-proposal-awaiting-distinct-scientific-review-and-Root-adoption', 'scope':306,
 'original_owner':22727, 'acquisition_date':'2020-01-01', 'manual_label_counts':dict(counts),
 'proposed_bounded_answers':70,'actual_unknowns_retained':236,'actual_wide_pages_viewed':13,'actual_close_pages_viewed':10,
 'all70positive_centres_have_actual_close_view':True,'no_SCL_mask_spectral_majority_or_annual_fallback_classifier':True,
 'PB05':{'scope':93,'qualitative_only_proposed_vegetation':5,'unknown':88,'absolute_radiometric_holds_retained':93,
         'proposed_point_indices':[r['point_index'] for r in rows if r['proposed_bounded_answer'] and r['display_and_radiometric_limits']['PB05_absolute_radiometric_hold_retained']]},
 'PB02':{'scope':213,'proposed':65,'unknown':148}, 'proposal':proposal,'proposed_exact_keys':pospin,'unknown_exact_keys':unkpin,
 'conservation':{'original_current_held_scope':778,'Batam306_subset':306,'other472_held_records_untouched':472,'70_plus236':306,
                 'subset_of_current_held778':True,'current_adopted133068_overlap':0,'global_running_adoption_count_not_changed':True},
 'source_inputs':[pin(inventory_file),pin(annual_file),pin(manual_file)]+list({r['file']:r for r in raw_files.values()}.values()),
 'views':all_view_pins,'view_inventories':inventories,'original_holds_changed':False,'adoption_performed':False,'authority_or_repair_credit':0}
write_json('batam306-firstdated-scientific-summary.json',summary)
print(json.dumps({'proposal':proposal,'counts':dict(counts),'PB05':summary['PB05']}))
