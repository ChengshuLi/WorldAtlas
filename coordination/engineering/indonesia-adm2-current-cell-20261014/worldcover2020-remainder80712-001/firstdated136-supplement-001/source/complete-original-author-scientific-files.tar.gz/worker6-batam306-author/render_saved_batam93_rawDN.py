"""Display-only PB02 source-native saved-block crops; no network/source read or indices."""
from pathlib import Path
import json,hashlib,collections
import numpy as np
import rasterio
ROOT=Path(__file__).resolve().parent.parent/'worker6-metadata';OUT=Path(__file__).resolve().parent/'native-rawDN-PB05-review';OUT.mkdir(exist_ok=True)
plan=json.loads((ROOT/'actual-first-date-native-block-plan778.json').read_text());items={i['item_id']:i for i in plan['items']};rows=[];held=[]
for folder in (ROOT/'first-raw-native-observation-001').glob('S2*'):
 f=folder/'point-observations.jsonl'
 if not f.exists():continue
 for l in f.read_text().splitlines():
  r=json.loads(l)
  if r['original_key']['owner']!=22727:continue
  (rows if r['normalization_contract_unchanged']['PB05_metadata_contradiction_retained'] else held).append(r)
assert len(rows)==93 and len(held)==213
rows.sort(key=lambda p:(p['item_id'],p['assets']['red']['native_containing_pixel'],p['point_index']))
pages=[];pageimages=[];pageindex=[];page_number=0
cached_item=None;arrays={}
for global_index,p in enumerate(rows):
 if p['item_id']!=cached_item:
  arrays.clear();item=items[p['item_id']]
  assert item['processing_baseline']=='05.00' and item['earthsearch_boa_offset_applied'] is True and item['declared_offset']==-0.1
  for band in ('red','green','blue','nir'):
   arrays[band]={}
   for block in item['assets'][band]['native_blocks']:
    br,bc=block['block'];meta=ROOT/'first-raw-native-observation-001'/p['item_id']/band/('block-%02d-%02d.json'%(br,bc));m=json.loads(meta.read_text());f=ROOT/m['array']['file']
    with np.load(f,allow_pickle=False) as z:values=z['values'];mask=z['mask']
    arrays[band][(br,bc)]=(values,mask,m['native_window'])
  cached_item=p['item_id']
 raw=np.zeros((4,49,49),np.uint16);masks=np.zeros((4,49,49),np.uint8);sources=[]
 for b,band in enumerate(('red','green','blue','nir')):
  a=p['assets'][band];window=a['native_context_window_plan']['requested_context_window'];left,top,width,height=window;assert width==height==49;bh,bw=item['assets'][band]['actual_header']['block_shapes'][0];H=item['assets'][band]['actual_header']['height'];W=item['assets'][band]['actual_header']['width']
  for rr in range(49):
   sr=top+rr
   for cc in range(49):
    sc=left+cc
    if not (0<=sr<H and 0<=sc<W):continue
    values,mask,w=arrays[band][(sr//bh,sc//bw)];raw[b,rr,cc]=values[sr-w[1],sc-w[0]];masks[b,rr,cc]=mask[sr-w[1],sc-w[0]]
  row,col=a['native_containing_pixel'];assert int(raw[b,row-top,col-left])==a['raw_value'] and int(masks[b,row-top,col-left])==a['native_valid_mask'];sources.append(a['containing_array'])
 rowf,colf=p['assets']['red']['native_fractional_pixel'];left,top,_,_=p['assets']['red']['native_context_window_plan']['requested_context_window'];cy,cx=rowf-top,colf-left;images=[]
 # Uncalibrated RAWDN qualitative display ONLY: no gain/offset/BOA units.
 rawdisplay=raw.astype(np.float64)
 for bands,hi in [([0,1,2],3000),([3,0,1],5000)]:
  patch=np.moveaxis(np.clip(rawdisplay[bands]/hi*255,0,255).astype(np.uint8),0,-1);patch[np.any(masks==0,axis=0)]=[255,0,255]
  ii=np.arange(192)*49//192;im=patch[ii[:,None],ii[None,:]].copy();yy=int(cy/49*192);xx=int(cx/49*192)
  for dy,dx in [(-5,0),(-4,0),(4,0),(5,0),(0,-5),(0,-4),(0,4),(0,5)]:
   if 0<=yy+dy<192 and 0<=xx+dx<192:im[yy+dy,xx+dx]=[255,255,0]
  images.append(im)
 pageimages.append(np.concatenate(images,axis=1));pageindex.append({'global_index_zero_based':global_index,'panel_1based':len(pageindex)+1,'point_index':p['point_index'],'original_key':p['original_key'],'item_id':p['item_id'],'acquisition_datetime':p['acquisition_datetime'],'raw_RGBNIR':[p['assets'][b]['raw_value'] for b in ('red','green','blue','nir')],'raw_masks':[p['assets'][b]['native_valid_mask'] for b in ('red','green','blue','nir')],'raw_SCL_value':p['assets']['scl']['raw_value'],'raw_SCL_mask':p['assets']['scl']['native_valid_mask'],'fractional_centre_in_crop':[cy,cx],'native_requested_window':[left,top,49,49],'context_complete':p['assets']['red']['native_context_window_plan']['context_complete_within_source_frame'],'source_array_pins':sources})
 if len(pageimages)==24 or global_index==len(rows)-1:
  page_number+=1;canvas=np.full((1176,1536,3),255,np.uint8)
  for n,im in enumerate(pageimages):canvas[(n//4)*196:(n//4)*196+192,(n%4)*384:(n%4)*384+384]=im
  f=OUT/f'batam-PB05-rawDN-{page_number:02d}.png'
  with rasterio.open(f,'w',driver='PNG',width=1536,height=1176,count=3,dtype='uint8') as ds:ds.write(np.moveaxis(canvas,-1,0))
  b=f.read_bytes();pages.append({'page_1based':page_number,'file':str(f.relative_to(OUT.parent)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'panels':pageindex});pageimages=[];pageindex=[]
(OUT/'contact-inventory.json').write_text(json.dumps({'scope':93,'all_original_Batam_held_scope':306,'PB05_raw_only_hold_preserved':93,'pages':pages,'display':'4columns×6rows, eachpanelleftRGB/rightNIR-R-G. PB05 uncalibrated RAWDN fixedRGB0..3000/FCC0..5000 qualitative displayonly; NOgain/offset/BOAunits/indices/quantitativeinterpretation. Metadata−.1/true contradiction andrawonlyholdpreserved. Nearestdisplayenlargement, hollowfractionalcentre cross, centrepixelunpainted. Magenta=actualmask0oroutsideframe; missingedgepixelsnotclamped.','new_physical_credit':0},indent=2)+'\n')
print(json.dumps({'qualitative_uncalibrated_PB05_rawDN93':True,'pages':len(pages),'PB05radiometry_hold_preserved':True}))
