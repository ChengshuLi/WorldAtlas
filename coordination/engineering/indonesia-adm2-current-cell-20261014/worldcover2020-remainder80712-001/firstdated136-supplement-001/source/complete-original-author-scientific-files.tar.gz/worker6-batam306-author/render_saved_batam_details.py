"""Display-only close views of manually flagged exact centres, from saved raw blocks."""
from pathlib import Path
import json,hashlib
import numpy as np
import rasterio
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent/'worker6-metadata';OUT=HERE/'native-detail-review';OUT.mkdir(exist_ok=True)
manual=json.loads((HERE/'provisional-wide-visual-decisions-NOT-FINAL.json').read_text());wanted={x['point_index']:x for x in manual['records'] if x['detail_required']};plan=json.loads((ROOT/'actual-first-date-native-block-plan778.json').read_text());items={x['item_id']:x for x in plan['items']};rows=[]
for f in (ROOT/'first-raw-native-observation-001').glob('S2*/point-observations.jsonl'):
 for l in f.read_text().splitlines():
  r=json.loads(l)
  if r['original_key']['owner']==22727 and r['point_index'] in wanted:rows.append(r)
rows.sort(key=lambda x:(wanted[x['point_index']]['source_display_kind'],x['item_id'],x['assets']['red']['native_containing_pixel']))
assert len(rows)==109
arrays={};cached=None;pages=[];pageimages=[];panels=[]
for p in rows:
 item=items[p['item_id']]
 if cached!=p['item_id']:
  arrays.clear()
  for band in ('red','green','blue','nir'):
   arrays[band]={}
   for block in item['assets'][band]['native_blocks']:
    br,bc=block['block'];m=json.loads((ROOT/'first-raw-native-observation-001'/p['item_id']/band/('block-%02d-%02d.json'%(br,bc))).read_text())
    with np.load(ROOT/m['array']['file'],allow_pickle=False) as z:v=z['values'];mask=z['mask']
    arrays[band][(br,bc)]=(v,mask,m['native_window'])
  cached=p['item_id']
 raw=np.zeros((4,17,17),np.uint16);masks=np.zeros((4,17,17),np.uint8)
 for b,band in enumerate(('red','green','blue','nir')):
  a=p['assets'][band];row,col=a['native_containing_pixel'];top,left=row-8,col-8;h=item['assets'][band]['actual_header'];bh,bw=h['block_shapes'][0]
  for rr in range(17):
   for cc in range(17):
    sr,sc=top+rr,left+cc
    if not(0<=sr<h['height'] and 0<=sc<h['width']):continue
    v,m,w=arrays[band][(sr//bh,sc//bw)];raw[b,rr,cc]=v[sr-w[1],sc-w[0]];masks[b,rr,cc]=m[sr-w[1],sc-w[0]]
  assert int(raw[b,8,8])==a['raw_value'] and int(masks[b,8,8])==a['native_valid_mask']
 fractional=p['assets']['red']['native_fractional_pixel'];cy,cx=fractional[0]-top,fractional[1]-left;pair=[];pb05=item['normalization_contract']['PB05_metadata_contradiction_retained']
 values=raw.astype(np.float64) if pb05 else raw.astype(np.float64)*0.0001
 stretches=(3000,5000) if pb05 else (0.3,0.5)
 for bands,hi in zip(([0,1,2],[3,0,1]),stretches):
  patch=np.moveaxis(np.clip(values[bands]/hi*255,0,255).astype(np.uint8),0,-1);patch[np.any(masks==0,axis=0)]=[255,0,255];ii=np.arange(256)*17//256;im=patch[ii[:,None],ii[None,:]].copy();yy=int(cy/17*256);xx=int(cx/17*256)
  for dy,dx in [(-8,0),(-7,0),(7,0),(8,0),(0,-8),(0,-7),(0,7),(0,8)]:
   if 0<=yy+dy<256 and 0<=xx+dx<256:im[yy+dy,xx+dx]=[255,255,0]
  pair.append(im)
 pageimages.append(np.concatenate(pair,axis=1));panels.append({'panel_1based':len(panels)+1,'point_index':p['point_index'],'original_key':p['original_key'],'item_id':p['item_id'],'display_kind':'UNCALIBRATED-RAWDN-noBOAunits' if pb05 else 'PB02gain0.0001offset0-once','fractional_centre_in_crop':[cy,cx],'requested_native_window':[left,top,17,17],'raw_RGBNIR':[p['assets'][b]['raw_value'] for b in ('red','green','blue','nir')],'raw_SCL':p['assets']['scl']['raw_value'],'wide_locator':wanted[p['point_index']]['wide_view'],'provisional_label':wanted[p['point_index']]['provisional_label']})
 if len(pageimages)==12 or p is rows[-1]:
  canvas=np.full((1040,1536,3),255,np.uint8)
  for n,im in enumerate(pageimages):canvas[(n//3)*260:(n//3)*260+256,(n%3)*512:(n%3)*512+512]=im
  f=OUT/f'batam-detail-{len(pages)+1:02d}.png'
  with rasterio.open(f,'w',driver='PNG',width=1536,height=1040,count=3,dtype='uint8') as ds:ds.write(np.moveaxis(canvas,-1,0))
  b=f.read_bytes();pages.append({'page_1based':len(pages)+1,'file':str(f.relative_to(HERE)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'panels':panels});pageimages=[];panels=[]
(OUT/'contact-inventory.json').write_text(json.dumps({'scope':109,'selection':'All75provisionalpositives+34consequentialambiguousactualwideviewcases; no SCL/spectrum classifier.','layout':'3columns×4rows, leftRGB/rightNIRRG,17nativepixels,256displaypixels eachchannelview,hollowfractionalcentremarker.','pages':pages},indent=2)+'\n');print({'keys':109,'pages':len(pages)})
