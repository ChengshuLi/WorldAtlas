from pathlib import Path
import json,gzip,hashlib,re,datetime
r=Path('/workspace/WorldAtlas');p=json.loads(gzip.decompress(Path('/tmp/worldatlas-v5-queue-published-final-plan.json.gz').read_bytes()));raw=Path('/tmp/worldatlas-v5-actual-issues-pages.json').read_text();pages=[]
while raw.strip():
 page,n=json.JSONDecoder().raw_decode(raw.lstrip());pages.append(page);raw=raw.lstrip()[n:]
by={i['number']:i for page in pages for i in page if 'pull_request' not in i};scopes=[]
for x in p['issue_updates']:
 a=by[x['number']];assert a['body']==x['body'],x['number'];assert sorted(l['name'] for l in a['labels'])==sorted(x['labels']),x['number'];assert a['state']=='open'
 if x['role']=='packet':
  matches=[json.loads(m[1]) for m in re.finditer(r'```json\s*\n([\s\S]*?)\n```',a['body'])];s=next(s for s in matches if s.get('batch_id'));scopes.append(s)
for x in p['issue_creations']:
 a=by[x['number']];assert a['body']==x['body'];assert {l['name'] for l in a['labels']}==set(x['labels']);scopes.append(x['scope'])
ids=[];regions={}
for s in scopes:
 assert s['release']==p['release'] and s['macro_certificate_sha256']==p['macro_certificate_sha256'];assert hashlib.sha256('\n'.join(sorted(s['member_location_ids'])).encode()).hexdigest()==s['member_location_ids_sha256'];ids+=s['member_location_ids'];regions.setdefault(s['region_id'],[]).extend(s['member_location_ids'])
assert len(scopes)==275 and len(ids)==len(set(ids))==49625 and len(regions)==81
handoffs=json.loads(gzip.decompress((r/'data/macro-foundation/regional-handoffs.json.gz').read_bytes()))
for row in handoffs['regions']:assert hashlib.sha256(json.dumps(sorted(regions[row['region_id']]),separators=(',',':')).encode()).hexdigest()==row['envelope']['member_location_ids_sha256']
receipt={'read_only':True,'verified':True,'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'release':p['release'],'macro_certificate_sha256':p['macro_certificate_sha256'],'github_issues_read':len(by),'existing_role_bodies_verified':435,'supplemental_issues':[x['number'] for x in p['issue_creations']],'packets':275,'locations':len(ids),'unique_locations':len(set(ids)),'regions':len(regions),'missing':0,'duplicates':0,'labels_preserved':True,'history_location_attribute_imports_enabled':False};Path('/tmp/worldatlas-v5-actual-queue-readback.json').write_text(json.dumps(receipt,separators=(',',':'))+'\n');print(receipt)
