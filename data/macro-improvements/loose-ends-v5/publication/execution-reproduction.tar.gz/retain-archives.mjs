import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {publishGeographicReleases,retainGeographicArchives} from '/workspace/WorldAtlas/scripts/bootstrap-geographic-release.mjs';
import {readGeographicReleaseManifest,decodeGeographicReleaseBatch} from '/workspace/WorldAtlas/scripts/read-geographic-release-manifest.mjs';
const origin='https://worldatlas-explorer.chengshu-li-2013.chatgpt.site',directory='/workspace/WorldAtlas/data/geographic-releases',mode=process.argv[2];
if(mode!=='archives'||!process.stdin.isTTY)throw Error('Explicit mode and hidden credential stdin required');
process.stdin.setRawMode(true);console.log('Ready for private service credential on hidden stdin.');
const token=await new Promise((resolve,reject)=>{let text='';process.stdin.on('data',chunk=>{text+=chunk;if(!/[\r\n]/.test(text))return;process.stdin.pause();process.stdin.setRawMode(false);try{resolve(JSON.parse(text.trim()).token)}catch{reject(Error('Invalid hidden input'))}})});
async function request(route,options={}){let response;for(let n=0;n<4;n++){response=await fetch(origin+route,{...options,headers:{'OAI-Sites-Authorization':'Bearer '+token,Origin:origin,...options.headers}});if(![429,502,503,504].includes(response.status))break;await new Promise(r=>setTimeout(r,500*2**n));}if(!response.ok&&!(options.allowNotFound&&response.status===404))throw Error('Private API HTTP '+response.status+' for '+route);return response;}
const manifest=readGeographicReleaseManifest(directory),sourceId=manifest.releases.at(-1).source_id,paths=[];
for(const folder of ['data/macro-foundation/envelopes-v5','data/macro-improvements/loose-ends-v5/publication','data/macro-improvements/loose-ends-v5/derived','data/macro-improvements/loose-ends-v5/evidence'])for(const file of fs.readdirSync(folder,{recursive:true})){const full=folder+'/'+file;if(fs.statSync(full).isFile())paths.push(full);}
const groups=new Map();for(const file of paths.toSorted()){const digest=createHash('sha256').update(fs.readFileSync(file)).digest('hex');if(!groups.has(digest))groups.set(digest,[]);groups.get(digest).push(file);}
const lanes=Array.from({length:6},()=>[]);let index=0;for(const paths of groups.values())lanes[index++%6].push(...paths);
const results=await Promise.all(lanes.map(archiveFiles=>retainGeographicArchives({archiveFiles,sourceId,request,readArchive:file=>fs.readFileSync(file)})));const retained=results.flat().toSorted((a,b)=>a.path.localeCompare(b.path)),receipt={recorded_at:new Date().toISOString(),source_id:sourceId,retained,objects:new Set(retained.map(r=>r.id)).size,bytes:retained.reduce((n,r)=>n+r.bytes,0),deployed:false};
fs.writeFileSync('/tmp/worldatlas-macro-v5-archives-receipt.json',JSON.stringify(receipt));console.log(JSON.stringify({retained_paths:retained.length,objects:receipt.objects,bytes:receipt.bytes}));
