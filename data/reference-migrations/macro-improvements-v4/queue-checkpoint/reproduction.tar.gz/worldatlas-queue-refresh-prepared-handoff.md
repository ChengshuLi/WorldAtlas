# Queue refresh: root-only post-publication handoff

Prepared 2026-10-02 (America/Los_Angeles). This helper performed only local `/tmp` writes and read-only GitHub/data reads. No issues, claims, current data, code or live Site were changed.

Actual fresh GitHub snapshot: `/tmp/worldatlas-queue-publication-issues-v4.json.gz`, 495 issues, SHA-256 `7ec03ceca097c33dc4e1430ec41cc90887db2a43caa91fe09c2450966e55f437`. Current installed macro pins were independently loaded from `data/macro-foundation/regional-handoffs.json.gz`; certificate `66a780aae17f18a8a7acbf11dcef68266b836c22e5fb70a026671ae3cfda6b5b`. Preview `/tmp/worldatlas-queue-v4-current-preview` uses actual release/envelope pins but deliberately remains publication_verified=false and all eight new packets blocked. **Never publish preview bodies.**

The preview passed exhaustive partition: 265 exact original scopes retained plus eight supplemental scopes (1,1,1,7,1,1,20,2) = 273 packets, 49,623 distinct locations, no omissions/duplicates, 5,138 provinces, 480 areas, 81 regions. All 427 original body updates preserve issue numbers/comments/PRs, owned members/hashes/directories. Nine existing-ID changes receive revalidation instructions; Manihiki provenance context is retained. No interior or history-import approval is inferred.

## Durable inputs and executable helpers

Portable helper `/tmp/worldatlas-plan-published-queue-portable.py` eliminates hardcoded `/tmp` source paths and requires `--candidate`, `--composition`, `--triage`, `--registry`, `--crosswalk`, `--issues`, `--output`. Optional `--handoffs`, `--live-confirmation`, `--created-issues` preserve the fail-closed publication/number gates. It reads gzip transparently and records every input hash. The original routing crosswalk already exists on main at `data/macro-improvements/combined-restoration/routing/routing-status-crosswalk.json.gz`.

Original triage and numeric issue registry were **not found as durable main files**; exact compressed copies, plus composition formerly only in the validated stage, are prepared in `/tmp/worldatlas-queue-refresh-inputs/`:

- `queue-workload-v3.archive.json.gz`: original 265 scopes and full source-policy inventory, decompressed SHA `305f8894bcce2b7c5d95ab51fce0c94307d3c3aae037d75dc13e11fd987dfae5`.
- `queue-issue-registry-v3.archive.json.gz`: exact 81-region/427-issue crosswalk, decompressed SHA `54161beac2e72373c1a3e6c3d06abd0edcfb56f3bcaeea1b9373b6639b4102cf`.
- `macro-restoration-composition.json.gz`: exact validated ordered source composition, compressed 179,792 bytes.
- `input-receipt.json`: compressed and uncompressed hashes for all three.

Root should retain these files in the final publication/queue PR, alongside the portable planner, readback helper and fetch helper. Suggested input destination `data/macro-foundation/queue-refresh-inputs-v4/`; helper paths may be `scripts/plan-published-queue.py`, `scripts/fetch-queue-issues.py`, `scripts/verify-published-queue.mjs`. No geography change is caused by storing these records. Final generated v3 body archives must also be committed compressed so the original issue bodies/pins/dates remain reproducible.

## Preconditions before any issue mutation

1. Release4 is committed/pushed, imported and hosted; actual live readback matches release ID, 49,623 count, hierarchy and footprints. Macro geometry/certificate fingerprints are independently verified. Regional interiors and location-attribute imports remain false.
2. Root creates a factual live confirmation JSON, without credential material:
   `{"published":true,"verified_by_root":true,"release":<exact handoffs.release>,"macro_certificate_sha256":<actual hash>,"live_location_count":49623,"historical_location_attribute_imports_enabled":false}`.
3. Fresh issue snapshot is fetched immediately before planning. The planner rejects status:claimed regional tasks. Before each write root also reads canonical claims/comments and compares `before_body_sha256` and `before_updated_at` against actual issue state, preserving late edits. If changed, refetch/replan; never overwrite a live worker.

## Exact bounded generation commands

The following are local/read-only. Paths use the prepared originals until root commits their durable counterparts:

```sh
python /tmp/worldatlas-fetch-queue-issues.py --output /tmp/worldatlas-queue-publication-issues-final.json.gz
python /tmp/worldatlas-plan-published-queue-portable.py --candidate /workspace/WorldAtlas/data --composition /tmp/worldatlas-queue-refresh-inputs/macro-restoration-composition.json.gz --triage /tmp/worldatlas-queue-refresh-inputs/queue-workload-v3.archive.json.gz --registry /tmp/worldatlas-queue-refresh-inputs/queue-issue-registry-v3.archive.json.gz --crosswalk /workspace/WorldAtlas/data/macro-improvements/combined-restoration/routing/routing-status-crosswalk.json.gz --issues /tmp/worldatlas-queue-publication-issues-final.json.gz --handoffs /workspace/WorldAtlas/data/macro-foundation/regional-handoffs.json.gz --live-confirmation ROOT_ACTUAL_LIVE_RECEIPT_JSON --output /tmp/worldatlas-queue-v4-final
```

Before creating supplemental issues, search existing open/all issues for each exact `<!-- worldatlas-queue-item:<key> -->` marker. Reuse the issue if present; do not duplicate after retries. Root creates only eight from plan.issue_creations, preserving original raised dates and parents. Save exact key→numeric-number map `/tmp/worldatlas-created-supplemental-issues-v4.json` (value either number or `{number:N}`). Rerun the same planner with `--created-issues /tmp/worldatlas-created-supplemental-issues-v4.json`. This resolves all umbrella links and appends numeric dependencies to the eight affected integration contracts while keeping all original dependencies. Do not publish approval bodies with unresolved keys.

Root may apply all 427 conditional body/label updates with bounded concurrency (for example four HTTP operations), preserving any active claims or user edits. All 81 integration tasks remain blocked; umbrellas unclaimable; original packet status/closed-source prerequisites preserved. Only actual published supplement packets become ready.

After writes, run the independent readback (read-only; reads canonical comments):

```sh
WORLDATLAS_QUEUE_CONTRACT_ROOT=/workspace/WorldAtlas node /tmp/worldatlas-published-queue-readback.mjs /tmp/worldatlas-queue-v4-final
```

It validates all 427 originals plus eight supplements, 273/49,623 exhaustive member partition, current parent totals, numeric integration dependencies, closed ready prerequisites and source-only history gating. Commit final generated manifests/body archives/source profiles and `actual-github-queue-readback.json`; retain original 49,589-member readback proof as its original snapshot.

Kingman/Gardner, Chagos partial family coverage, Manuae/Aitutaki footprint review and all regional interiors stay visibly open. The source snapshot and member proof cannot prove live publication; only root's actual publish/readback receipt can open queue readiness.
