import fs from 'node:fs';
import crypto from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {readClaim,githubPages} from '/workspace/WorldAtlas/scripts/issue-claim-contract.mjs';
const run=promisify(execFile),dir='/tmp/worldatlas-queue-v4-final',plan=JSON.parse(fs.readFileSync(dir+'/queue-update-plan.json'));
if(!plan.publication_verified||!plan.publication_gate.issue_number_links_resolved)throw Error('Published scope and numeric links required');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex'),repo='repos/ChengshuLi/WorldAtlas';
const api=async(path,body)=>JSON.parse((await run('gh',['api',path,...(body?['--method','PATCH','--input','-']:[])],{input:undefined,maxBuffer:12*1024*1024})).stdout);
async function request(path,body){
 for(let attempt=0;attempt<3;attempt++){try{return await new Promise((resolve,reject)=>{const child=execFile('gh',['api',path,...(body?['--method','PATCH','--input','-']:[])],{maxBuffer:12*1024*1024},(error,stdout)=>error?reject(error):resolve(JSON.parse(stdout)));if(body)child.stdin.end(JSON.stringify(body));});}catch(e){if(!/HTTP 50[234]/.test(e.message)||attempt===2)throw e;await new Promise(resolve=>setTimeout(resolve,1000));}}
}
const errors=[],log=dir+'/applied-issues.jsonl';let next=0,completed=0;
const recorded=new Set(fs.existsSync(log)?fs.readFileSync(log,'utf8').trim().split('\n').filter(Boolean).map(s=>JSON.parse(s).number):[]);
async function worker(){while(next<plan.issue_updates.length&&!errors.length){const x=plan.issue_updates[next++];try{
 if(recorded.has(x.number)){completed++;continue;}
 const actual=await request(`${repo}/issues/${x.number}`),labels=actual.labels.map(l=>l.name);
 if(actual.body===x.body){completed++;continue;}
 if(hash(actual.body??'')!==x.before_body_sha256||actual.updated_at!==x.before_updated_at)throw Error(`Concurrent body/date edit #${x.number}; preserve and replan`);
 if(JSON.stringify(labels.slice().sort())!==JSON.stringify(x.before_labels.slice().sort())||labels.includes('status:claimed'))throw Error(`Concurrent label/claim #${x.number}`);
 if(actual.comments){const claim=readClaim(await githubPages(path=>request(path),`/${repo}/issues/${x.number}/comments`));if(claim?.active)throw Error(`Active canonical claim #${x.number}`);}
 if(JSON.stringify(x.labels.slice().sort())!==JSON.stringify(labels.slice().sort()))throw Error('Unexpected label mutation');
 const patched=await request(`${repo}/issues/${x.number}`,{body:x.body});if(patched.body!==x.body)throw Error('Write readback mismatch');
 fs.appendFileSync(log,JSON.stringify({number:x.number,body_sha256:hash(patched.body),updated_at:patched.updated_at,labels_preserved:true})+'\n');completed++;if(completed%25===0)console.log(JSON.stringify({updated:completed,total:plan.issue_updates.length}));
 }catch(e){errors.push({number:x.number,error:e.message});}}}
await Promise.all(Array.from({length:4},worker));
const receipt={recorded_at:new Date().toISOString(),updates:completed,expected:plan.issue_updates.length,errors};fs.writeFileSync(dir+'/apply-receipt.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));if(errors.length)process.exitCode=1;
