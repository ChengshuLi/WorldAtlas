#!/usr/bin/env python3
"""Read-only queue plan generator. This program has no GitHub mutation/API capability.
Preview: python THIS --candidate /tmp/.../creation --output /tmp/worldatlas-queue-v4-preview
Published: add --handoffs FINAL --live-confirmation ROOT_VERIFIED_RECEIPT and a fresh --issues snapshot.
Root alone consumes planned issue creations/updates after publication verification.
"""
import argparse,copy,json,gzip,re,hashlib,datetime
from collections import defaultdict,Counter
from pathlib import Path
from zoneinfo import ZoneInfo

def load(p):
 p=Path(p);b=p.read_bytes();return json.loads(gzip.decompress(b) if p.name.endswith('.gz') else b)
def sha(b):return hashlib.sha256(b).hexdigest()
def js(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def member_sha(ids):return sha('\n'.join(sorted(ids)).encode())
def envelope_member_sha(ids):return sha(js(sorted(ids)).encode())
def save(root,name,data):
 p=root/name;b=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode();p.write_bytes(b)
 if len(b)>100000:Path(str(p)+'.gz').write_bytes(gzip.compress(b,mtime=0))
 return {'path':str(p),'sha256':sha(b),'bytes':len(b)}
def spec(body):
 matches=list(re.finditer(r'<!-- worldatlas-work:v1\s*\n([\s\S]*?)\n-->',body));assert len(matches)==1
 return json.loads(matches[0][1])
def scope_block(body,batchid):
 blocks=list(re.finditer(r'```json\s*\n([\s\S]*?)\n```',body))
 for match in blocks:
  try:x=json.loads(match[1])
  except ValueError:continue
  if isinstance(x,dict) and x.get('batch_id')==batchid:return match,x
 raise AssertionError('Exact original packet JSON missing '+batchid)
def workblock(x):return '<!-- worldatlas-work:v1\n'+js(x)+'\n-->'
def prune(x):
 if isinstance(x,dict):return {k:prune(v) for k,v in x.items() if k not in ['coordinates','geometry','before_feature','after_feature','unchanged_location_ids']}
 if isinstance(x,list):return [prune(v) for v in x]
 return x
ap=argparse.ArgumentParser();ap.add_argument('--candidate',required=True);ap.add_argument('--output',required=True);ap.add_argument('--issues',required=True);ap.add_argument('--triage',required=True);ap.add_argument('--registry',required=True);ap.add_argument('--crosswalk',required=True);ap.add_argument('--composition',required=True);ap.add_argument('--handoffs');ap.add_argument('--live-confirmation');ap.add_argument('--created-issues');args=ap.parse_args()
out=Path(args.output);out.mkdir(parents=True,exist_ok=True);candidate=Path(args.candidate);m=load(args.triage);registry=load(args.registry);issues={x['number']:x for x in load(args.issues)};hlist=load(candidate/'hierarchy.json');h={x['id']:x for x in hlist};comp=load(args.composition);cross=load(args.crosswalk);now=datetime.datetime.now(datetime.timezone.utc);date=now.astimezone(ZoneInfo('America/Los_Angeles')).date().isoformat()
assert len(registry['regions'])==81 and len(m['batches'])==265
oldids={k for b in m['batches'] for k in b['member_location_ids']};assert len(oldids)==49589
byloc={};byunit=defaultdict(list);new=set(comp['new_ids']);metadata={};locationnames={};chains={}
for part in load(candidate/'world-index.json')['parts']:
 data=load(candidate/part)
 for feature in data['features']:
  p=feature['properties'];i=p['id'];assert i not in byloc;i_parent=p['parent_id'];ch=[]
  while i_parent:assert i_parent in h;i_item=h[i_parent];ch.append(i_parent);byunit[i_parent].append(i);i_parent=i_item.get('parent_id')
  assert len(ch)==5;chains[i]=ch;byloc[i]=ch[2];locationnames[i]=p['name']
  if i in new:metadata[i]=p.get('metadata',{})
assert len(byloc)==49623 and set(byloc)==oldids|new and len(new)==34 and not oldids&new
for ids in byunit.values():ids.sort()
original_batches={b['batch_id']:b for b in m['batches']};rmap={r['region_id']:r for r in m['regions']};recordmap={r['region_id']:r for r in registry['regions']}
for b in m['batches']:assert all(byloc[i]==b['region_id'] for i in b['member_location_ids']),('Existing workload moved regions',b['batch_id'])
final=load(args.handoffs) if args.handoffs else None;publication_verified=False
if final:
 assert len(final['regions'])==81 and final.get('regional_interiors_approved') is False
 for r in final['regions']:
  env=r['envelope'];assert env['member_location_ids_sha256']==envelope_member_sha(byunit[r['region_id']]);assert env['locations']==len(byunit[r['region_id']])
 release=final['release'];cert=final['macro_certificate_sha256'];envs={r['region_id']:r['envelope'] for r in final['regions']}
 assert release['version']==4 and release['hierarchy_sha256']==sha((candidate/'hierarchy.json').read_bytes())
 if args.live_confirmation:
  live=load(args.live_confirmation);assert live['published'] is True and live['verified_by_root'] is True
  assert live['release']==release and live['macro_certificate_sha256']==cert
  assert live['live_location_count']==49623 and live['historical_location_attribute_imports_enabled'] is False
  publication_verified=True
else:
 release={'id':'REQUIRED_FROM_FINAL_PUBLISHED_RELEASE','version':4,'hierarchy_sha256':sha((candidate/'hierarchy.json').read_bytes()),'footprints_sha256':'REQUIRED_FROM_FINAL_PUBLISHED_RELEASE'};cert='REQUIRED_FINAL_MACRO_CERTIFICATE_SHA256';envs={k:{'geometry_sha256':'REQUIRED_FINAL_FROZEN_GEOMETRY_SHA256','member_location_ids_sha256':envelope_member_sha(byunit[k]),'locations':len(byunit[k])} for k in rmap}
assert not args.live_confirmation or final,'A root publication verification requires actual final handoffs'
newbyregion=defaultdict(list)
for i in sorted(new):newbyregion[byloc[i]].append(i)
geometry_ids=[x['id'] for x in comp['replacement_deltas']];assert len(geometry_ids)==6
namechanges=[x for x in comp['reference_changed_location_properties'] if x['before_properties']['name']!=x['after_properties']['name']];assert len(namechanges)==3
changed_ids=set(geometry_ids)|{x['location_id'] for x in namechanges};assert len(changed_ids)==9
region_contexts=[]
context_ids={byloc[i] for i in new|changed_ids}|{comp['macro_amendment']['reciprocal_exclusion']['region_id']}
assert len(context_ids)==14
for region in sorted(context_ids):
 region_contexts.append({'region_id':region,'name':h[region]['name'],'new_location_ids':sorted(i for i in new if byloc[i]==region),'footprint_correction_ids':sorted(i for i in geometry_ids if byloc[i]==region),'present_day_name_correction_ids':sorted(x['location_id'] for x in namechanges if byloc[x['location_id']]==region),'reciprocal_macro_exclusion_only':region==comp['macro_amendment']['reciprocal_exclusion']['region_id'],'candidate_member_ids_sha256':envelope_member_sha(byunit[region])})
provenance_changes=[x['location_id'] for x in comp['reference_changed_location_properties'] if x['before_properties']['name']==x['after_properties']['name']]
assert len(comp['reference_changed_groups'])==2
supp=[];full_source_hints=[]
for region,ids in sorted(newbyregion.items()):
 assert len(ids)<=200
 batchid='regional-supplement:'+sha((region+'\n'+'\n'.join(ids)).encode())[:16];owned='data/regional-review/'+batchid.replace(':','-')+'/'
 area_scopes=[];province_scopes=[]
 for tier,target in [(1,area_scopes),(0,province_scopes)]:
  for u in sorted({chains[i][tier] for i in ids}):
   scoped=[i for i in ids if u in chains[i]];target.append({'id':u,'name':h[u]['name'],'owned_member_location_count':len(scoped),'member_location_ids':scoped,'full_current_location_count':len(byunit[u]),'partial':len(scoped)!=len(byunit[u]),'combined_parent_decision':'Regional integration owns original plus supplemental packets; no independent shared-parent edits'})
 sources=[]
 for i in ids:
  meta=metadata[i];linked=[c for c in cross['correction_candidates'] if c['location_id']==i]
  assert len(linked)==1
  sources.append({'location_id':i,'name':locationnames[i],'metadata':prune(meta),'source_correction_issue':linked[0]['issue'],'source_evidence':linked[0]['source_and_operation_evidence'],'policy_profile_status':'Modern sourced whole-island/reference patch is not an approved atlas granularity or source-policy profile; independently verify geographic role, vintage, license and full-family completeness','reference_owner':'unknown; no sovereign owner inferred from macro membership'})
 full_source_hints.extend(sources)
 sources=[{'location_id':z['location_id'],'name':z['name'],'source_correction_issue':z['source_correction_issue'],'metadata':{k:v for k,v in z['metadata'].items() if k in ['source_id','source_identity','source_name','source_url','source_raw_sha256','license','attribution','reference_year','supported_from','supported_to','location_basis']},'source_profile_status':z['policy_profile_status'],'reference_owner':z['reference_owner'],'full_source_profile_canonical_sha256':sha(js(z).encode()),'durable_full_source_profile_path':'data/macro-foundation/new-location-source-profiles-v4.json.gz'} for z in sources]
 scope={'batch_id':batchid,'region_id':region,'location_count':len(ids),'member_location_ids':ids,'member_location_ids_sha256':member_sha(ids),'release':release,'macro_certificate_sha256':cert,'frozen_region_geometry_sha256':envs[region]['geometry_sha256'],'frozen_region_member_ids_sha256':envs[region]['member_location_ids_sha256'],'area_scopes':area_scopes,'province_scopes':province_scopes,'owned_evidence_path':owned,'review_only':True,'source_profile_hints':sources,'original_partition_unchanged':True}
 label=h[region]['name'];rec=recordmap[region];work={'max_prs':2,'depends_on':[33,36],'scope':f'Read-only supplemental source/semantic audit of exactly {len(ids)} new published location IDs in {region}; evidence/proposals only; no geography/schema/grid/live changes or attribute imports','mode':'geography','owned_paths':[owned]}
 body=f'Raised/recorded: {date} (America/Los_Angeles). Parent: #{rec["umbrella"]}; worldwide umbrella #7.\n\nBounded supplemental geography evidence packet: **{len(ids)} locations**, at most two PRs. Original 265 packets keep their exact scopes. This is an evidence workload, not a new geographic unit.\n\nRelease: `{release["id"]}` (v4).\nHierarchy SHA-256: `{release["hierarchy_sha256"]}`.\nFootprints SHA-256: `{release["footprints_sha256"]}`.\nMacro certificate SHA-256: `{cert}`.\nFrozen region geometry SHA-256: `{envs[region]["geometry_sha256"]}`.\nFrozen region member IDs SHA-256: `{envs[region]["member_location_ids_sha256"]}`.\n\nOwned evidence directory: `{owned}`. Use geography/<job-id>.\n\nAcceptance:\n'+ '\n'.join('- '+x for x in m['review_contract']['required_review'])+'\n\nDocument every source/island, each new coextensive tier exception, all shared original parents, and known omissions. Modern coastline dates are not ancient effective intervals. Source roles and original sovereign affiliations are evidence hints, not approved location ownership or tier suitability. Every sourced correction requires a separate bounded engineering issue. Preserve other workers’ evidence and all archived identities. Do not change shared hierarchy, footprints, canonical grid, UI/schema, claims or live releases. Historical location-attribute imports remain blocked until the complete region is separately approved and published.\n\nExact supplemental scope and source-profile review hints:\n```json\n'+js(scope)+'\n```\n\n'+workblock(work)+'\n\n<!-- worldatlas-queue-item:regional-supplement:'+batchid+' -->\n'
 assert len(body)<60000
 supp.append({'key':'regional-supplement:'+batchid,'title':f'Review {label} new named-land territories: {len(ids)} locations','labels':['type:geography','kind:work-item','status:ready' if publication_verified else 'status:blocked'],'body':body,'scope':scope,'parent_umbrella':rec['umbrella'],'approval_issue':rec['approval_issue'],'number':'REQUIRED_FROM_CREATED_ISSUE'})
created=load(args.created_issues) if args.created_issues else {}
for packet in supp:
 if packet['key'] in created:
  val=created[packet['key']];packet['number']=val['number'] if isinstance(val,dict) else val;assert isinstance(packet['number'],int)
assert len(supp)==8 and sum(x['scope']['location_count'] for x in supp)==34
all_packets=m['batches']+[x['scope'] for x in supp];flat=[i for x in all_packets for i in x['member_location_ids']];assert len(flat)==49623==len(set(flat)) and set(flat)==set(byloc)
# Scope roles remain original; full-parent totals/labels are revalidated using final membership.
unit_packet_count=Counter(u for packet in all_packets for u in {p for i in packet['member_location_ids'] for p in chains[i][:2]})
archive=[];updates=[];updated_manifest=copy.deepcopy(m);updated_manifest['release']=release;updated_manifest['macro_certificate_sha256']=cert;updated_manifest['generated_on']=date;updated_manifest['parent_partition_release']=m['release'];updated_manifest['supplemental_batches']=[x['scope'] for x in supp];updated_manifest['publication_verified']=publication_verified
notice=f'{date} (America/Los_Angeles): macro publication queue migration. Exact original workload member IDs, member hashes and owned evidence directories are preserved. Previous issue bodies/pins are archived with this migration. Global release/certificate and current region envelopes are refreshed; nine retained IDs changed (six footprints, three present-day names), with no historical claim transfer. Newly sourced locations are assigned separately to eight bounded supplemental packets. This update does not approve region interiors, original source completeness or location-attribute imports.\n\n'
def pinbody(body,r):
 old=r['envelope'];env=envs[r['region_id']]
 body=body.replace(m['release']['id'],release['id'])
 for label,value in [('Hierarchy SHA-256',release['hierarchy_sha256']),('Footprints SHA-256',release['footprints_sha256']),('Macro certificate SHA-256',cert),('Frozen region geometry SHA-256',env['geometry_sha256']),('Frozen region member IDs SHA-256',env['member_location_ids_sha256'])]:
  body,n=re.subn(r'^'+re.escape(label)+r': `[^`]+`\.',label+': `'+value+'`.',body,flags=re.M);assert n==1,(label,n)
 body=body.replace('(v3).','(v4).');return notice+body
for rec in registry['regions']:
 region=rec['region_id'];r=rmap[region];news=[s for s in supp if s['scope']['region_id']==region];fresh=r.copy();fresh['envelope']=envs[region];fresh['location_count']=len(byunit[region]);fresh['area_ids']=sorted(u for u in byunit if h[u]['level']=='area' and chains[byunit[u][0]][2]==region);fresh['province_ids']=sorted(u for u in byunit if h[u]['level']=='province' and chains[byunit[u][0]][2]==region)
 updated_manifest['regions'][next(k for k,x in enumerate(updated_manifest['regions']) if x['region_id']==region)]=fresh
 for number,kind in [(rec['umbrella'],'umbrella'),*[(n,'packet') for n in rec['review_issues']],(rec['approval_issue'],'approval')]:
  original=issues[number];assert original['state']=='open';assert 'status:claimed' not in original['labels'],('Live claim needs explicit rebase/revalidation',number)
  archive.append({'number':number,'body':original['body'],'title':original['title'],'labels':original['labels'],'updated_at':original['updated_at'],'body_sha256':sha(original['body'].encode()),'role':kind,'original_recorded_date_preserved':True})
  body=pinbody(original['body'],r);labels=original['labels'][:];scope=None;future_dep_keys=[]
  if kind=='packet':
   ix=rec['review_issues'].index(number);batchid=rec['batch_ids'][ix];match,scope=scope_block(body,batchid);oldscope=copy.deepcopy(scope);scope['release']=release;scope['original_scope_release']=m['release'];scope['frozen_region_geometry_sha256']=envs[region]['geometry_sha256'];scope['frozen_region_member_ids_sha256']=envs[region]['member_location_ids_sha256'];scope['macro_certificate_sha256']=cert
   scope['required_revalidation_location_ids']=sorted(set(scope['member_location_ids'])&changed_ids)
   for item in scope['province_scopes']:
    u=item['id'];item['original_name']=item['name'];item['name']=h[u]['name'];item['original_full_province_locations']=item['full_province_locations'];item['full_province_locations']=len(byunit[u]);item['original_parts']=item.get('parts');item['parts']=unit_packet_count[u];owned=len(set(scope['member_location_ids'])&set(byunit[u]));item['partial']=owned!=len(byunit[u])
   for item in scope['area_scopes']:
    u=item['id'];item['original_full_area_location_count']=item['full_area_location_count'];item['full_area_location_count']=len(byunit[u]);item['partial']=item['owned_member_location_count']!=len(byunit[u])
   assert scope['member_location_ids']==oldscope['member_location_ids'] and scope['member_location_ids_sha256']==oldscope['member_location_ids_sha256'] and scope['owned_evidence_path']==oldscope['owned_evidence_path']
   body=body[:match.start()]+'```json\n'+js(scope)+'\n```'+body[match.end():]
   body+='\n\nRetained-ID changes in this exact packet require source/footprint/label revalidation: '+(', '.join('`'+i+'`' for i in scope['required_revalidation_location_ids']) or 'none')+'. Existing semantic assessments remain open. New locations are owned by separate supplemental packets; combined parent acceptance belongs to the integration task.\n'
   replacement=next(b for b in updated_manifest['batches'] if b['batch_id']==batchid);replacement.update({k:scope[k] for k in ['release','area_scopes','province_scopes','original_scope_release','required_revalidation_location_ids']})
  elif kind=='umbrella':
   body=re.sub(r"\*\*\d+ locations, \d+ provinces and \d+ areas\*\*",f'**{fresh["location_count"]} locations, {len(fresh["province_ids"])} provinces and {len(fresh["area_ids"])} areas**',body)
   body+='\n\nOriginal packets keep '+str(rec['locations'])+' exact location IDs. Supplemental packet additions: '+str(sum(x['scope']['location_count'] for x in news))+'. Full current region has '+str(fresh['location_count'])+' locations.\n'
   body+='Supplemental packets (issue numbers linked after creation):\n'+('\n'.join('- '+s['key']+': '+str(s['scope']['location_count'])+' new locations' for s in news) or '- None')+'\n'
   if region==comp['macro_amendment']['reciprocal_exclusion']['region_id']:body+='Marcus/Minamitorishima is explicitly excluded from this Japan macro route and separately included in Northwestern Pacific/Micronesia/Oceania; no Japan mainland/other island association changes.\n'
  else:
   assert 'status:blocked' in labels and 'type:engineering' in labels
   existing_spec=spec(body);assert set(rec['review_issues'])<=set(existing_spec['depends_on']);future_dep_keys=[s['key'] for s in news]
   if created:
    assert all(s['key'] in created for s in news),'Resolve all supplemental issues for this approval before body publication'
    resolved=[s['number'] for s in news];existing_spec['depends_on']=list(dict.fromkeys(existing_spec['depends_on']+resolved));body=re.sub(r'<!-- worldatlas-work:v1\s*\n([\s\S]*?)\n-->',lambda _:workblock(existing_spec),body)
   body+='\n\nAdditional required supplemental geography evidence dependencies (resolve keys to created GitHub issue numbers before publishing this body): '+(', '.join(future_dep_keys) or 'none')+'. Preserve all original and later sourced correction dependencies. No history content readiness until all descendants, shared parents, source omissions and the approved grid are separately certified.\n'
  if kind=='umbrella' and region in context_ids:
   body+='\nFinite macro restoration context (whole-family coverage remains open):\n```json\n'+js(next(x for x in region_contexts if x['region_id']==region))+'\n```\n'
  if created:
   for s in news:body=body.replace(s['key'],'#'+str(s['number']))
  if not publication_verified:
   labels=[x for x in labels if x!='status:ready'];
   if kind!='umbrella' and 'status:blocked' not in labels:labels.append('status:blocked')
  assert len(body)<60000,(number,len(body))
  updates.append({'number':number,'role':kind,'region_id':region,'before_body_sha256':sha(original['body'].encode()),'before_updated_at':original['updated_at'],'before_labels':original['labels'],'body':body,'labels':labels,'supplemental_dependency_keys':future_dep_keys,'owned_members_changed':False,'preserve_issue_comments_claims_and_pr_links':True,'current_source_revalidation_ids':scope.get('required_revalidation_location_ids',[]) if scope else []})
assert Counter(x['role'] for x in updates)==Counter({'umbrella':81,'packet':265,'approval':81})
# Full bottom-up member inventory avoids centroid/independent-parent polygons.
inventory=[{'id':u,'name':h[u]['name'],'level':h[u]['level'],'parent_id':h[u].get('parent_id'),'member_location_ids':ids} for u,ids in sorted(byunit.items())]
assert Counter(x['level'] for x in inventory)==Counter({'province':5138,'area':480,'region':81,'subcontinent':29,'continent':6})
proof={'pass':True,'publication_verified':publication_verified,'locations':49623,'existing_locations':49589,'new_locations':34,'original_packets_preserved':265,'supplemental_packets':8,'total_packets':273,'duplicate_locations':0,'missing_locations':0,'member_location_ids_sha256':member_sha(flat),'all_current_provinces':5138,'all_current_areas':480,'regions':81,'min_supplemental_locations':min(x['scope']['location_count'] for x in supp),'max_supplemental_locations':max(x['scope']['location_count'] for x in supp),'current_location_attribute_imports_approved':False,'original_workload_owners_or_evidence_paths_changed':False,'existing_location_footprint_corrections':6,'existing_location_present_day_name_changes':3,'existing_location_ids_touched':9,'provenance_update_existing_ids':provenance_changes,'province_present_day_name_changes':2,'new_geographic_groups':8,'affected_region_contexts':len(region_contexts),'affected_region_details':region_contexts,'source_profiles_for_new_modern_sources_approved':False}
updated_manifest['validation']=proof;updated_manifest['input_hashes']={'candidate_hierarchy_sha256':sha((candidate/'hierarchy.json').read_bytes()),'candidate_world_index_sha256':sha((candidate/'world-index.json').read_bytes()),'original_triage_sha256':sha(Path(args.triage).read_bytes()),'actual_issue_snapshot_sha256':sha(Path(args.issues).read_bytes()),'original_registry_sha256':sha(Path(args.registry).read_bytes()),'composition_sha256':sha(Path(args.composition).read_bytes()),'crosswalk_sha256':sha(Path(args.crosswalk).read_bytes()),'handoffs_sha256':sha(Path(args.handoffs).read_bytes()) if args.handoffs else None}
plan={'version':1,'read_only':True,'recorded_at_utc':now.isoformat(),'recorded_on':date,'date_timezone':'America/Los_Angeles','publication_verified':publication_verified,'publication_gate':{'no_mutations_emitted_or_executed':True,'issue_number_links_resolved':bool(created),'required_before_execution':['Actual release4 committed/pushed, imported and hosted site confirms matching version/hierarchy/footprints','Final member-derived region envelopes/certificate generated and verified','Root supplies exact release/macro certificate and confirms location imports stay blocked','Refetch every target issue before mutation; compare current body SHA, comments/canonical active claim and preserve any late worker edits','Create supplemental issues idempotently, replace keys with actual issue numbers in umbrella links and approval work.depends_on','Update all427 existing bodies/pins only after publication gate; preserve canonical claims/PRs/comment history; active workers must revalidate affected subjects','Actual GitHub readback verifies273-packet/49623 exhaustive partition and all81approval dependencies; do not imply regional interior approval']},'release':release,'macro_certificate_sha256':cert,'proof':proof,'issue_creations':supp,'issue_updates':updates,'planned_durable_files':['data/macro-foundation/regional-handoffs.json.gz','data/macro-foundation/current-membership-inventory.json.gz','data/macro-foundation/queue-workload-v4.json.gz','data/macro-foundation/new-location-source-profiles-v4.json.gz','data/macro-foundation/queue-workload-v3.archive.json.gz','data/macro-foundation/queue-issue-body-v3.archive.json.gz'],'hold_and_unclosed_source_status':{'Kingman_Reef':'No valid source-land cell; explicit held omission, not approved location','Gardner_Pinnacles':'No valid source-land cell; explicit held omission, not approved location','Chagos':'Only compared modern DiegoGarcia+Salomon components; other named-atoll coverage open','Manuae_Aitutaki':'Present-day names corrected; partial existing footprints remain source-coverage review','global_world_shoreline_complete':False,'regional_interiors_approved':False,'history_attribute_imports_approved':False}}
files=[save(out,'queue-update-plan.json',plan),save(out,'queue-workload-v4.json',updated_manifest),save(out,'queue-member-inventory-v4.json',inventory),save(out,'queue-workload-v3.archive.json',m),save(out,'queue-issue-body-v3.archive.json',archive),save(out,'queue-partition-proof.json',proof),save(out,'new-location-source-profiles-v4.json',full_source_hints)]
receipt={'version':1,'read_only':True,'publication_verified':publication_verified,'files':files,'proof':proof};save(out,'receipt.json',receipt);print(json.dumps(receipt,indent=2))
