#!/usr/bin/env python3
"""Read-only paginated GitHub issue snapshot; no tokens in command output/files."""
import argparse,json,subprocess,gzip,hashlib,datetime
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--repository',default='ChengshuLi/WorldAtlas');ap.add_argument('--output',required=True);args=ap.parse_args()
raw=subprocess.check_output(['gh','api','--paginate',f'repos/{args.repository}/issues?state=all&per_page=100']).decode();dec=json.JSONDecoder();pages=[]
while raw.strip():
 raw=raw.lstrip();p,n=dec.raw_decode(raw);pages.append(p);raw=raw[n:]
issues=[{'number':i['number'],'body':i.get('body') or '', 'title':i['title'],'state':i['state'],'labels':[x['name'] for x in i['labels']],'updated_at':i['updated_at'],'comments':i['comments']} for page in pages for i in page if 'pull_request' not in i]
p=Path(args.output);p.parent.mkdir(parents=True,exist_ok=True);b=(json.dumps(issues,ensure_ascii=False,separators=(',',':'))+'\n').encode();p.write_bytes(gzip.compress(b,mtime=0) if p.name.endswith('.gz') else b)
print(json.dumps({'read_only':True,'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'path':str(p),'issues':len(issues),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
