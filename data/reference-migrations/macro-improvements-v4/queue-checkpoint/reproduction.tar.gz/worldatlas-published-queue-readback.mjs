// Read-only GitHub validator for the generated final queue migration. No API writes.
import fs from 'node:fs';import zlib from 'node:zlib';import crypto from 'node:crypto';import {execFile} from 'node:child_process';import {promisify} from 'node:util';
import {isDeepStrictEqual} from 'node:util';
const {workSpec,readClaim,githubPages}=await import((process.env.WORLDATLAS_QUEUE_CONTRACT_ROOT??'/workspace/WorldAtlas')+'/scripts/issue-claim-contract.mjs');
const dir=process.argv[2];if(!dir)throw Error('Pass final planner output directory');
const read=name=>JSON.parse(fs.readFileSync(dir+'/'+name)),plan=read('queue-update-plan.json'),inventory=read('queue-member-inventory-v4.json'),manifest=read('queue-workload-v4.json');
if(!plan.publication_verified||!plan.publication_gate.issue_number_links_resolved)throw Error('Final root-verified publication and created issue numbers required');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),run=promisify(execFile),errors=[],check=(v,msg)=>{if(!v)errors.push(msg);};
const api=async path=>JSON.parse((await run('gh',['api',path],{maxBuffer:96*1024*1024})).stdout),repo='ChengshuLi/WorldAtlas',issues=(await githubPages(api,`/repos/${repo}/issues?state=all`)).filter(i=>!i.pull_request),byN=new Map(issues.map(i=>[i.number,i])),groups=new Map(inventory.map(i=>[i.id,i])),scopes=[];let commentThreads=0,claims=0,activeClaims=0;
const blockScope=(body,id)=>[...body.matchAll(/```json\s*\n([\s\S]*?)\n```/g)].map(m=>{try{return JSON.parse(m[1]);}catch{return null;}}).find(s=>s?.batch_id===id);
for(const expected of plan.issue_updates){
 const actual=byN.get(expected.number);check(!!actual,`Missing #${expected.number}`);if(!actual)continue;
 const labels=actual.labels.map(l=>l.name),types=labels.filter(l=>l.startsWith('type:'));
 check(types.length===1,`#${actual.number}: needs one type`);
 check(actual.body.includes(plan.release.id)&&actual.body.includes(plan.macro_certificate_sha256),`#${actual.number}: stale release/certificate`);
 check(!actual.body.includes('REQUIRED_FROM_FINAL_')&&!actual.body.includes('REQUIRED_FINAL_'),`#${actual.number}: unresolved publication pin`);
 const expectedSpec=expected.role==='umbrella'?null:workSpec(expected.body);
 if(expected.role==='umbrella')check(labels.includes('type:geography')&&labels.includes('kind:umbrella')&&!labels.includes('status:ready'),`#${actual.number}: umbrella claimable/type wrong`);
 else{
  const got=workSpec(actual.body);check(JSON.stringify(got)===JSON.stringify(expectedSpec),`#${actual.number}: work mode/dependencies/owned scope differs`);
  if(expected.role==='approval')check(labels.includes('type:engineering')&&labels.includes('status:blocked')&&!labels.includes('status:ready'),`#${actual.number}: approval wrongly ready`);
  else{
   check(labels.includes('type:geography'),`#${actual.number}: packet type wrong`);
   const id=manifest.batches.find(b=>b.owned_evidence_path===expectedSpec.owned_paths[0])?.batch_id,scope=blockScope(actual.body,id),orig=manifest.batches.find(b=>b.batch_id===id);
   check(!!scope,`#${actual.number}: exact scope JSON missing`);if(scope){scopes.push(scope);check(JSON.stringify(scope.member_location_ids)===JSON.stringify(orig.member_location_ids)&&scope.member_location_ids_sha256===orig.member_location_ids_sha256,`#${actual.number}: original member IDs/hash modified`);check(isDeepStrictEqual(scope.release,plan.release),`#${actual.number}: scope release stale`);}
   if(labels.includes('status:ready'))for(const dep of got.depends_on)check(byN.get(dep)?.state==='closed',`#${actual.number}: open ready dependency #${dep}`);
  }
 }
}
for(const expected of plan.issue_creations){
 const actual=byN.get(expected.number);check(!!actual,`Missing supplemental #${expected.number}`);if(!actual)continue;
 const labels=actual.labels.map(l=>l.name),got=workSpec(actual.body),scope=blockScope(actual.body,expected.scope.batch_id);check(labels.includes('type:geography')&&!labels.includes('type:engineering')&&labels.includes('kind:work-item'),`#${actual.number}: supplemental type wrong`);
 check(got.mode==='geography'&&got.max_prs<=2&&JSON.stringify(got.owned_paths)===JSON.stringify([expected.scope.owned_evidence_path]),`#${actual.number}: supplemental work contract wrong`);
 check(!!scope,`#${actual.number}: supplemental scope missing`);if(scope){scopes.push(scope);check(JSON.stringify(scope.member_location_ids)===JSON.stringify(expected.scope.member_location_ids),`#${actual.number}: supplemental members differ`);check(isDeepStrictEqual(scope.release,plan.release),`#${actual.number}: supplemental scope release stale`);}
 const parent=byN.get(expected.parent_umbrella),approval=byN.get(expected.approval_issue);check(parent?.body.includes('#'+actual.number),`#${actual.number}: umbrella not linked`);check(approval&&workSpec(approval.body).depends_on.includes(actual.number),`#${actual.number}: approval missing new dependency`);
 if(labels.includes('status:ready'))for(const dep of got.depends_on)check(byN.get(dep)?.state==='closed',`#${actual.number}: open ready dependency #${dep}`);
}
const flat=scopes.flatMap(s=>s.member_location_ids),unitMembers=new Map();check(scopes.length===273,'Need 273 original+supplemental scopes');check(flat.length===49623&&new Set(flat).size===49623,'49,623 partition missing/duplicate');check(hash([...flat].sort().join('\n'))===plan.proof.member_location_ids_sha256,'Exhaustive member hash wrong');
for(const s of scopes){check(hash(s.member_location_ids.join('\n'))===s.member_location_ids_sha256,`${s.batch_id}: scope hash wrong`);const region=groups.get(s.region_id);check(s.member_location_ids.every(i=>region?.member_location_ids.includes(i)),`${s.batch_id}: region contains foreign members`);for(const tier of ['province_scopes','area_scopes'])for(const row of s[tier]){const g=groups.get(row.id),owned=s.member_location_ids.filter(i=>g?.member_location_ids.includes(i));check(!!g,`${s.batch_id}: missing parent ${row.id}`);const total=row.full_province_locations??row.full_area_location_count??row.full_current_location_count;check(total===g?.member_location_ids.length,`${s.batch_id}: current parent total stale ${row.id}`);if(!unitMembers.has(row.id))unitMembers.set(row.id,[]);unitMembers.get(row.id).push(...owned);}}
check([...unitMembers.keys()].filter(i=>groups.get(i)?.level==='area').length===480,'480 areas must be covered');check([...unitMembers.keys()].filter(i=>groups.get(i)?.level==='province').length===5138,'5,138 provinces must be covered');for(const [id,ids]of unitMembers)check(JSON.stringify(ids.sort())===JSON.stringify(groups.get(id).member_location_ids),`Parent membership duplicated/missing ${id}`);
// Claims/comments are read without overwriting; source-only history gates remain intact.
let commentNext=0;
async function commentWorker(){while(commentNext<issues.length){const actual=issues[commentNext++];
 const labels=actual.labels.map(l=>l.name);
 if(actual.state==='open'&&labels.includes('type:history-research')&&labels.includes('kind:work-item'))check(workSpec(actual.body).mode==='source-only',`#${actual.number}: premature history content mode`);
 if(actual.comments){commentThreads++;try{const c=readClaim(await githubPages(api,`/repos/${repo}/issues/${actual.number}/comments`));if(c){claims++;if(c.active){activeClaims++;check(c.issue_number===actual.number,`#${actual.number}: wrong claim issue`);}}}catch(e){errors.push(`#${actual.number}: canonical claim ${e.message}`);}}
}}
await Promise.all(Array.from({length:4},commentWorker));
const receipt={version:1,read_only:true,recorded_at_utc:new Date().toISOString(),publication_verified:true,github_issues_read:issues.length,issue_updates_checked:plan.issue_updates.length,original_packets:265,supplemental_packets:8,total_packets:scopes.length,locations:flat.length,unique_locations:new Set(flat).size,areas:480,provinces:5138,regions:81,comment_threads_read:commentThreads,canonical_claims:claims,active_claims:activeClaims,history_content_imports_approved:false,errors,pass:!errors.length};fs.writeFileSync(dir+'/actual-github-queue-readback.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));if(errors.length)process.exitCode=1;
