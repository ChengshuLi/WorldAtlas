Metadata Link: https://www.fisheries.noaa.gov/inport/q?keywords=UM0504
