<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="1.7.4-Wroclaw" minimumScale="0" maximumScale="1e+08" minLabelScale="0" maxLabelScale="1e+08" hasScaleBasedVisibilityFlag="0" scaleBasedLabelVisibilityFlag="0">
  <transparencyLevelInt>255</transparencyLevelInt>
  <singlesymbol>
    <symbol>
      <lowervalue></lowervalue>
      <uppervalue></uppervalue>
      <label></label>
      <pointsymbol>hard:circle</pointsymbol>
      <pointsize>2</pointsize>
      <pointsizeunits>pixels</pointsizeunits>
      <rotationclassificationfieldname></rotationclassificationfieldname>
      <scaleclassificationfieldname></scaleclassificationfieldname>
      <symbolfieldname></symbolfieldname>
      <outlinecolor red="0" blue="255" green="0"/>
      <outlinestyle>SolidLine</outlinestyle>
      <outlinewidth>0.36</outlinewidth>
      <fillcolor red="38" blue="253" green="43"/>
      <fillpattern>NoBrush</fillpattern>
      <texturepath>.</texturepath>
    </symbol>
  </singlesymbol>
  <customproperties/>
  <displayfield>ID</displayfield>
  <label>0</label>
  <labelattributes>
    <label fieldname="" text="Label"/>
    <family fieldname="" name="MS Shell Dlg 2"/>
    <size fieldname="" units="pt" value="12"/>
    <bold fieldname="" on="0"/>
    <italic fieldname="" on="0"/>
    <underline fieldname="" on="0"/>
    <strikeout fieldname="" on="0"/>
    <color fieldname="" red="0" blue="0" green="0"/>
    <x fieldname=""/>
    <y fieldname=""/>
    <offset x="0" y="0" units="pt" yfieldname="" xfieldname=""/>
    <angle fieldname="" value="0" auto="0"/>
    <alignment fieldname="" value="center"/>
    <buffercolor fieldname="" red="255" blue="255" green="255"/>
    <buffersize fieldname="" units="pt" value="1"/>
    <bufferenabled fieldname="" on=""/>
    <multilineenabled fieldname="" on=""/>
    <selectedonly on=""/>
  </labelattributes>
  <edittypes>
    <edittype type="0" name="EDITCODE"/>
    <edittype type="0" name="FEATURETYP"/>
    <edittype type="0" name="GRIDCODE"/>
    <edittype type="0" name="ID"/>
    <edittype type="0" name="NAME"/>
    <edittype type="0" name="OBJECTID"/>
    <edittype type="0" name="PID"/>
    <edittype type="0" name="REVISED"/>
    <edittype type="0" name="SHAPE_Area"/>
    <edittype type="0" name="SHAPE_Leng"/>
    <edittype type="0" name="STATE"/>
    <edittype type="0" name="SYMBOL"/>
  </edittypes>
  <editform>..</editform>
  <editforminit></editforminit>
  <annotationform>.</annotationform>
  <attributeactions/>
  <overlay display="false" type="diagram">
    <renderer item_interpretation="linear">
      <diagramitem size="0" value="0"/>
      <diagramitem size="0" value="0"/>
    </renderer>
    <factory sizeUnits="MM" type="Pie">
      <wellknownname>Pie</wellknownname>
      <classificationfield>0</classificationfield>
    </factory>
    <scalingAttribute>0</scalingAttribute>
  </overlay>
</qgis>
