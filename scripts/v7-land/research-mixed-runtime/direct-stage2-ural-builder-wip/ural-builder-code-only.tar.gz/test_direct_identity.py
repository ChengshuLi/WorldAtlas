import hashlib,importlib.util,json,tempfile,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=HERE/'runtime/v7-land/named-identity-prototype'
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
adapter=load('direct_identity_adapter',BASE/'identity_watch.py');old=load('old_identity',HERE.parent/'stage2-rss-runtime-20261105/v7-land/named-identity-prototype/named_identity.py')
class DirectIdentity(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.p=Path(self.t.name)/'source.json';self.g={'type':'Polygon','coordinates':[[[0,0],[2,0],[2,2],[0,2],[0,0]]]};self.feature={'type':'Feature','properties':{'id':'1','name':'Island','class':'island'},'geometry':self.g};self.data={'type':'FeatureCollection','features':[self.feature]};self.p.write_text(json.dumps(self.data));self.code=(BASE/'named_identity.py').read_bytes();self.r={'identity_path':str(self.p),'identity_sha256':hashlib.sha256(self.p.read_bytes()).hexdigest(),'point_geometry':{'type':'Point','coordinates':[1,1]},'island_identity':'Island','spec':{'method':'raw_named_polygon_contains_point_v1','identity_feature_id':'1','identity_id_property':'id','identity_name_property':'name','identity_class_property':'class','identity_class_value':'island','identity_geometry_sha256':old.geom_hash(self.g)}}
 def test_real_gdal_equal_old_core_without_memory_callback(self):
  def forbidden():raise AssertionError('memory callback must not be used')
  a=adapter.run(self.code,self.r,forbidden);b=old.check(self.data,self.r['point_geometry'],self.r['island_identity'],self.r['spec']);self.assertEqual(a['result'],b);self.assertEqual(a['memory_monitor'],{'mode':'direct-in-process','runtime_supervisor':'not-launched','runtime_memory_limit':'not-imposed','external_constraints':'not-assessed'})
 def test_wrong_source_hash_fails(self):
  self.r['identity_sha256']='0'*64
  with self.assertRaisesRegex(ValueError,'pin mismatch'):adapter.run(self.code,self.r)
 def test_boundary_point_fails(self):
  self.r['point_geometry']={'type':'Point','coordinates':[0,1]}
  with self.assertRaisesRegex(ValueError,'strictly inside'):adapter.run(self.code,self.r)
 def test_source_mutation_during_check_fails(self):
  code=b"def check(source,point,name,spec):\n from pathlib import Path\n Path("+repr(str(self.p)).encode()+b").write_text('{}')\n return {}\n"
  with self.assertRaisesRegex(ValueError,'changed during check'):adapter.run(code,self.r)
if __name__=='__main__':unittest.main()
