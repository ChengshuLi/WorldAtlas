import unittest
from test_baseline_runner import Runner
class DirectResume(Runner):
 def test_direct_failure_resume_matches_full_result(self):
  expected=self.runit();self.cp.unlink();calls=[0]
  def fail():
   calls[0]+=1
   if calls[0]>9:raise RuntimeError('injected failure')
  with self.assertRaisesRegex(RuntimeError,'injected failure'):self.runit(guard=fail)
  self.assertTrue(self.cp.exists())
  got=self.runit(True)
  self.assertEqual(got['codes'].tolist(),expected['codes'].tolist())
  self.assertEqual(got['roots'].tolist(),expected['roots'].tolist())
  self.assertEqual(got['exact_queries'],expected['exact_queries'])
  self.identity={'test':'changed'}
  with self.assertRaisesRegex(ValueError,'identity'):self.runit(True)
if __name__=='__main__':unittest.main()
