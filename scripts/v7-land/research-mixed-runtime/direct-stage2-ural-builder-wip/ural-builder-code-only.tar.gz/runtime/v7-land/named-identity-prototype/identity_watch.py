"""Direct, pinned identity-source adapter. No supervisor or memory limit."""
import hashlib,json,types

def run(checker_bytes,request,available=None):
    if not isinstance(checker_bytes,bytes) or len(checker_bytes)>8*1024*1024:
        raise ValueError('invalid checker code')
    if not isinstance(request,dict) or set(request)!={'identity_path','identity_sha256','point_geometry','island_identity','spec'}:
        raise ValueError('invalid identity request')
    path=request['identity_path'];expected=request['identity_sha256']
    with open(path,'rb') as f:raw=f.read(8*1024*1024+1)
    if len(raw)>8*1024*1024 or hashlib.sha256(raw).hexdigest()!=expected:
        raise ValueError('identity source pin mismatch')
    module=types.ModuleType('pinned_named_identity_direct')
    exec(compile(checker_bytes,'<pinned-named-identity>','exec'),module.__dict__)
    result=module.check(json.loads(raw),request['point_geometry'],request['island_identity'],request['spec'])
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    if h.hexdigest()!=expected:raise ValueError('identity source changed during check')
    return {'result':result,'memory_monitor':{'mode':'direct-in-process','runtime_supervisor':'not-launched','runtime_memory_limit':'not-imposed','external_constraints':'not-assessed'}}
