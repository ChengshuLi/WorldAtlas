"""Atomic rename that never replaces an existing destination."""
import ctypes,os,sys
libc=ctypes.CDLL(None,use_errno=True)
def move_noreplace(source,destination):
 src=os.fsencode(source);dst=os.fsencode(destination)
 if sys.platform.startswith('linux') and hasattr(libc,'renameat2'):
  fn=libc.renameat2;fn.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint];fn.restype=ctypes.c_int
  rc=fn(-100,src,-100,dst,1) # AT_FDCWD, RENAME_NOREPLACE
 elif sys.platform=='darwin' and hasattr(libc,'renamex_np'):
  fn=libc.renamex_np;fn.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_uint];fn.restype=ctypes.c_int
  rc=fn(src,dst,4) # RENAME_EXCL
 else:raise RuntimeError('atomic no-replace rename unavailable')
 if rc!=0:
  err=ctypes.get_errno();raise OSError(err,os.strerror(err),os.fsdecode(destination))
