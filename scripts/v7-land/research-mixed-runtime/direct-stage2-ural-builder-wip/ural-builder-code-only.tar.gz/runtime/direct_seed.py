"""Direct v2 seed execution and readback; research-only, no supervisor."""
import hashlib,importlib.util,json,os,subprocess,sys,tempfile
from pathlib import Path
import verify_inputs
HERE=Path(__file__).resolve().parent
DIRECT_SEED_FREEZE = {'seed_producer.py': '6a1e69411b25c67948c7b741b6330dc9e335c0b00688bad3a5bbc52247f151d3', 'export_adapter.py': 'e2874d45df5dff9e3a300f7e93f1fb1d1730196766d36dca14f0c629c62533c3', 'seed_rules.py': '0e98f77341b8f297b434d46250f2e8e9f615e6a3764cad176fe3cdf40c52f342', 'region_client.py': '1deb45ca74f48439543eac5955cf1e3544d1248aba94e709e240e883801c7321', 'region_worker.py': '3d7f14ba3df538fd35e40509e576faaf9b844ec3e4dbb3e8a8c8ddee062d5706', 'regions.py': 'd54df44cecddd76a9aae660112375b934700051d09b6facb6de0a9646a70c011', 'closure_client.py': '51007b2f0e8e4244974ef1b698ee47dcee8739f0a2d5ce04c56bd9c1fe92c1e6', 'panama_seed_source.py': 'f6edea70f22993241acbffcfd1d02eefaf7a9e60b00925e8afdfb5963b781655', 'osm_source_handoff.py': 'ef6bc620e447f38be3524bcebeba6b1fe309ab2a4ea7f507ccf38c3ef4d30add', 'assemble_osm_ways.py': 'b1edf136b05109dcfb080158f58dffe9f910c6c30b3a654721478453b64270e2', 'rasterizer/build_seed.py': '8b59d9212064ed7fcdde37ca9ad53a8b1544c0b2abad4b1e2ac3c30e49b193a1', 'rasterizer/seed_kernel.cpp': '1543a7014f84eb5969b073435d463e838922c186d996ec9dcb0f68133ac15fa8', 'closure-checkers/validate_water_closure_v2.py': '5b01e11908293df6f941adbc391d4c9e7709f49c1b8ad60d46be0558d66ca6b3', 'closure-checkers/validate_terminal_closure.py': '08fd855bddd47dd2152ae0ac0fabd1e23e1d75db9e337a0af3a840a6787e1cb2'}
DIRECT_SEED_FREEZE['ural_seed_source.py']='073a57da44a2ad330ac38e0068144f1e00ac9bd3e51dce3c43531e10b6cb28ea'
DIRECT_SEED_FREEZE['ural_producer_config.py']='9c041415e7a21723c7ceed887c647c4884d749e12a94f7b6ccc920d38912f3c9'
# The separately reviewed core source validator is an additional pinned dependency.
DIRECT_SEED_FREEZE['panama_core_validation.py']='c87ea27314b8db533e52fa2daf8ae98b2df1de3c9a4b0884d4efcbc874d9253a'
DIRECT_SEED_REPORTED = ('seed_producer.py','export_adapter.py','seed_rules.py','region_client.py','region_worker.py','regions.py','closure_client.py','panama_seed_source.py','osm_source_handoff.py','assemble_osm_ways.py','ural_seed_source.py','ural_producer_config.py')
def need(v,msg):
 if not v:raise ValueError(msg)
def unique(pairs):
 d={}
 for k,v in pairs:
  need(k not in d,'duplicate JSON key');d[k]=v
 return d
def invalid_constant(value):raise ValueError('non-finite JSON constant')
def read_json(raw):return json.loads(raw,object_pairs_hook=unique,parse_constant=invalid_constant)
def validate_ural_config(config):
 keys={'recipe_dir','inputs_dir','helpers_dir','work_parent','inventories','python','dependency_dirs'}
 need(isinstance(config,dict) and set(config)==keys,'invalid Ural configuration')
 def absolute(p):return isinstance(p,str) and bool(p) and Path(p).is_absolute()
 def digest(s):return isinstance(s,str) and len(s)==64 and all(c in '0123456789abcdef' for c in s)
 def pin(p):return isinstance(p,dict) and set(p)=={'path','sha256'} and absolute(p['path']) and digest(p['sha256'])
 for name in ('recipe_dir','inputs_dir','helpers_dir','work_parent'):need(absolute(config[name]),'Ural paths must be absolute')
 need(pin(config['python']),'invalid Ural Python pin')
 deps=config['dependency_dirs'];need(isinstance(deps,list) and 1<=len(deps)<=8 and all(pin(p) for p in deps),'invalid Ural dependency pins')
 inventories=config['inventories'];names={'recipe_dir','inputs_dir','helpers_dir'}
 need(isinstance(inventories,dict) and set(inventories)==names,'invalid Ural inventories')
 for inventory in inventories.values():
  need(isinstance(inventory,dict) and 1<=len(inventory)<=10000,'invalid Ural inventory')
  for path,sha in inventory.items():
   need(isinstance(path,str) and bool(path) and not path.startswith('/') and all(x not in ('','.','..') for x in path.split('/')) and digest(sha),'invalid Ural inventory item')
 return config

def ural_paths(config):
 validate_ural_config(config)
 dirs=[Path(config[k]).resolve(strict=True) for k in ('recipe_dir','inputs_dir','helpers_dir','work_parent')]
 dirs.extend(Path(x['path']).resolve(strict=True) for x in config['dependency_dirs'])
 executable=Path(config['python']['path']).resolve(strict=True)
 need(all(p.is_dir() for p in dirs) and executable.is_file(),'invalid Ural source paths')
 return [*dirs,executable]

def require_disjoint_ural(config,work,output,extra_paths=()):
 targets=[work,output,*(Path(x).resolve() for x in extra_paths)]
 for p in ural_paths(config):
  need(all(not t.is_relative_to(p) and not p.is_relative_to(t) for t in targets),'work/output overlaps Ural source or runtime')

def request(grid,inputs,strip_rows,ural_source=None):
 required={'snapshot','resolution','physical_rows','physical_runs','physical_report','component_rows','component_runs','component_manifest','closure_checker','terminal_checker','closure_contract','seed_builder','seed_kernel'}
 optional={'panama_osm_archive'}
 need(isinstance(inputs,dict) and required<=set(inputs) and set(inputs)<=required|optional,'invalid direct seed input set')
 need(isinstance(grid,dict) and set(grid)=={'width','height','west','north','step'},'invalid direct seed grid')
 need(type(strip_rows) is int and strip_rows>0,'invalid direct seed strip rows')
 for p in inputs.values():need(isinstance(p,dict) and set(p)=={'path','sha256'} and isinstance(p['path'],str) and p['path'] and isinstance(p['sha256'],str) and len(p['sha256'])==64 and all(x in '0123456789abcdef' for x in p['sha256']),'invalid direct seed input pin')
 result={'schema':'worldatlas-stage2-seed-direct-request-v2','grid':grid,'inputs':inputs,'controls':{'strip_rows':strip_rows}}
 if ural_source is not None:result['ural_source']=validate_ural_config(ural_source)
 return result
def code_check(guard):
 directory=HERE/'seed-producer-direct'
 for name,expected in DIRECT_SEED_FREEZE.items():need(verify_inputs.sha_file(directory/name,guard)==expected,'direct seed code changed: '+name)
def inputs_check(q,guard):
 for spec in q['inputs'].values():
  need(Path(spec['path']).is_absolute(),'direct seed input path must be absolute')
  need(verify_inputs.sha_file(spec['path'],guard)==spec['sha256'],'input hash mismatch: '+spec['path'])
def load_request(path,guard):
 raw=verify_inputs.bounded_bytes(path,1<<20,guard);q=read_json(raw)
 need(q==request(q.get('grid'),q.get('inputs'),q.get('controls',{}).get('strip_rows'),q.get('ural_source')),'invalid direct seed request')
 for key,name in (('seed_builder','rasterizer/build_seed.py'),('seed_kernel','rasterizer/seed_kernel.cpp'),('closure_checker','closure-checkers/validate_water_closure_v2.py'),('terminal_checker','closure-checkers/validate_terminal_closure.py')):need(q['inputs'][key]['sha256']==DIRECT_SEED_FREEZE[name],'unreviewed direct seed executable: '+key)
 return raw,q
def verify_result(request_path,output,guard=lambda:None):
 request_path=Path(request_path).resolve(strict=True);output=Path(output).resolve(strict=True)
 raw,q=load_request(request_path,guard);code_check(guard);inputs_check(q,guard)
 report_path=output/'report.json';report_raw=verify_inputs.bounded_bytes(report_path,16<<20,guard);report=read_json(report_raw)
 expected_code={n:DIRECT_SEED_FREEZE[n] for n in DIRECT_SEED_REPORTED};expected_code.update({'rasterizer':DIRECT_SEED_FREEZE['rasterizer/build_seed.py'],'rasterizer_kernel':DIRECT_SEED_FREEZE['rasterizer/seed_kernel.cpp']})
 need(report.get('schema')=='worldatlas-stage2-mainland-seed-report-v1' and report.get('status')=='diagnostic-seed-pending-independent-provenance' and report.get('publishable') is False and report.get('execution')=={'mode':'direct','strip_rows':q['controls']['strip_rows']} and report.get('grid')==q['grid'] and report.get('request_sha256')==hashlib.sha256(raw).hexdigest() and report.get('input_sha256')=={k:v['sha256'] for k,v in q['inputs'].items()} and report.get('code_sha256')==expected_code,'direct seed report binding mismatch')
 for field,key in (('decision_snapshot_sha256','snapshot'),('resolution_report_sha256','resolution'),('physical_rows_sha256','physical_rows'),('physical_runs_sha256','physical_runs'),('physical_report_sha256','physical_report'),('component_rows_sha256','component_rows'),('component_runs_sha256','component_runs'),('component_manifest_sha256','component_manifest')):need(report.get(field)==q['inputs'][key]['sha256'],'direct seed named input mismatch: '+field)
 for key,name in (('seed_rows_sha256','rows.u32le'),('seed_runs_sha256','runs.u32le'),('rasterizer_report_sha256','rasterizer-report.json')):need(report.get(key)==verify_inputs.sha_file(output/name,guard),'direct seed output mismatch')
 code_check(guard);inputs_check(q,guard);need(verify_inputs.bounded_bytes(request_path,1<<20,guard)==raw and verify_inputs.bounded_bytes(report_path,16<<20,guard)==report_raw,'direct seed request or report changed')
 return q,report
def check_runtime(caucasus=False):
 def module_root(name):
  spec=importlib.util.find_spec(name);need(spec is not None and spec.origin,name+' Python package unavailable');p=Path(spec.origin).resolve();return str(p.parent.parent if p.name=='__init__.py' else p.parent)
 return module_root('osgeo'),([module_root(x) for x in ('shapely','shapefile','pyproj')] if caucasus else [])
def invoke(request_path,work,output,guard=lambda:None,*,caucasus=None):
 directory=HERE/'seed-producer-direct';request_path=Path(request_path).resolve(strict=True);work=Path(work).resolve();output=Path(output).resolve()
 raw,q=load_request(request_path,guard);code_check(guard);inputs_check(q,guard)
 need(not work.exists() and not output.exists() and work.parent.is_dir() and output.parent.is_dir(),'direct seed work/output already exists or parent missing')
 gdal_root,gate_roots=check_runtime(caucasus is not None);gate_report=None;gate_cfg=None;gate_dir=None
 if caucasus is not None:
  need(isinstance(caucasus,dict) and set(caucasus)=={'config','directory','report'},'invalid Caucasus gate input')
  gate_cfg=caucasus['config'];gate_dir=Path(caucasus['directory']).resolve(strict=True);gate_report=Path(caucasus['report']).resolve()
  names={'caucasus_stage2_validation.py','caucasus_effective_snapshot.py','caucasus_seed_gate.py','caucasus_source_assembly.py','caucasus_compact_selectors.py','caucasus_selector_replay.py','caucasus_stage2_binding.py'}
  need(isinstance(gate_cfg,dict) and set(gate_cfg)=={'recipe','hydro','author','code_sha256'} and isinstance(gate_cfg['code_sha256'],dict) and set(gate_cfg['code_sha256'])==names and not gate_report.exists() and gate_report.parent.is_dir(),'invalid Caucasus gate configuration')
  for name,digest in gate_cfg['code_sha256'].items():need(verify_inputs.sha_file(gate_dir/name,guard)==digest,'Caucasus gate code mismatch: '+name)
  for key in ('recipe','hydro','author'):
   pin=gate_cfg[key];need(isinstance(pin,dict) and set(pin)=={'path','sha256'} and Path(pin['path']).is_absolute() and verify_inputs.sha_file(pin['path'],guard)==pin['sha256'],'Caucasus gate input mismatch: '+key)
 started=False
 try:
  with tempfile.TemporaryDirectory(prefix='.direct-seed-code-',dir=work.parent) as temp:
   snap=Path(temp);seed_dir=snap/'seed';seed_dir.mkdir()
   for name,expected in DIRECT_SEED_FREEZE.items():
    data=verify_inputs.bounded_bytes(directory/name,1<<20,guard);need(hashlib.sha256(data).hexdigest()==expected,'direct seed code changed during capture: '+name);dest=seed_dir/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
   env={k:v for k,v in os.environ.items() if not k.upper().startswith('PYTHON')};env['PYTHONNOUSERSITE']='1'
   if gate_cfg is None:
    boot="import importlib.util,sys\np=sys.argv[1]\nsys.path[:0]=[p,sys.argv[2]]\nnames="+repr(tuple(n[:-3] for n in DIRECT_SEED_REPORTED if n.endswith('.py')))+"\nif any(n in sys.modules for n in names): raise RuntimeError('seed module already loaded')\ns=importlib.util.spec_from_file_location('seed_producer',p+'/seed_producer.py')\nm=importlib.util.module_from_spec(s)\nsys.modules['seed_producer']=m\ns.loader.exec_module(m)\nm.run(*sys.argv[3:])"
    cmd=[sys.executable,'-I','-S','-c',boot,str(seed_dir),gdal_root,str(request_path),str(work),str(output)]
   else:
    gate_snap=snap/'caucasus';gate_snap.mkdir()
    for name,expected in gate_cfg['code_sha256'].items():
     data=verify_inputs.bounded_bytes(gate_dir/name,1<<20,guard);need(hashlib.sha256(data).hexdigest()==expected,'Caucasus code changed during capture: '+name);(gate_snap/name).write_bytes(data)
    gate_json=snap/'gate-config.json';gate_raw=json.dumps(gate_cfg,sort_keys=True,allow_nan=False).encode();gate_json.write_bytes(gate_raw)
    boot="import json,sys\np=sys.argv[1]\nsys.path[:0]=[p]+json.loads(sys.argv[2])\nfrom caucasus_stage2_binding import run_seed\nc=json.load(open(sys.argv[3]))\nrun_seed(c,sys.argv[4],sys.argv[5],sys.argv[6],sys.argv[7],sys.argv[8],sys.argv[9],sys.argv[10])"
    cmd=[sys.executable,'-I','-S','-c',boot,str(gate_snap),json.dumps([gdal_root,*gate_roots]),str(gate_json),str(request_path),hashlib.sha256(raw).hexdigest(),str(seed_dir),DIRECT_SEED_FREEZE['seed_producer.py'],str(work),str(output),str(gate_report)]
   started=True;subprocess.run(cmd,cwd=snap,env=env,check=True)
   for name,expected in DIRECT_SEED_FREEZE.items():need(verify_inputs.sha_file(seed_dir/name,guard)==expected,'captured direct seed code changed: '+name)
   if gate_cfg is not None:
    need(gate_json.read_bytes()==gate_raw,'Caucasus gate configuration changed')
    for name,expected in gate_cfg['code_sha256'].items():need(verify_inputs.sha_file(gate_snap/name,guard)==expected and verify_inputs.sha_file(gate_dir/name,guard)==expected,'Caucasus code changed: '+name)
    for key in ('recipe','hydro','author'):need(verify_inputs.sha_file(gate_cfg[key]['path'],guard)==gate_cfg[key]['sha256'],'Caucasus input changed: '+key)
    g=read_json(verify_inputs.bounded_bytes(gate_report,16<<20,guard));need(g.get('request_sha256')==hashlib.sha256(raw).hexdigest() and g.get('seed_producer_executed') is True and g.get('seed_producer_sha256')==DIRECT_SEED_FREEZE['seed_producer.py'],'Caucasus gate report mismatch')
  q2,report=verify_result(request_path,output,guard);need(q2==q and verify_inputs.bounded_bytes(request_path,1<<20,guard)==raw,'direct seed request changed')
  return report
 except Exception as exc:
  if started and (work.exists() or output.exists() or (gate_report is not None and gate_report.exists())):raise RuntimeError('direct seed work, output or gate report may exist; inspect before retrying') from exc
  raise

def verify_panama_source(request_path,output,guard=lambda:None):
 """Re-execute the selected Panama source binder against pinned bytes.

 This is a source-consistency check, not independent geographic or historical
 construction proof. It uses the same reviewed binder in a fresh isolated process.
 """
 request_path=Path(request_path).resolve(strict=True);raw,q=load_request(request_path,guard);q2,report=verify_result(request_path,output,guard);need(q==q2,'direct seed request mismatch')
 need('panama_osm_archive' in q['inputs'],'selected Panama archive missing')
 spec=importlib.util.find_spec('osgeo');need(spec is not None and spec.origin,'GDAL Python package unavailable');gdal_root=str(Path(spec.origin).resolve().parent.parent)
 directory=HERE/'seed-producer-direct';code_check(guard);inputs_check(q,guard)
 # Keep capture outside all replay inputs even when TMPDIR points into them.
 capture_parent=Path(output).resolve(strict=True).parent
 if q.get('ural_source') is not None:require_disjoint_ural(q['ural_source'],capture_parent,Path(output).resolve())
 with tempfile.TemporaryDirectory(prefix='.direct-panama-source-',dir=capture_parent) as temp:
  snap=Path(temp)
  for name,expected in DIRECT_SEED_FREEZE.items():
   data=verify_inputs.bounded_bytes(directory/name,1<<20,guard);need(hashlib.sha256(data).hexdigest()==expected,'direct seed code changed during capture: '+name);dest=snap/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  boot="import json,sys\np=sys.argv[1]\nsys.path[:0]=[p,sys.argv[2]]\nfrom export_adapter import load_pinned_snapshot\nfrom panama_core_validation import validate_panama_source\nq=json.load(open(sys.argv[3]))\ns=load_pinned_snapshot(q['inputs']['snapshot']['path'],q['inputs']['snapshot']['sha256'],lambda:None)\nr=json.load(open(sys.argv[4]))\nt=validate_panama_source(s,q['inputs']['snapshot']['sha256'],r,q['inputs']['panama_osm_archive'])\nprint(json.dumps(t,sort_keys=True,allow_nan=False))"
  env={k:v for k,v in os.environ.items() if not k.upper().startswith('PYTHON')};env['PYTHONNOUSERSITE']='1'
  result=subprocess.run([sys.executable,'-I','-S','-c',boot,str(snap),gdal_root,str(request_path),str(Path(output).resolve()/'report.json')],cwd=snap,env=env,check=False,capture_output=True,text=True)
  need(result.returncode==0,'Panama source validation rejected: '+result.stderr[-4096:])
  need(len(result.stdout.encode('utf-8'))<=1<<20,'Panama source trace too large');trace=read_json(result.stdout)
  for name,expected in DIRECT_SEED_FREEZE.items():need(verify_inputs.sha_file(snap/name,guard)==expected,'captured direct seed code changed: '+name)
 need(trace is not None and trace==report.get('panama_source_trace'),'Panama source trace mismatch')
 code_check(guard);inputs_check(q,guard);need(verify_inputs.bounded_bytes(request_path,1<<20,guard)==raw,'direct seed request changed')
 return trace

def verify_ural_source(request_path,output,guard=lambda:None):
 """Replay the complete pinned Ural source contract in a no-site subprocess.

 This is a consistency check, not scientific validation or proof of the
 historical physical-mask producer. The caller authenticates the snapshot.
 """
 request_path=Path(request_path).resolve(strict=True);output=Path(output).resolve(strict=True)
 raw,q=load_request(request_path,guard);q2,report=verify_result(request_path,output,guard)
 need(q==q2,'Ural source request mismatch')
 config=q.get('ural_source');expected=report.get('ural_source_trace')
 if config is None:
  need(expected is None,'unexpected Ural trace without source request')
  snapshot=read_json(verify_inputs.bounded_bytes(q['inputs']['snapshot']['path'],16<<20,guard))
  boundaries=snapshot.get('mainland_boundaries') if isinstance(snapshot,dict) else None
  need(isinstance(boundaries,list) and all(isinstance(x,dict) for x in boundaries),'invalid selected boundary records')
  need(not any(x.get('boundary_id')=='ural_kara_coast_to_caspian' for x in boundaries),'selected Ural boundary requires source replay')
  inputs_check(q,guard)
  return None
 need(isinstance(expected,dict),'missing Ural source trace')
 spec=importlib.util.find_spec('osgeo');need(spec is not None and spec.origin,'GDAL Python package unavailable')
 gdal_root=str(Path(spec.origin).resolve().parent.parent)
 directory=HERE/'seed-producer-direct';code_check(guard);inputs_check(q,guard)
 # A system temporary directory may itself be a pinned replay input or the
 # Ural work parent. Capture next to the seed output only after proving that
 # parent is disjoint from all replay paths and runtime dependencies.
 capture_parent=output.parent
 require_disjoint_ural(config,capture_parent,output)
 with tempfile.TemporaryDirectory(prefix='.direct-ural-source-',dir=capture_parent) as temp:
  snap=Path(temp)
  for name,digest in DIRECT_SEED_FREEZE.items():
   data=verify_inputs.bounded_bytes(directory/name,1<<20,guard);need(hashlib.sha256(data).hexdigest()==digest,'direct seed code changed during capture: '+name)
   dest=snap/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  boot="""import json,sys
from pathlib import Path
p=sys.argv[1];sys.path[:0]=[p,sys.argv[2]]
from closure_client import sha
from export_adapter import load_pinned_snapshot,boundary_records
from ural_producer_config import prepare,validate_ural_relationship_scope
from ural_seed_source import verify_trace
q=json.load(open(sys.argv[3]));report=json.load(open(sys.argv[4]));out=Path(sys.argv[5]).resolve()
inputs=q['inputs'];sources={Path(x['path']).resolve().parent for x in inputs.values()}|{Path(sys.argv[3]).resolve().parent,Path(p).resolve()}
pin,check=prepare(q['ural_source'],inputs['snapshot'],[out/'__no_work__',out,*sources],sha,lambda:None)
snapshot=load_pinned_snapshot(inputs['snapshot']['path'],inputs['snapshot']['sha256'],lambda:None)
_,_,boundaries,catalog=boundary_records(snapshot);validate_ural_relationship_scope(boundaries)
trace=verify_trace(boundaries,catalog,pin,report['ural_source_trace']);check()
print(json.dumps(trace,sort_keys=True,allow_nan=False))
"""
  env={k:v for k,v in os.environ.items() if not k.upper().startswith('PYTHON')};env['PYTHONNOUSERSITE']='1'
  result=subprocess.run([sys.executable,'-I','-S','-B','-c',boot,str(snap),gdal_root,str(request_path),str(output/'report.json'),str(output)],cwd=snap,env=env,check=False,capture_output=True,text=True)
  need(result.returncode==0,'Ural source replay rejected: '+result.stderr[-4096:])
  need(len(result.stdout.encode('utf-8'))<=1<<20,'Ural source trace too large');trace=read_json(result.stdout)
  for name,digest in DIRECT_SEED_FREEZE.items():need(verify_inputs.sha_file(snap/name,guard)==digest,'captured direct seed code changed: '+name)
 need(trace==expected,'Ural source trace mismatch')
 code_check(guard);inputs_check(q,guard);need(verify_inputs.bounded_bytes(request_path,1<<20,guard)==raw,'direct seed request changed')
 q3,report3=verify_result(request_path,output,guard);need(q3==q and report3==report,'Ural request or report changed during replay')
 return trace
