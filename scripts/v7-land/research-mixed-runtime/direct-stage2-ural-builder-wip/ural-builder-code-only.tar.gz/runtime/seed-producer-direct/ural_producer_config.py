"""Pin a complete Ural replay input tree for a direct research seed run.

The pinned inventory covers every regular file under each replay directory.
It is an additional check, not a replacement for the gate's source validation
or independent review of executable and dependency integrity.
"""
import re
from pathlib import Path

_KEYS = ('recipe_dir', 'inputs_dir', 'helpers_dir')
_DIGEST = re.compile(r'[0-9a-f]{64}\Z')

def _overlap(a, b):
 return a == b or a in b.parents or b in a.parents

def prepare(config, snapshot_pin, protected, sha, guard):
 if config is None:
  return None, None
 if not isinstance(config, dict) or set(config) != set(_KEYS) | {'work_parent', 'inventories', 'python', 'dependency_dirs'}:
  raise ValueError('invalid Ural replay configuration')
 inventories = config['inventories']
 if not isinstance(inventories, dict) or set(inventories) != set(_KEYS):
  raise ValueError('invalid Ural inventories')
 paths = {}
 for key in (*_KEYS, 'work_parent'):
  if not isinstance(config[key], str) or not config[key]: raise ValueError('invalid Ural replay path')
  path = Path(config[key]).resolve(strict=True)
  if not path.is_dir(): raise ValueError('Ural replay path is not a directory')
  paths[key] = path
 python_pin=config['python']; dependencies=config['dependency_dirs']
 def valid_pin(pin):
  return isinstance(pin,dict) and set(pin)=={'path','sha256'} and isinstance(pin['path'],str) and bool(pin['path']) and isinstance(pin['sha256'],str) and bool(_DIGEST.fullmatch(pin['sha256']))
 if not valid_pin(python_pin) or not isinstance(dependencies,list) or not 1<=len(dependencies)<=8 or not all(valid_pin(d) for d in dependencies):
  raise ValueError('invalid Ural runtime pins')
 executable=Path(python_pin['path']).resolve(strict=True)
 if not executable.is_file(): raise ValueError('invalid Ural executable')
 dep_paths=[Path(d['path']).resolve(strict=True) for d in dependencies]
 if not all(p.is_dir() for p in dep_paths): raise ValueError('invalid Ural dependency directory')
 # Explicitly disallow nesting among all replay paths, including scratch.
 all_paths = list(paths.values())+dep_paths
 if any(_overlap(a,b) for i,a in enumerate(all_paths) for b in all_paths[i+1:]):
  raise ValueError('Ural replay paths overlap')
 if any(_overlap(executable,p) for p in (paths['work_parent'],*protected[:2])):
  raise ValueError('Ural executable overlaps work/output')
 if any(_overlap(paths['work_parent'],p) for p in protected):
  raise ValueError('Ural replay work overlaps seed paths')
 # Seed work and output must not overlap any replay input path.
 if any(_overlap(d,p) for d in [*(paths[k] for k in _KEYS),*dep_paths] for p in protected[:2]):
  raise ValueError('seed work/output overlaps Ural inputs')
 def check():
  from ural_seed_source import dependency_tree_sha256
  if sha(executable,guard)!=python_pin['sha256']: raise ValueError('Ural Python executable pin mismatch')
  # The upstream tree-hash routine uses os.walk; explicitly surface scan
  # errors rather than accepting an unreadable subtree as absent.
  import os
  def walk_error(error): raise error
  for path in dep_paths:
   for _ in os.walk(path,followlinks=False,onerror=walk_error): pass
  if any(dependency_tree_sha256(path)!=pin['sha256'] for path,pin in zip(dep_paths,dependencies)): raise ValueError('Ural dependency tree pin mismatch')
  for key in _KEYS:
   expected=inventories[key]
   if not isinstance(expected, dict) or not expected or len(expected)>10000:
    raise ValueError('invalid Ural inventory')
   for name,digest in expected.items():
    if not isinstance(name,str) or not name or name.startswith('/') or any(x in ('','.','..') for x in name.split('/')) or not isinstance(digest,str) or not _DIGEST.fullmatch(digest):
     raise ValueError('invalid Ural inventory entry')
   actual={}
   # Do not follow symlinks, including symlinked directories or special files.
   import os
   def walk_error(error): raise error
   for root,dirs,files in os.walk(paths[key],followlinks=False,onerror=walk_error):
    if any((Path(root)/d).is_symlink() for d in dirs): raise ValueError('Ural inventory contains symlink')
    for name in files:
     file=Path(root)/name
     if file.is_symlink() or not file.is_file(): raise ValueError('Ural inventory contains non-regular file')
     rel=file.relative_to(paths[key]).as_posix()
     if rel not in expected: raise ValueError('Ural inventory has unexpected file')
     actual[rel]=sha(file,guard)
     if len(actual)>10000: raise ValueError('Ural inventory too large')
   if actual!=expected: raise ValueError('Ural inventory mismatch')
 check()
 return {**{k:str(v) for k,v in paths.items()},'snapshot':snapshot_pin['path'],'snapshot_sha256':snapshot_pin['sha256'],'python':{'path':str(executable),'sha256':python_pin['sha256']},'dependency_dirs':[{'path':str(path),'sha256':pin['sha256']} for path,pin in zip(dep_paths,dependencies)]}, check


def validate_ural_relationship_scope(boundaries):
 # Role vocabulary is boundary-specific, even if the shared adapter recognizes
 # these relationships globally. Check every selected boundary, not only those
 # used by a particular region.
 from regions import URAL_CONSTRUCTION_INPUTS
 from ural_seed_source import BOUNDARY
 for (kind, boundary_id), record in boundaries.items():
  if kind == 'boundary' and boundary_id != BOUNDARY:
   if any(ref.get('relationship') in URAL_CONSTRUCTION_INPUTS for ref in record.get('qualified_source_refs', [])):
    raise ValueError('Ural construction relationship on non-Ural boundary')
