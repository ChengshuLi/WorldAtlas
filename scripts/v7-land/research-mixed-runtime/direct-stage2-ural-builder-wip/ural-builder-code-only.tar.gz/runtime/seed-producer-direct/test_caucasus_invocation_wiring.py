"""Bounded fake-process tests for the disabled Caucasus/direct seed wiring."""
import hashlib,json,pathlib,unittest
from types import SimpleNamespace
from unittest import mock
import direct_seed
import test_seed_producer as fixture
HERE=pathlib.Path(__file__).resolve().parent
GATE=HERE.parent.parent/'caucasus-audit'
class CaucasusInvocation(unittest.TestCase):
 def setUp(self):
  self.case=fixture.Producer('test_runs_from_selected_structured_inputs');self.case.setUp();self.addCleanup(self.case.doCleanups);self.q=self.case.req
  for key,name in (('closure_checker','closure-checkers/validate_water_closure_v2.py'),('terminal_checker','closure-checkers/validate_terminal_closure.py')):self.q['inputs'][key]=fixture.pin(HERE/name)
  self.case.path.write_text(json.dumps(self.q));names=('caucasus_stage2_validation.py','caucasus_effective_snapshot.py','caucasus_seed_gate.py','caucasus_source_assembly.py','caucasus_compact_selectors.py','caucasus_selector_replay.py','caucasus_stage2_binding.py')
  self.cfg={'code_sha256':{n:fixture.sha(GATE/n) for n in names}}
  for name in ('recipe','hydro','author'):
   p=self.case.d/name;p.write_text(name);self.cfg[name]=fixture.pin(p)
  self.gate_report=self.case.d/'gate-report.json';self.gate={'config':self.cfg,'directory':str(GATE),'report':str(self.gate_report)};self.called=0
 def fake_run(self,cmd,**kwargs):
  self.called+=1;self.assertEqual(cmd[1:3],['-I','-S']);self.assertNotIn('PYTHONPATH',kwargs['env']);self.assertEqual(kwargs['env']['PYTHONNOUSERSITE'],'1')
  work,out,gate=map(pathlib.Path,cmd[-3:]);work.mkdir();out.mkdir();rows=b'rows';runs=b'runs';raster=b'raster';(out/'rows.u32le').write_bytes(rows);(out/'runs.u32le').write_bytes(runs);(out/'rasterizer-report.json').write_bytes(raster)
  h=lambda b:hashlib.sha256(b).hexdigest();raw=self.case.path.read_bytes();code={n:direct_seed.DIRECT_SEED_FREEZE[n] for n in direct_seed.DIRECT_SEED_REPORTED};code.update({'rasterizer':direct_seed.DIRECT_SEED_FREEZE['rasterizer/build_seed.py'],'rasterizer_kernel':direct_seed.DIRECT_SEED_FREEZE['rasterizer/seed_kernel.cpp']})
  report={'schema':'worldatlas-stage2-mainland-seed-report-v1','status':'diagnostic-seed-pending-independent-provenance','publishable':False,'grid':self.q['grid'],'execution':{'mode':'direct','strip_rows':self.q['controls']['strip_rows']},'request_sha256':h(raw),'input_sha256':{k:v['sha256'] for k,v in self.q['inputs'].items()},'code_sha256':code,'seed_rows_sha256':h(rows),'seed_runs_sha256':h(runs),'rasterizer_report_sha256':h(raster)}
  for field,key in (('decision_snapshot_sha256','snapshot'),('resolution_report_sha256','resolution'),('physical_rows_sha256','physical_rows'),('physical_runs_sha256','physical_runs'),('physical_report_sha256','physical_report'),('component_rows_sha256','component_rows'),('component_runs_sha256','component_runs'),('component_manifest_sha256','component_manifest')):report[field]=self.q['inputs'][key]['sha256']
  (out/'report.json').write_text(json.dumps(report));gate.write_text(json.dumps({'request_sha256':h(raw),'seed_producer_executed':True,'seed_producer_sha256':direct_seed.DIRECT_SEED_FREEZE['seed_producer.py']}));return SimpleNamespace(returncode=0)
 def run_fake(self):
  with mock.patch.object(direct_seed.importlib.util,'find_spec',return_value=SimpleNamespace(origin='/tmp/mocksite/pkg/__init__.py')),mock.patch.object(direct_seed.subprocess,'run',side_effect=self.fake_run):return direct_seed.invoke(self.case.path,self.case.work,self.case.output,caucasus=self.gate)
 def test_fake_gate_binds_direct_call(self):
  result=self.run_fake();self.assertEqual(self.called,1);self.assertEqual(result['execution']['mode'],'direct');self.assertTrue(self.gate_report.exists())
 def test_changed_gate_source_rejected_before_work(self):
  pathlib.Path(self.cfg['recipe']['path']).write_text('changed')
  with self.assertRaisesRegex(ValueError,'Caucasus gate input mismatch'):self.run_fake()
  self.assertEqual(self.called,0);self.assertFalse(self.case.work.exists());self.assertFalse(self.case.output.exists())
 def test_changed_gate_code_rejected_before_work(self):
  self.cfg['code_sha256']['caucasus_seed_gate.py']='0'*64
  with self.assertRaisesRegex(ValueError,'Caucasus gate code mismatch'):self.run_fake()
  self.assertEqual(self.called,0);self.assertFalse(self.gate_report.exists())
if __name__=='__main__':unittest.main()
