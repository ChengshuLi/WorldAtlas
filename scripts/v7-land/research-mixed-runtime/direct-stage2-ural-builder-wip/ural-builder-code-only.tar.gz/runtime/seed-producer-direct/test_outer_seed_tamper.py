"""Bounded unit checks of the unwired direct invocation's revalidation."""
import hashlib,json,pathlib,unittest
from unittest import mock
import orchestrate_stage2 as outer
import test_seed_producer as fixtures
HERE=pathlib.Path(__file__).resolve().parent
class OuterSeedTamper(unittest.TestCase):
 def setUp(self):
  self.case=fixtures.Producer('test_runs_from_selected_structured_inputs');self.case.setUp();self.addCleanup(self.case.doCleanups)
  self.q=self.case.req
  for k,name in (('closure_checker','closure-checkers/validate_water_closure_v2.py'),('terminal_checker','closure-checkers/validate_terminal_closure.py')):self.q['inputs'][k]=fixtures.pin(HERE/name)
  self.case.path.write_text(json.dumps(self.q));self.mode=None
 def fake_run(self,cmd,**kwargs):
  out=pathlib.Path(cmd[-1]);out.mkdir();rows=b'row fixture';runs=b'run fixture';(out/'rows.u32le').write_bytes(rows);(out/'runs.u32le').write_bytes(runs)
  raw=self.case.path.read_bytes();code={n:outer.DIRECT_SEED_FREEZE[n] for n in outer.DIRECT_SEED_REPORTED};code.update({'rasterizer':outer.DIRECT_SEED_FREEZE['rasterizer/build_seed.py'],'rasterizer_kernel':outer.DIRECT_SEED_FREEZE['rasterizer/seed_kernel.cpp']})
  h=lambda b:hashlib.sha256(b).hexdigest()
  raster=b'rasterizer report';(out/'rasterizer-report.json').write_bytes(raster)
  report={'schema':'worldatlas-stage2-mainland-seed-report-v1','status':'diagnostic-seed-pending-independent-provenance','publishable':False,'grid':self.q['grid'],'execution':{'mode':'direct','strip_rows':self.q['controls']['strip_rows']},'request_sha256':h(raw),'input_sha256':{k:v['sha256'] for k,v in self.q['inputs'].items()},'code_sha256':code,'seed_rows_sha256':h(rows),'seed_runs_sha256':h(runs),'rasterizer_report_sha256':h(raster)}
  for field,key in (('decision_snapshot_sha256','snapshot'),('resolution_report_sha256','resolution'),('physical_rows_sha256','physical_rows'),('physical_runs_sha256','physical_runs'),('physical_report_sha256','physical_report'),('component_rows_sha256','component_rows'),('component_runs_sha256','component_runs'),('component_manifest_sha256','component_manifest')):report[field]=self.q['inputs'][key]['sha256']
  if self.mode=='report':report['code_sha256']['seed_producer.py']='0'*64
  if self.mode=='output':(out/'runs.u32le').write_bytes(b'tampered')
  (out/'report.json').write_text(json.dumps(report))
  if self.mode=='request':self.case.path.write_bytes(raw+b' ')
  if self.mode=='input':pathlib.Path(self.q['inputs']['snapshot']['path']).write_text('{}')
  return mock.Mock(returncode=0)
 def invoke(self):
  with mock.patch.object(outer.subprocess,'run',side_effect=self.fake_run):return outer.invoke_direct_seed(self.case.path,self.case.work,self.case.output)
 def test_synthetic_matching_result(self):self.assertEqual(self.invoke()['execution']['mode'],'direct')
 def test_reject_relative_input_before_start(self):
  self.q['inputs']['snapshot']['path']='relative.json';self.case.path.write_text(json.dumps(self.q))
  with self.assertRaisesRegex(ValueError,'input path must be absolute'):self.invoke()
  self.assertFalse(self.case.work.exists());self.assertFalse(self.case.output.exists())
 def test_reject_duplicate_json_before_start(self):
  raw=self.case.path.read_text();self.case.path.write_text(raw[:-1]+', "schema": "duplicate"}')
  with self.assertRaisesRegex(ValueError,'duplicate JSON key'):self.invoke()
  self.assertFalse(self.case.work.exists());self.assertFalse(self.case.output.exists())
 def test_reject_changed_request(self):
  self.mode='request'
  with self.assertRaisesRegex(RuntimeError,'inspect before retrying') as e:self.invoke()
  self.assertIn('report binding mismatch',str(e.exception.__cause__))
 def test_reject_changed_input(self):
  self.mode='input'
  with self.assertRaisesRegex(RuntimeError,'inspect before retrying') as e:self.invoke()
  self.assertIn('input hash mismatch',str(e.exception.__cause__))
 def test_reject_forged_report_code(self):
  self.mode='report'
  with self.assertRaisesRegex(RuntimeError,'inspect before retrying') as e:self.invoke()
  self.assertIn('report binding mismatch',str(e.exception.__cause__))
 def test_reject_tampered_output(self):
  self.mode='output'
  with self.assertRaisesRegex(RuntimeError,'inspect before retrying') as e:self.invoke()
  self.assertIn('output mismatch',str(e.exception.__cause__))
  self.assertTrue(self.case.output.exists())
  with self.assertRaisesRegex(ValueError,'already exists'):self.invoke()
if __name__=='__main__':unittest.main()
