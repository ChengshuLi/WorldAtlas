"""Exercise the actual unmodified v2 executable pins on a bounded fixture."""
import contextlib, hashlib, json, os, pathlib, subprocess, sys, unittest
from unittest import mock
import seed_producer, test_seed_producer
HERE=pathlib.Path(__file__).resolve().parent

def prepare_selected_panama_region(q):
 snapshot=pathlib.Path(q['inputs']['snapshot']['path']);s=json.loads(snapshot.read_text());old=s['seed_regions'][0]['region_id'];new='north_america_mainland_region_v1';s['seed_regions'][0]['region_id']=new
 s['land_baseline_policy']['region_ids']=[new if x==old else x for x in s['land_baseline_policy']['region_ids']]
 for rule in s['mainland_component_rules']:
  if rule.get('region_id')==old:rule['region_id']=new
 snapshot.write_text(json.dumps(s));q['inputs']['snapshot']=test_seed_producer.pin(snapshot)
 resolution=pathlib.Path(q['inputs']['resolution']['path']);r=json.loads(resolution.read_text());r['snapshot_sha256']=q['inputs']['snapshot']['sha256'];resolution.write_text(json.dumps(r));q['inputs']['resolution']=test_seed_producer.pin(resolution)
 return q
class UnpatchedFreeze(unittest.TestCase):
 def test_actual_pins_and_real_osm_fixture(self):
  files={'seed_builder':HERE/'rasterizer/build_seed.py','seed_kernel':HERE/'rasterizer/seed_kernel.cpp','closure_checker':HERE/'closure-checkers/validate_water_closure_v2.py'}
  for k,p in files.items():self.assertEqual(seed_producer.TRUSTED_CODE[k],hashlib.sha256(p.read_bytes()).hexdigest())
  p=HERE/'closure-checkers/validate_terminal_closure.py'
  self.assertEqual(seed_producer.TRUSTED_TERMINAL_CHECKER,hashlib.sha256(p.read_bytes()).hexdigest())
  case=test_seed_producer.Producer('test_real_panama_archive_and_water_checker_on_synthetic_grid');case.setUp()
  try:
   # The inherited fixture normally overrides pins. Suppress that override so
   # the producer validates the actual checked-in candidate constants instead.
   with mock.patch.object(test_seed_producer.patch,'dict',lambda *a,**k:contextlib.nullcontext()):
    case.test_real_panama_archive_and_water_checker_on_synthetic_grid()
  finally:case.doCleanups()
 def test_direct_subprocess_real_osm_fixture(self):
  case=test_seed_producer.Producer('test_real_panama_archive_and_water_checker_on_synthetic_grid');case.setUp()
  def invoke(request,work,output):
   subprocess.run([sys.executable,'-c','import seed_producer,sys; seed_producer.run(*sys.argv[1:])',str(request),str(work),str(output)],cwd=HERE,check=True)
   return json.loads((pathlib.Path(output)/'report.json').read_text())
  try:
   with mock.patch.object(test_seed_producer.patch,'dict',lambda *a,**k:contextlib.nullcontext()),mock.patch.object(test_seed_producer,'run',invoke):
    case.test_real_panama_archive_and_water_checker_on_synthetic_grid()
  finally:case.doCleanups()
 def test_direct_terminal_checker_real_osm_fixture(self):
  case=test_seed_producer.Producer('test_real_panama_archive_and_water_checker_on_synthetic_grid');case.setUp()
  def invoke(request,work,output):
   request=pathlib.Path(request);q=json.loads(request.read_text());snapshot=pathlib.Path(q['inputs']['snapshot']['path']);data=json.loads(snapshot.read_text())
   boundary=data['mainland_boundaries'][0]['boundary_id'];route=data['routes'][0]
   route['closure_method']='physical_terminal_closure_v1'
   route['start_terminal']={'boundary_id':boundary,'endpoint':'end'};route['end_terminal']={'boundary_id':boundary,'endpoint':'start'}
   snapshot.write_text(json.dumps(data));q['inputs']['snapshot']=test_seed_producer.pin(snapshot)
   resolution=pathlib.Path(q['inputs']['resolution']['path']);r=json.loads(resolution.read_text());r['snapshot_sha256']=q['inputs']['snapshot']['sha256'];resolution.write_text(json.dumps(r));q['inputs']['resolution']=test_seed_producer.pin(resolution)
   q['inputs']['terminal_checker']=test_seed_producer.pin(HERE/'closure-checkers/validate_terminal_closure.py');request.write_text(json.dumps(q))
   subprocess.run([sys.executable,'-c','import seed_producer,sys; seed_producer.run(*sys.argv[1:])',str(request),str(work),str(output)],cwd=HERE,check=True)
   result=json.loads((pathlib.Path(output)/'report.json').read_text());proof=next(x['closure_proof'] for x in result['region_traces'][0]['input_trace'] if x['kind']=='route')
   self.assertEqual(proof['schema'],'physical-terminal-closure-proof-v1');self.assertEqual(proof['checker_sha256'],q['inputs']['terminal_checker']['sha256']);self.assertEqual(proof['support_checker_sha256'],q['inputs']['closure_checker']['sha256']);return result
  # The reused fixture asserts the water checker hash; for this variant the
  # direct terminal checker is expected. All other fixture assertions remain.
  original_assert=case.assertEqual
  terminal=seed_producer.TRUSTED_TERMINAL_CHECKER;water=seed_producer.TRUSTED_CODE['closure_checker']
  def compare(a,b,*args,**kwargs):
   if a==terminal and b==water:return original_assert(a,terminal,*args,**kwargs)
   return original_assert(a,b,*args,**kwargs)
  case.assertEqual=compare
  try:
   with mock.patch.object(test_seed_producer.patch,'dict',lambda *a,**k:contextlib.nullcontext()),mock.patch.object(test_seed_producer,'run',invoke):
    case.test_real_panama_archive_and_water_checker_on_synthetic_grid()
  finally:case.doCleanups()
 def test_unwired_outer_helper_direct_invocation(self):
  import orchestrate_stage2 as outer
  case=test_seed_producer.Producer('test_real_panama_archive_and_water_checker_on_synthetic_grid');case.setUp()
  def invoke(request,work,output):
   request=pathlib.Path(request);q=prepare_selected_panama_region(json.loads(request.read_text()));q['inputs']['terminal_checker']=test_seed_producer.pin(HERE/'closure-checkers/validate_terminal_closure.py');request.write_text(json.dumps(q))
   report=outer.invoke_direct_seed(request,work,output)
   import direct_seed
   self.assertEqual(direct_seed.verify_panama_source(request,output),report['panama_source_trace'])
   report_path=pathlib.Path(output)/'report.json';tampered=json.loads(report_path.read_text());tampered['panama_source_trace']['vertices']+=1;report_path.write_text(json.dumps(tampered))
   with self.assertRaisesRegex(ValueError,'Panama seed source trace mismatch'):direct_seed.verify_panama_source(request,output)
   report_path.write_text(json.dumps(report))
   return report
  try:
   with mock.patch.object(test_seed_producer.patch,'dict',lambda *a,**k:contextlib.nullcontext()),mock.patch.object(test_seed_producer,'run',invoke):
    case.test_real_panama_archive_and_water_checker_on_synthetic_grid()
  finally:case.doCleanups()
 def test_direct_seed_to_core_binding_real_osm(self):
  import direct_seed,build_stage2 as core
  case=test_seed_producer.Producer('test_real_panama_archive_and_water_checker_on_synthetic_grid');case.setUp()
  def invoke(request,work,output):
   request=pathlib.Path(request);q=prepare_selected_panama_region(json.loads(request.read_text()));q['inputs']['terminal_checker']=test_seed_producer.pin(HERE/'closure-checkers/validate_terminal_closure.py')
   stage=case.d/'stage';(stage/'requests').mkdir(parents=True);(stage/'derived').mkdir();req=stage/'requests'/'seed.json';req.write_text(json.dumps(q));manifest=stage/'derived'/'manifest.json';manifest.write_text('{}')
   report=direct_seed.invoke(req,work,output);pin=test_seed_producer.pin
   mapping=(('snapshot','decision_snapshot'),('physical_rows','physical_rows'),('physical_runs','physical_runs'),('physical_report','physical_report'),('component_rows','component_rows'),('component_runs','component_runs'),('component_manifest','component_manifest'),('closure_checker','closure_checker'),('terminal_checker','terminal_checker'),('closure_contract','closure_contract'),('seed_builder','seed_builder'),('seed_kernel','seed_kernel'),('panama_osm_archive','panama_osm_archive'))
   outer_inputs={dst:q['inputs'][src] for src,dst in mapping};controls={'minimum_memory_kib':0};oc={'grid':q['grid'],'policy_id':'p','policy_version':'1','controls':controls,'seed_controls':q['controls'],'inputs':outer_inputs};op=case.d/'outer.json';op.write_text(json.dumps(oc));op_pin=pin(op)
   cfg={'orchestration':{'outer_config_sha256':op_pin['sha256'],'derived_manifest':pin(manifest)},'policy_id':'p','policy_version':'1','controls':controls,'inputs':{'resolution_report':q['inputs']['resolution']},'seed_code_files':{'rasterizer':q['inputs']['seed_builder'],'rasterizer_kernel':q['inputs']['seed_kernel']}}
   db={'request':pin(req),'panama_osm_archive':q['inputs']['panama_osm_archive'],'outer_config':op_pin};derived={'seed_request_sha256':db['request']['sha256']};paths={'seed_report':pathlib.Path(output)/'report.json'}
   pins={dst:q['inputs'][src]['sha256'] for src,dst in mapping if dst in ('decision_snapshot','physical_rows','physical_runs','physical_report','component_rows','component_runs','component_manifest')};pins['resolution_report']=q['inputs']['resolution']['sha256']
   self.assertEqual(core.verify_direct_binding(db,derived,cfg,paths,pins,q['grid'],report,lambda:None),q)
   op.write_text(op.read_text()+' ')
   with self.assertRaisesRegex(ValueError,'input hash mismatch'):core.verify_direct_binding(db,derived,cfg,paths,pins,q['grid'],report,lambda:None)
   return report
  try:
   with mock.patch.object(test_seed_producer.patch,'dict',lambda *a,**k:contextlib.nullcontext()),mock.patch.object(test_seed_producer,'run',invoke):
    case.test_real_panama_archive_and_water_checker_on_synthetic_grid()
  finally:case.doCleanups()
 def test_unwired_outer_helper_ignores_pythonpath_sitecustomize(self):
  import orchestrate_stage2 as outer
  case=test_seed_producer.Producer('test_real_panama_archive_and_water_checker_on_synthetic_grid');case.setUp()
  evil=case.d/'evil';evil.mkdir();sentinel=case.d/'sitecustomize-ran'
  (evil/'sitecustomize.py').write_text('from pathlib import Path\nPath('+repr(str(sentinel))+').write_text("injected")\nimport sys,types\nsys.modules["seed_producer"]=types.ModuleType("seed_producer")\n')
  previous=os.environ.get('PYTHONPATH');os.environ['PYTHONPATH']=str(evil)
  def invoke(request,work,output):
   request=pathlib.Path(request);q=json.loads(request.read_text());q['inputs']['terminal_checker']=test_seed_producer.pin(HERE/'closure-checkers/validate_terminal_closure.py');request.write_text(json.dumps(q))
   return outer.invoke_direct_seed(request,work,output)
  try:
   with mock.patch.object(test_seed_producer.patch,'dict',lambda *a,**k:contextlib.nullcontext()),mock.patch.object(test_seed_producer,'run',invoke):
    case.test_real_panama_archive_and_water_checker_on_synthetic_grid()
   self.assertFalse(sentinel.exists())
  finally:
   if previous is None:os.environ.pop('PYTHONPATH',None)
   else:os.environ['PYTHONPATH']=previous
   case.doCleanups()
 def test_unwired_outer_helper_rejects_code_tamper_before_work(self):
  import orchestrate_stage2 as outer
  case=test_seed_producer.Producer('test_runs_from_selected_structured_inputs');case.setUp()
  try:
   q=case.req;q['inputs']['terminal_checker']=test_seed_producer.pin(HERE/'closure-checkers/validate_terminal_closure.py');q['inputs']['closure_checker']=test_seed_producer.pin(HERE/'closure-checkers/validate_water_closure_v2.py');case.path.write_text(json.dumps(q))
   with mock.patch.dict(outer.DIRECT_SEED_FREEZE,{'regions.py':'0'*64}):
    with self.assertRaisesRegex(ValueError,'direct seed code changed'):outer.invoke_direct_seed(case.path,case.work,case.output)
   self.assertFalse(case.work.exists());self.assertFalse(case.output.exists())
  finally:case.doCleanups()
 def test_unreviewed_checker_rejected_without_override(self):
  case=test_seed_producer.Producer('test_runs_from_selected_structured_inputs');case.setUp()
  try:
   with self.assertRaisesRegex(ValueError,'unreviewed executable code'):
    seed_producer.run(case.path,case.work,case.output)
   self.assertFalse(case.work.exists());self.assertFalse(case.output.exists())
  finally:case.doCleanups()
if __name__=='__main__':unittest.main()
