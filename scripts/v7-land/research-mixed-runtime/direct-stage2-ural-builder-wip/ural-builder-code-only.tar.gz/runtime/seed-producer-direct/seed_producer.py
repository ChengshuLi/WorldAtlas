"""Execute a fresh simple mainland seed from selected Neon L2 decisions.

The caller authenticates the pinned Neon export and independently resolves the
current stage-1 component witnesses before invoking this producer. No historical
continent map, prior assignment checkpoint, or List 1 override is accepted.
"""
import hashlib,json,os,subprocess,sys,ctypes
from pathlib import Path
from decimal import Decimal
from fractions import Fraction
from export_adapter import load_pinned_snapshot,boundary_records,selected_regions,no_duplicates
from seed_rules import compile_rules
from region_client import execute as build_region
from closure_client import sha
from panama_seed_source import bind as bind_panama_source
from ural_seed_source import bind as bind_ural_source
from ural_producer_config import prepare as prepare_ural_config, validate_ural_relationship_scope
BASE=Path(__file__).resolve().parent
CODE=('seed_producer.py','export_adapter.py','seed_rules.py','region_client.py','region_worker.py','regions.py','closure_client.py','panama_seed_source.py','osm_source_handoff.py','assemble_osm_ways.py','ural_seed_source.py','ural_producer_config.py')
TRUSTED_CODE={'seed_builder':'8b59d9212064ed7fcdde37ca9ad53a8b1544c0b2abad4b1e2ac3c30e49b193a1','seed_kernel':'1543a7014f84eb5969b073435d463e838922c186d996ec9dcb0f68133ac15fa8','closure_checker':'5b01e11908293df6f941adbc391d4c9e7709f49c1b8ad60d46be0558d66ca6b3'}
TRUSTED_TERMINAL_CHECKER='08fd855bddd47dd2152ae0ac0fabd1e23e1d75db9e337a0af3a840a6787e1cb2'
INPUTS={'snapshot','resolution','physical_rows','physical_runs','physical_report','component_rows','component_runs','component_manifest','closure_checker','closure_contract','seed_builder','seed_kernel'}
def bounded_json(pin,guard,limit=16<<20):
 h=hashlib.sha256();chunks=[];n=0
 with open(pin['path'],'rb') as f:
  while True:
   guard();b=f.read(1<<20)
   if not b:break
   n+=len(b)
   if n>limit:raise ValueError('JSON input exceeds bound')
   chunks.append(b);h.update(b)
 if h.hexdigest()!=pin['sha256']:raise ValueError('JSON pin mismatch')
 return json.loads(b''.join(chunks))
def publish_no_replace(source,destination):
 # Both operations atomically fail if destination exists. Never fall back to
 # check-then-rename: that could overwrite an output created by another process.
 libc=ctypes.CDLL(None,use_errno=True)
 if sys.platform.startswith('linux') and hasattr(libc,'renameat2'):
  rename=libc.renameat2;rename.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint];rename.restype=ctypes.c_int
  rc=rename(-100,os.fsencode(source),-100,os.fsencode(destination),1)
 elif sys.platform=='darwin' and hasattr(libc,'renamex_np'):
  rename=libc.renamex_np;rename.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_uint];rename.restype=ctypes.c_int
  rc=rename(os.fsencode(source),os.fsencode(destination),4)
 else:raise NotImplementedError('atomic no-overwrite directory publication unavailable')
 if rc:
  error=ctypes.get_errno();raise OSError(error,os.strerror(error),str(destination))
def run(request_path,work_dir,output_dir):
 # Compatibility callback for pure hashing/geometry helpers; no resource monitoring.
 guard=lambda:None
 request_path=Path(request_path).resolve(strict=True);work=Path(work_dir).resolve();output=Path(output_dir).resolve();guard()
 if work.exists() or output.exists() or not work.parent.is_dir() or not output.parent.is_dir() or work==output or work in output.parents or output in work.parents:raise ValueError('invalid work/output directory')
 with open(request_path,'rb') as f:raw=f.read((1<<20)+1)
 if len(raw)>1<<20:raise ValueError('request too large')
 req=json.loads(raw,object_pairs_hook=no_duplicates);inp=req.get('inputs');grid=req.get('grid');controls=req.get('controls')
 if req.get('schema')!='worldatlas-stage2-seed-direct-request-v2' or not isinstance(inp,dict) or not INPUTS<=set(inp) or set(inp)-INPUTS-{'terminal_checker','panama_osm_archive'} or not isinstance(grid,dict) or set(grid)!={'width','height','west','north','step'} or not isinstance(controls,dict) or set(controls)!={'strip_rows'}:raise ValueError('invalid seed request')
 if type(controls['strip_rows']) is not int or controls['strip_rows']<1:raise ValueError('invalid seed controls')
 for key,digest in TRUSTED_CODE.items():
  if inp[key].get('sha256')!=digest:raise ValueError('unreviewed executable code')
 if 'terminal_checker' in inp and inp['terminal_checker'].get('sha256')!=TRUSTED_TERMINAL_CHECKER:raise ValueError('unreviewed terminal checker code')
 for pin in inp.values():
  if not isinstance(pin,dict) or set(pin)!={'path','sha256'} or not isinstance(pin['sha256'],str) or len(pin['sha256'])!=64 or sha(pin['path'],guard)!=pin['sha256']:raise ValueError('input pin mismatch')
 sources={Path(p['path']).resolve().parent for p in inp.values()}|{BASE,request_path.parent}
 for target in (work,output):
  if any(target==d or target in d.parents or d in target.parents for d in sources):raise ValueError('seed work/output overlaps inputs')
 code_hashes={name:sha(BASE/name,guard) for name in CODE};code_hashes['rasterizer']=inp['seed_builder']['sha256'];code_hashes['rasterizer_kernel']=inp['seed_kernel']['sha256']
 ural_pin,check_ural_inputs=prepare_ural_config(req.get('ural_source'),inp['snapshot'],[work,output,*sources],sha,guard)
 snapshot=load_pinned_snapshot(inp['snapshot']['path'],inp['snapshot']['sha256'],guard);resolution=bounded_json(inp['resolution'],guard);rev,entity,boundaries,source_catalog=boundary_records(snapshot)
 validate_ural_relationship_scope(boundaries)
 boundaries,ural_source_trace=bind_ural_source(boundaries,source_catalog,ural_pin)
 if resolution.get('grid')!=grid or resolution.get('component_manifest_sha256')!=inp['component_manifest']['sha256'] or any(resolution.get('input_sha256',{}).get(k)!=inp[k]['sha256'] for k in ('physical_rows','physical_runs','component_rows','component_runs')):raise ValueError('witness resolution input mismatch')
 boundaries,panama_source_trace=bind_panama_source(boundaries,source_catalog,inp.get('panama_osm_archive'))
 regions,records=selected_regions(snapshot,rev,boundaries)
 if any(r.get('closure_method')=='physical_terminal_closure_v1' for r in records.values() if r['kind']=='route') and 'terminal_checker' not in inp:raise ValueError('terminal checker required for selected routes')
 rules=compile_rules(snapshot,resolution,inp['snapshot']['sha256'],[r['region_id'] for r in regions])
 report=bounded_json(inp['physical_report'],guard);outputs=report.get('physical_output_sha256',report.get('output_sha256',{}))
 if report.get('status') not in ('candidate-only','stage1-complete') or report.get('grid')!=grid or outputs.get('rows.u32le')!=inp['physical_rows']['sha256'] or outputs.get('runs.u32le')!=inp['physical_runs']['sha256']:raise ValueError('physical report mismatch')
 contract=bounded_json(inp['closure_contract'],guard);physical=contract.get('physical',{});cg=contract.get('grid',{})
 if contract.get('schema')!='physical-water-closure-contract-v2' or physical.get('rows_sha256')!=inp['physical_rows']['sha256'] or physical.get('runs_sha256')!=inp['physical_runs']['sha256'] or physical.get('report_sha256')!=inp['physical_report']['sha256'] or physical.get('water_code')!=1 or physical.get('land_code')!=17 or cg.get('crs')!='EPSG:4326' or cg.get('width')!=grid['width'] or cg.get('height')!=grid['height'] or Fraction(str(cg.get('west')))!=Fraction(str(grid['west'])) or Fraction(str(cg.get('north')))!=Fraction(str(grid['north'])) or Fraction(cg.get('step_numerator'),cg.get('step_denominator'))!=Fraction(str(grid['step'])):raise ValueError('physical contract mismatch')
 work.mkdir(mode=0o700)
 if os.stat(work).st_dev!=os.stat(output.parent).st_dev:raise ValueError('seed output must share work filesystem')
 rinput=work/'region-input';rinput.mkdir();regionwork=work/'region-work';regionwork.mkdir();codework=work/'rasterizer-code';codework.mkdir();seedout=work/'seed-output'
 # Execute only reviewed byte-pinned rasterizer source copies.
 for key,name in (('seed_builder','build_seed.py'),('seed_kernel','seed_kernel.cpp')):
  with open(inp[key]['path'],'rb') as f:data=f.read((1<<20)+1)
  if len(data)>1<<20 or hashlib.sha256(data).hexdigest()!=inp[key]['sha256']:raise ValueError('rasterizer source mismatch')
  (codework/name).write_bytes(data)
 closure={'checker_path':inp['closure_checker']['path'],'checker_sha256':inp['closure_checker']['sha256'],'physical_dir':str(Path(inp['physical_rows']['path']).resolve().parent),'physical_rows_sha256':inp['physical_rows']['sha256'],'physical_runs_sha256':inp['physical_runs']['sha256'],'physical_report_sha256':inp['physical_report']['sha256'],'contract_path':inp['closure_contract']['path'],'contract_sha256':inp['closure_contract']['sha256']}
 if 'terminal_checker' in inp:closure.update({'terminal_checker_path':inp['terminal_checker']['path'],'terminal_checker_sha256':inp['terminal_checker']['sha256']})
 if Path(inp['physical_runs']['path']).resolve().parent!=Path(closure['physical_dir']):raise ValueError('physical files must be colocated')
 source_list=[{'source_id':k[0],'version':k[1],**v} for k,v in source_catalog.items()];region_configs=[];region_traces=[]
 for decision in regions:
  guard();result=build_region({'schema':'stage2-region-worker-direct-request-v2','revision_id':rev,'records':list(records.values()),'sources':source_list,'decision':decision,'closure':closure},regionwork);
  if any(result['code_sha256'].get(n)!=code_hashes[n] for n in ('region_worker.py','regions.py','closure_client.py')):raise ValueError('region worker code mismatch')
  g=result['geometry'];name=hashlib.sha256(decision['region_id'].encode()).hexdigest()+'.geojson';p=rinput/name;data=json.dumps({'type':'FeatureCollection','features':[{'type':'Feature','properties':{},'geometry':g}]},sort_keys=True,separators=(',',':'),allow_nan=False).encode();p.write_bytes(data);region_configs.append({'id':decision['region_id'],'geometry':{'path':str(p),'sha256':hashlib.sha256(data).hexdigest()},'witnesses':[{'lon':float(w['lon']),'lat':float(w['lat']),'inside':w['inside']} for w in decision['witnesses']]});region_traces.append(result['report'])
 raster_rules=[{'component_id':r['component_id_current_generation_only'],'region_id':r['region_id'],'inside_code':r['inside_code'],'outside_code':r['outside_code']} for r in rules]
 config={'schema':'direct-region-seed-research-v2','grid':{**grid,'crs':'EPSG:4326'},'component_rows':inp['component_rows'],'component_runs':inp['component_runs'],'regions':region_configs,'rules':raster_rules,'evidence':[inp[k] for k in ('snapshot','resolution','physical_rows','physical_runs','physical_report','component_manifest','closure_checker','closure_contract')],'strip_rows':controls['strip_rows']};config_path=rinput/'seed-config.json';config_path.write_text(json.dumps(config,sort_keys=True,indent=2)+'\n')
 err=work/'rasterizer.log'
 with open(err,'w+b') as log:
  env=os.environ.copy()
  p=subprocess.run([sys.executable,str(codework/'build_seed.py'),str(config_path),str(seedout)],stdout=log,stderr=log,env=env)
  if p.returncode:log.seek(0);raise ValueError('seed rasterizer failed: '+log.read(4096).decode(errors='replace'))
 raster=bounded_json({'path':str(seedout/'report.json'),'sha256':sha(seedout/'report.json',guard)},guard)
 rows=sha(seedout/'rows.u32le',guard);runs=sha(seedout/'runs.u32le',guard)
 if raster.get('schema')!='direct-region-seed-research-report-v1' or raster.get('outputs_sha256')!={'rows':rows,'runs':runs} or raster.get('component_rows_sha256')!=inp['component_rows']['sha256'] or raster.get('component_runs_sha256')!=inp['component_runs']['sha256']:raise ValueError('seed rasterizer output mismatch')
 populations=raster.get('rule_population');counts=raster.get('category_cell_counts')
 if not isinstance(populations,dict) or set(populations)!={str(r['component_id_current_generation_only']) for r in rules} or not isinstance(counts,dict) or set(counts)!={str(x) for x in range(17,23)} or any(type(v) is not int or v<=0 for v in counts.values()):raise ValueError('missing mainland category population')
 for r in rules:
  pop=populations[str(r['component_id_current_generation_only'])]
  if not isinstance(pop,dict) or type(pop.get('inside_cells')) is not int or type(pop.get('outside_cells')) is not int or pop['inside_cells']<=0 or (r['region_id'] is not None and pop['outside_cells']<=0):raise ValueError('empty mainland rule partition')
 for pin in inp.values():
  if sha(pin['path'],guard)!=pin['sha256']:raise ValueError('input changed during seed build')
 if check_ural_inputs is not None:check_ural_inputs()
 with open(request_path,'rb') as f:request_after=f.read((1<<20)+1)
 if request_after!=raw or {name:sha(BASE/name,guard) for name in CODE}!={k:v for k,v in code_hashes.items() if k in CODE}:raise ValueError('request or producer code changed')
 (seedout/'report.json').rename(seedout/'rasterizer-report.json')
 rasterizer_report_sha=sha(seedout/'rasterizer-report.json',guard)
 out={'schema':'worldatlas-stage2-mainland-seed-report-v1','status':'diagnostic-seed-pending-independent-provenance','publishable':False,'grid':grid,'decision_snapshot_sha256':inp['snapshot']['sha256'],'decision_revision':rev,'entity_revision':entity,'resolution_report_sha256':inp['resolution']['sha256'],'physical_rows_sha256':inp['physical_rows']['sha256'],'physical_runs_sha256':inp['physical_runs']['sha256'],'component_rows_sha256':inp['component_rows']['sha256'],'component_runs_sha256':inp['component_runs']['sha256'],'component_manifest_sha256':inp['component_manifest']['sha256'],'physical_report_sha256':inp['physical_report']['sha256'],'physical_code_contract':{'water':1,'land':17},'input_sha256':{k:v['sha256'] for k,v in inp.items()},'rasterizer_report_sha256':rasterizer_report_sha,'execution':{'mode':'direct','strip_rows':controls['strip_rows']},'seed_rows_sha256':rows,'seed_runs_sha256':runs,'seed_roots':sorted(r['component_id_current_generation_only'] for r in rules),'rule_population':populations,'category_cell_counts':counts,'region_traces':region_traces,'seed_rules':rules,'code_sha256':code_hashes,'request_sha256':hashlib.sha256(raw).hexdigest(),'limitations':['Caller must authenticate the Neon export and independently re-execute witness resolution and full physical/component coverage before accepting this seed.','Witnesses support component identity but do not prove absence of unintended bridges.','Stored boundary lineage and historical V2/V7 raster equivalence may be incomplete.','No island or List 1 overrides are applied.']}
 out['panama_source_trace']=panama_source_trace
 out['ural_source_trace']=ural_source_trace
 with open(seedout/'report.json','x') as f:json.dump(out,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 fd=os.open(seedout/'rasterizer-report.json',os.O_RDONLY);os.fsync(fd);os.close(fd);fd=os.open(seedout,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
 guard();publish_no_replace(seedout,output)
 fd=os.open(output.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd);return out
