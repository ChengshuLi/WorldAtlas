"""Assemble mainland region polygons from selected Neon L2 lines.

This module does not choose a boundary, source, route, root or category. Its
caller must authenticate the pinned combined Neon export and provide a physical
mask closure validator. No historical label grid is read.
"""
import hashlib,json,math,re
from decimal import Decimal,InvalidOperation
from osgeo import ogr
ogr.UseExceptions()

# Deliberate allowlist: unknown relationships require a reviewed contract update.
SUPPORTING_RELATIONSHIPS = frozenset(['independent_original_terrain_research_not_watershed_or_construction_proof', 'independent_terrain_research_anapa_not_full_watershed_verification_or_construction', 'independent_terrain_research_east_not_watershed_verification_or_construction', 'independent_terrain_research_east_original_not_watershed_verification_or_construction', 'independent_terrain_research_sections_2_3_not_watershed_verification_or_construction', 'independent_terrain_research_west_original_not_watershed_verification_or_construction', 'research_comparison_evidence_not_independent_verification_or_proof_of_construction', 'secondary_terrain_points_not_independent_of_srtm_or_watershed_validation', 'srtm_cross_sensor_research_not_independent_hydrobasins_or_watershed_verification', 'supporting research evidence only; not production geometry selection', 'supporting_geographic_evidence_not_complete_construction_lineage', 'temporary research-only named-waterway corroboration; not a selected pipeline input', 'terrain_quality_mask_for_eastern_research', 'historical_relation_membership_support_not_complete_coordinate_lineage', 'historical_way_membership_support_not_complete_coordinate_lineage', 'companion_mask_for_independent_terrain_screen', 'current_mainstream_source_comparison_not_historical_bytes_or_terrain_proof', 'independent_terrain_screen_mask_zero_only_not_proof_of_divide', 'local_geographic_comparison_not_terrain_or_construction_proof'])
CONSTRUCTION_RELATIONSHIP = "construction_input"
# Audited Ural workflow relationships bind each role to a specific source and
# catalog hash. For chunked ArcticDEM, the third value pins the reassembled
# provider tile; the catalog hash instead identifies the R2 manifest.
URAL_CONSTRUCTION_INPUTS = {
 'raw_basin_edges_and_drainage_classes': ('hydrosheds-hydrobasins-europe-level12-standard', '21797d53e0792cae047d25f0c3cfb570c7ef43700ec962b35b2ac92467e29f03', None),
 'drainage_classes': ('hydrosheds-hydrobasins-siberia-level12-standard', '67ea00df7d14a397f8f78e5b1dc31dcca036018ccbcb36e007ce6854b91d71bd', None),
 'mapped_river_graph_and_spring_role': ('osm-ural-river-relation-214415-full', '89cef99ad92bb8acbd81da3f371a2244892ae71da49c99d4c478e9f111af56a0', None),
 'terrain_input_for_modeled_spring_connection': ('ural-copernicus-glo30-n54e059', 'd1d0a6b65e0fc19695f9414fd5bcece8a2f508a6f7790c70bb20677f20be3ef6', None),
 'manifest_of_raw_arcticdem_tile_used_for_gap00': ('ural-arcticdem-gap00', '667cca1c18e397c3e64b00961ecfe2fe9d7e791542dbaa3d0259eaf432d58bee', '0207e55aec04678895aa73ead434ff189eb0c0a3a8badf553a831821a13eabbd'),
 'manifest_of_first_raw_arcticdem_tile_used_for_gap02': ('ural-arcticdem-gap02a', 'e174e2f039dce3d36f206289554c22818cd6488408efe60ec8a07a3746d5800a', 'dab46d70f16e3c6ee397f342167458513e2d6697898b86a5a2c1e447a437987a'),
 'manifest_of_second_raw_arcticdem_tile_used_for_gap02': ('ural-arcticdem-gap02b', 'a32df2fd906bcf0f86eeed9c97dc7ff579345f692a331d41cbe8a58945548c51', '7a02a4d2ad464323c56bd953c7841369ff2183be243c0931e39b3894031549c3'),
}

def source_role(relationship):
 if relationship==CONSTRUCTION_RELATIONSHIP or relationship in URAL_CONSTRUCTION_INPUTS:return 'construction_input'
 if relationship in SUPPORTING_RELATIONSHIPS:return 'supporting_research_evidence'
 raise ValueError('unsupported source relationship')


def geometry_hash(g):return hashlib.sha256(json.dumps(g,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def coord(v):
 if isinstance(v,bool) or not isinstance(v,(int,float,str,Decimal)):raise ValueError('invalid coordinate')
 try:d=Decimal(str(v))
 except InvalidOperation:raise ValueError('invalid coordinate') from None
 if not d.is_finite():raise ValueError('nonfinite coordinate')
 return d

def points(g):
 if not isinstance(g,dict) or set(g)!={'type','coordinates'} or g['type']!='LineString' or not isinstance(g['coordinates'],list) or not 2<=len(g['coordinates'])<=200000:raise ValueError('invalid L2 LineString')
 out=[]
 for p in g['coordinates']:
  if not isinstance(p,list) or len(p)!=2:raise ValueError('invalid coordinate pair')
  x,y=map(coord,p)
  if not (-180<=x<=180 and -90<=y<=90):raise ValueError('coordinate outside CRS84')
  out.append((x,y))
 if any(a==b for a,b in zip(out,out[1:])):raise ValueError('duplicate consecutive vertex')
 if any(abs(a[0]-b[0])>180 for a,b in zip(out,out[1:])):raise ValueError('antimeridian crossing unsupported')
 return out

def assemble(revision_id,records,decision,source_catalog,closure_checker,*,physical_rows_sha256,physical_runs_sha256,physical_report_sha256,checker_sha256,closure_contract_sha256,guard,terminal_checker_sha256=None):
 if not isinstance(revision_id,str) or not revision_id or not isinstance(decision,dict) or set(decision)!={'region_id','revision_id','execution_status','segments','geometry_sha256','geometry_hash_method','witnesses'} or decision['geometry_hash_method']!='binary64-sorted-compact-geojson-v1' or decision['revision_id']!=revision_id or decision['execution_status']!='selected_for_research' or not isinstance(decision['region_id'],str) or not decision['region_id'] or not isinstance(decision['segments'],list) or not decision['segments'] or len(decision['segments'])>1000 or not callable(closure_checker) or not callable(guard) or any(not re.fullmatch('[0-9a-f]{64}',str(x)) for x in (physical_rows_sha256,physical_runs_sha256,physical_report_sha256,checker_sha256,closure_contract_sha256)):raise ValueError('invalid selected region decision')
 ring=[];trace=[];used=set();total_vertices=0
 for item in decision['segments']:
  guard()
  if not isinstance(item,dict) or set(item)!={'kind','id','start','end','reverse'} or item['kind'] not in ('boundary','route') or not isinstance(item['id'],str) or type(item['start']) is not int or type(item['end']) is not int or type(item['reverse']) is not bool:raise ValueError('invalid region segment selection')
  key=(item['kind'],item['id']);record=records.get(key)
  if not isinstance(record,dict) or record.get('revision_id')!=revision_id or record.get('execution_status')!='selected_for_research' or record.get('id')!=item['id'] or record.get('kind')!=item['kind']:raise ValueError('missing, stale or unselected L2 geometry')
  if record.get('geometry_hash_method')!='binary64-sorted-compact-geojson-v1':raise ValueError('unsupported L2 geometry hash method')
  g=record.get('geometry');pts=points(g)
  canon={'type':'LineString','coordinates':[[float(x),float(y)] for x,y in pts]}
  if geometry_hash(canon)!=record.get('geometry_sha256'):raise ValueError('L2 geometry hash mismatch')
  a,b=item['start'],item['end']
  if not 0<=a<b<=len(pts) or b-a<2:raise ValueError('invalid L2 vertex slice')
  citations=[]
  if item['kind']=='boundary':
   refs=record.get('qualified_source_refs');status=record.get('lineage_status')
   if not isinstance(refs,list) or not refs or status not in ('complete','incomplete'):raise ValueError('boundary provenance missing')
   for ref in refs:
    if not isinstance(ref,dict) or set(ref)!={'source_id','version','relationship','role'} or not isinstance(ref['relationship'],str) or not ref['relationship'] or ref['role'] not in ('construction_input','supporting_research_evidence'):raise ValueError('invalid boundary source citation')
    if ref['role']!=source_role(ref['relationship']):raise ValueError('unsupported or inconsistent source role')
    source=source_catalog.get((ref['source_id'],ref['version']))
    if not isinstance(source,dict) or source.get('kind')!='raw' or not re.fullmatch('[0-9a-f]{64}',str(source.get('sha256'))) or not source.get('bucket') or not source.get('key'):raise ValueError('boundary citation not a pinned raw source')
    citation={'source_id':ref['source_id'],'version':ref['version'],'relationship':ref['relationship'],'role':ref['role'],'sha256':source['sha256'],'bucket':source['bucket'],'key':source['key']}
    expected=URAL_CONSTRUCTION_INPUTS.get(ref['relationship'])
    if expected:
     if ref['source_id']!=expected[0] or source['sha256']!=expected[1]:raise ValueError('Ural construction source pin mismatch')
     if expected[2]:
      if source.get('representation')!='manifest_of_raw_parts' or source.get('full_tile_sha256')!=expected[2]:raise ValueError('Ural tile manifest mismatch')
      citation.update(representation='manifest_of_raw_parts',full_tile_sha256=expected[2])
    citations.append(citation)
  else:
   role=record.get('role');prov=record.get('provenance')
   if role!='water_closure':raise ValueError('route requires physical closure proof')
   if not isinstance(prov,dict) or prov.get('lineage_status') not in ('complete','incomplete') or not isinstance(prov.get('source_refs'),list):raise ValueError('closure provenance missing')
   for ref in prov['source_refs']:
    if not isinstance(ref,dict) or set(ref)!={'source_id','version'}:raise ValueError('invalid closure source citation')
    source=source_catalog.get((ref['source_id'],ref['version']))
    if not isinstance(source,dict) or source.get('kind')!='raw' or not re.fullmatch('[0-9a-f]{64}',str(source.get('sha256'))) or not source.get('bucket') or not source.get('key') or not isinstance(source.get('origin'),str) or not source['origin']:raise ValueError('closure citation not pinned raw source')
    citations.append({'source_id':ref['source_id'],'version':ref['version'],'sha256':source['sha256'],'bucket':source['bucket'],'key':source['key'],'origin':source['origin']})
  selected=pts[a:b];selected=selected[::-1] if item['reverse'] else selected
  if ring and ring[-1]!=selected[0]:raise ValueError('L2 segments do not connect exactly')
  if item['kind']=='route':
   method=record.get('closure_method')
   if method=='physical_water_closure_v1':
    proof=closure_checker(record,selected)
    expected_schema='physical-water-closure-proof-v1'
   elif method=='physical_terminal_closure_v1':
    if not isinstance(terminal_checker_sha256,str) or not re.fullmatch('[0-9a-f]{64}',terminal_checker_sha256):raise ValueError('terminal checker pin missing')
    if a!=0 or b!=len(pts):raise ValueError('terminal closure must use complete route')
    refs=[]
    for side in (('end','start') if item['reverse'] else ('start','end')):
     ref=record.get(side+'_terminal')
     if not isinstance(ref,dict) or set(ref)!={'boundary_id','endpoint'} or ref['endpoint'] not in ('start','end'):raise ValueError('invalid terminal reference')
     boundary=records.get(('boundary',ref['boundary_id']))
     if not isinstance(boundary,dict) or boundary.get('revision_id')!=revision_id or boundary.get('execution_status')!='selected_for_research':raise ValueError('closure terminal boundary is not selected')
     bp=points(boundary.get('geometry'));canonical={'type':'LineString','coordinates':[[float(x),float(y)] for x,y in bp]}
     if geometry_hash(canonical)!=boundary.get('geometry_sha256'):raise ValueError('closure terminal boundary geometry mismatch')
     refs.append({'boundary_id':ref['boundary_id'],'endpoint':ref['endpoint'],'geometry':canonical,'geometry_sha256':boundary['geometry_sha256']})
    if selected[0]!=points(refs[0]['geometry'])[0 if refs[0]['endpoint']=='start' else -1] or selected[-1]!=points(refs[1]['geometry'])[0 if refs[1]['endpoint']=='start' else -1]:raise ValueError('closure endpoint does not match selected boundary')
    proof=closure_checker(record,selected,refs)
    expected_schema='physical-terminal-closure-proof-v1'
    if not isinstance(proof,dict) or proof.get('start_geometry_sha256')!=refs[0]['geometry_sha256'] or proof.get('end_geometry_sha256')!=refs[1]['geometry_sha256'] or proof.get('start_endpoint')!=refs[0]['endpoint'] or proof.get('end_endpoint')!=refs[1]['endpoint'] or proof.get('no_land_land_edge_touched') is not True:raise ValueError('terminal closure proof mismatch')
   else:raise ValueError('unsupported closure method')
   selected_line={'type':'LineString','coordinates':[[float(x),float(y)] for x,y in selected]}
   if not isinstance(proof,dict) or proof.get('schema')!=expected_schema or proof.get('status')!='valid' or proof.get('geometry_sha256')!=geometry_hash(selected_line) or proof.get('physical_rows_sha256')!=physical_rows_sha256 or proof.get('physical_runs_sha256')!=physical_runs_sha256 or proof.get('physical_report_sha256')!=physical_report_sha256 or proof.get('contract_sha256')!=closure_contract_sha256 or proof.get('checker_sha256')!=(terminal_checker_sha256 if method=='physical_terminal_closure_v1' else checker_sha256):raise ValueError('water closure not validated against geometry, physical mask and checker pins')
  else:proof=None
  total_vertices+=len(selected)
  if total_vertices>250000:raise ValueError('region vertex limit exceeded')
  ring.extend(selected if not ring else selected[1:]);used.add(key)
  trace.append({'kind':item['kind'],'id':item['id'],'geometry_sha256':record['geometry_sha256'],'start':a,'end':b,'reverse':item['reverse'],'lineage_status':record.get('lineage_status'),'source_citations':citations,'closure_proof':proof,'route_provenance':record.get('provenance') if item['kind']=='route' else None})
 if len(ring)<4 or ring[0]!=ring[-1]:raise ValueError('region ring is not explicitly closed')
 if any(abs(a[0]-b[0])>180 for a,b in zip(ring,ring[1:])):raise ValueError('antimeridian crossing unsupported')
 guard();geom={'type':'Polygon','coordinates':[[[float(x),float(y)] for x,y in ring]]};g=ogr.CreateGeometryFromJson(json.dumps(geom))
 if g is None or g.IsEmpty() or not g.IsValid():raise ValueError('invalid assembled region')
 if geometry_hash(geom)!=decision['geometry_sha256']:raise ValueError('region output geometry hash mismatch')
 if not isinstance(decision['witnesses'],list):raise ValueError('invalid region witnesses')
 for w in decision['witnesses']:
  if not isinstance(w,dict) or set(w)!={'lon','lat','inside'} or type(w['inside']) is not bool:raise ValueError('invalid region witness')
  lon,lat=coord(w['lon']),coord(w['lat'])
  if not(-180<=lon<=180 and -90<=lat<=90):raise ValueError('witness outside CRS84')
  p=ogr.Geometry(ogr.wkbPoint);p.AddPoint_2D(float(lon),float(lat))
  if g.Boundary().Intersects(p) or bool(g.Contains(p))!=w['inside']:raise ValueError('region witness fails or touches boundary')
 return geom,{'revision_id':revision_id,'region_id':decision['region_id'],'geometry_sha256':decision['geometry_sha256'],'input_trace':trace,'used_geometry_ids':sorted([list(x) for x in used]),'lineage_limitations':[t['id'] for t in trace if t['lineage_status']=='incomplete'],'method':'selected Neon L2 line and route geometries; explicit ordered concatenation, no geometric repair'}
