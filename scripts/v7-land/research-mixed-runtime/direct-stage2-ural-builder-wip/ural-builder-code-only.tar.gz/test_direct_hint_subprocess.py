import json,os,subprocess,sys,unittest
from pathlib import Path
from test_direct_hint_cli import CLITests
class DirectHintInvocation(CLITests):
 def test_direct_command_and_failed_input(self):
  runner=Path(__file__).resolve().parent/'runtime/hint-producer/run_diagnostic.py';out=self.p/'out'/'direct'
  proc=subprocess.run([sys.executable,str(runner),str(self.req),str(out)],capture_output=True,text=True,env=dict(os.environ,OPENBLAS_NUM_THREADS='1'),check=True)
  obj=json.loads(proc.stdout);self.assertEqual(obj['root_count'],2);self.assertTrue((out/'report.json').exists());self.assertFalse((out/'monitor.json').exists())
  (self.i/'component_runs').write_bytes(b'corrupt');bad=self.p/'out'/'bad'
  p=subprocess.run([sys.executable,str(runner),str(self.req),str(bad)],capture_output=True,text=True,env=dict(os.environ,OPENBLAS_NUM_THREADS='1'))
  self.assertNotEqual(p.returncode,0);self.assertFalse(bad.exists())
if __name__=='__main__':unittest.main()
