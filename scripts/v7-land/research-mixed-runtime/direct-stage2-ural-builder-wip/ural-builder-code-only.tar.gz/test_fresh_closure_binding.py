"""Bounded research tests; fresh mode is not wired to an executable path."""
import copy, unittest
import contracts as c
from test_direct_contracts import CrosswalkTests

class FreshClosure(CrosswalkTests):
 def fresh(self):
  return c.validate_selected_seed_decisions(self.snapshot,self.seed,self.groups,self.codes,self.metric,fresh_closure_proofs=True)
 def change_historic_checker_and_contract(self):
  prov=self.snapshot['routes'][0]['provenance']
  prov['checker_sha256']='b'*64; prov['contract_sha256']='c'*64
  # The seed trace must preserve the selected historical provenance exactly.
  self.seed['region_traces'][0]['input_trace'][1]['route_provenance']=copy.deepcopy(prov)
 def test_new_proof_does_not_rewrite_history(self):
  self.change_historic_checker_and_contract()
  with self.assertRaisesRegex(ValueError,'route source/provenance'):self.check()
  self.assertTrue(self.fresh())
 def test_fresh_proof_still_binds_new_inputs(self):
  self.change_historic_checker_and_contract()
  proof=self.seed['region_traces'][0]['input_trace'][1]['closure_proof']
  for key in ('checker_sha256','contract_sha256','physical_rows_sha256','physical_runs_sha256','physical_report_sha256','geometry_sha256'):
   old=proof[key];proof[key]='0'*64
   with self.assertRaises(ValueError):self.fresh()
   proof[key]=old
 def test_trace_must_preserve_selected_historical_record(self):
  self.change_historic_checker_and_contract()
  self.seed['region_traces'][0]['input_trace'][1]['route_provenance']['checker_sha256']='d'*64
  with self.assertRaisesRegex(ValueError,'route provenance'):self.fresh()
 def test_historical_physical_pins_are_not_relabelled(self):
  prov=self.snapshot['routes'][0]['provenance']
  for key in ('physical_rows_sha256','physical_runs_sha256','physical_report_sha256'):prov[key]='e'*64
  self.seed['region_traces'][0]['input_trace'][1]['route_provenance']=copy.deepcopy(prov)
  with self.assertRaisesRegex(ValueError,'route source/provenance'):self.check()
  self.assertTrue(self.fresh())
 def test_fresh_terminal_support_and_endpoints_fail_closed(self):
  route=self.snapshot['routes'][0];route['closure_method']='physical_terminal_closure_v1';route['start_terminal']={'boundary_id':'b','endpoint':'end'};route['end_terminal']={'boundary_id':'b','endpoint':'start'}
  prov=route['provenance'];prov['checker_sha256']='b'*64;prov['contract_sha256']='c'*64
  trace=self.seed['region_traces'][0]['input_trace'][1];trace['route_provenance']=copy.deepcopy(prov);proof=trace['closure_proof'];pins=self.seed['input_sha256']
  proof.update({'schema':'physical-terminal-closure-proof-v1','checker_sha256':pins['terminal_checker'],'support_checker_sha256':pins['closure_checker'],'no_land_land_edge_touched':True,'start_geometry_sha256':self.snapshot['mainland_boundaries'][0]['geometry_sha256'],'end_geometry_sha256':self.snapshot['mainland_boundaries'][0]['geometry_sha256'],'start_endpoint':'end','end_endpoint':'start'})
  self.assertTrue(self.fresh())
  for key,bad in (('support_checker_sha256','0'*64),('start_endpoint','start'),('end_geometry_sha256','0'*64),('no_land_land_edge_touched',False)):
   old=proof[key];proof[key]=bad
   with self.assertRaises(ValueError):self.fresh()
   proof[key]=old
 def test_historic_digest_must_be_well_formed(self):
  self.change_historic_checker_and_contract()
  self.snapshot['routes'][0]['provenance']['checker_sha256']='not-a-hash'
  self.seed['region_traces'][0]['input_trace'][1]['route_provenance']['checker_sha256']='not-a-hash'
  with self.assertRaisesRegex(ValueError,'route source/provenance'):self.fresh()
if __name__=='__main__':unittest.main()
