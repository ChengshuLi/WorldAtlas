import json, sys, unittest
from unittest.mock import patch
from pathlib import Path
from types import SimpleNamespace
def setUpModule():
 import importlib
 global binding, gate_path, previous_modules
 gate_path=str(Path(__file__).parent/'caucasus-audit');sys.path.insert(0,gate_path)
 names=('caucasus_seed_gate','caucasus_effective_snapshot','caucasus_stage2_validation','caucasus_stage2_binding')
 previous_modules={name:sys.modules.get(name) for name in names}
 binding=importlib.import_module('caucasus_stage2_binding')

def tearDownModule():
 sys.path.remove(gate_path)
 for name,old in previous_modules.items():
  if old is None:sys.modules.pop(name,None)
  else:sys.modules[name]=old

class NestedIsolation(unittest.TestCase):
 def test_nested_process_is_no_site_and_has_explicit_absolute_roots(self):
  with patch.object(binding.sys,'flags',SimpleNamespace(isolated=1,no_site=1)), patch.object(binding.sys,'path',['/fixture/dependencies']), patch.object(binding,'verify_config'), patch.object(binding,'digest',return_value='a'*64), patch.object(binding,'validate_direct_request'), patch.object(binding.subprocess,'run') as run:
   binding.run_seed({k:{'path':'/p','sha256':'a'*64} for k in ('recipe','hydro','author')},'request','a'*64,'producer','b'*64,'work','output','report')
  cmd=run.call_args.args[0]
  self.assertEqual(cmd[1:4],['-I','-S','-B'])
  roots=json.loads(cmd[6]);self.assertEqual(roots,[str(binding.HERE),'/fixture/dependencies'])
  self.assertIn('sys.path[:0]=paths',cmd[5])
if __name__=='__main__':unittest.main()

class NestedRealProcess(unittest.TestCase):
 def test_no_site_child_and_hostile_pythonpath_not_loaded(self):
  import os, tempfile
  from unittest.mock import patch
  with tempfile.TemporaryDirectory() as d:
   root=Path(d); gate=root/'caucasus_seed_gate.py'; report=root/'report.json'; marker=root/'executed'
   gate.write_text("import json,sys\nfrom pathlib import Path\np=Path(sys.argv[sys.argv.index('--report')+1])\np.write_text(json.dumps({'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'path':sys.path}))\n")
   (root/'sitecustomize.py').write_text('open('+repr(str(marker))+', "w").write("bad")')
   cfg={k:{'path':'/p','sha256':'a'*64} for k in ('recipe','hydro','author')}
   # Simulate the authenticated no-site parent bootstrap, which owns sys.path.
   with patch.object(binding.sys,'flags',SimpleNamespace(isolated=1,no_site=1)), patch.object(binding,'HERE',root), patch.object(binding,'verify_config'), patch.object(binding,'digest',return_value='a'*64), patch.object(binding,'validate_direct_request'), patch.dict(os.environ,{'PYTHONPATH':str(root),'PYTHONHOME':str(root)}):
    binding.run_seed(cfg,'request','a'*64,'producer','b'*64,'work','output',report)
   observed=json.loads(report.read_text());self.assertEqual((observed['isolated'],observed['no_site']),(1,1));self.assertFalse(marker.exists())
