"""Bounded no-overwrite and platform-dispatch tests; no map is built."""
import errno
import tempfile
import unittest
from pathlib import Path
from unittest import mock
import atomic_move


class FakeCall:
    def __init__(self, result=0):
        self.result = result
        self.args = None

    def __call__(self, *args):
        self.args = args
        return self.result


class AtomicMove(unittest.TestCase):
    def test_real_linux_move_and_no_replace(self):
        if not atomic_move.sys.platform.startswith('linux'):
            self.skipTest('Linux syscall test')
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source, target = root / 'source', root / 'target'
            source.mkdir()
            (source / 'value').write_text('new')
            target.mkdir()
            (target / 'value').write_text('old')
            with self.assertRaises(OSError) as cm:
                atomic_move.move_noreplace(source, target)
            self.assertIn(cm.exception.errno, (errno.EEXIST, errno.ENOTEMPTY))
            self.assertEqual((source / 'value').read_text(), 'new')
            self.assertEqual((target / 'value').read_text(), 'old')
            (target / 'value').unlink()
            target.rmdir()
            atomic_move.move_noreplace(source, target)
            self.assertFalse(source.exists())
            self.assertEqual((target / 'value').read_text(), 'new')

    def test_darwin_uses_exclusive_rename(self):
        call = FakeCall()
        with mock.patch.object(atomic_move.sys, 'platform', 'darwin'), \
             mock.patch.object(atomic_move, 'libc', type('Lib', (), {'renamex_np': call})()):
            atomic_move.move_noreplace('/source', '/target')
        self.assertEqual(call.args, (b'/source', b'/target', 4))

    def test_unavailable_syscall_fails_closed(self):
        with mock.patch.object(atomic_move.sys, 'platform', 'darwin'), \
             mock.patch.object(atomic_move, 'libc', object()):
            with self.assertRaisesRegex(RuntimeError, 'unavailable'):
                atomic_move.move_noreplace('/source', '/target')

    def test_missing_linux_symbol_and_unknown_platform_fail_closed(self):
        for platform in ('linux', 'freebsd'):
            with self.subTest(platform=platform), \
                 mock.patch.object(atomic_move.sys, 'platform', platform), \
                 mock.patch.object(atomic_move, 'libc', object()):
                with self.assertRaisesRegex(RuntimeError, 'unavailable'):
                    atomic_move.move_noreplace('/source', '/target')

    def test_existing_empty_directory_and_dangling_symlink_are_not_replaced(self):
        if not atomic_move.sys.platform.startswith('linux'):
            self.skipTest('Linux syscall test')
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            for kind in ('directory', 'symlink'):
                with self.subTest(kind=kind):
                    source, target = root / ('source-' + kind), root / ('target-' + kind)
                    source.mkdir()
                    if kind == 'directory':
                        target.mkdir()
                    else:
                        target.symlink_to('missing-target')
                    with self.assertRaises(OSError):
                        atomic_move.move_noreplace(source, target)
                    self.assertTrue(source.is_dir())
                    self.assertTrue(target.is_dir() if kind == 'directory' else target.is_symlink())

    def test_darwin_error_is_propagated(self):
        call = FakeCall(-1)
        with mock.patch.object(atomic_move.sys, 'platform', 'darwin'), \
             mock.patch.object(atomic_move, 'libc', type('Lib', (), {'renamex_np': call})()), \
             mock.patch.object(atomic_move.ctypes, 'get_errno', return_value=errno.EEXIST):
            with self.assertRaises(OSError) as cm:
                atomic_move.move_noreplace('/source', '/target')
        self.assertEqual(cm.exception.errno, errno.EEXIST)


if __name__ == '__main__':
    unittest.main()
