"""Bounded isolated-process tests for Caucasus dependency origin checks."""
import hashlib,json,os,py_compile,shutil,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent;RUNTIME=ROOT/'runtime';GATE=ROOT/'caucasus-audit'
class ImportIsolation(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.d=Path(self.t.name);self.shadow=self.d/'shadow';self.shadow.mkdir();self.marker=self.d/'shadow-executed';self.gate=GATE
  (self.shadow/'caucasus_stage2_validation.py').write_text('from pathlib import Path\nPath('+repr(str(self.marker))+').write_text("bad")\n')
  names=('caucasus_stage2_validation.py','caucasus_effective_snapshot.py','caucasus_seed_gate.py','caucasus_source_assembly.py','caucasus_compact_selectors.py','caucasus_selector_replay.py','caucasus_stage2_binding.py')
  sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();self.cfg={'code_sha256':{n:sha(GATE/n) for n in names}}
  for n in ('recipe','hydro','author'):
   p=self.d/n;p.write_text(n);self.cfg[n]={'path':str(p),'sha256':sha(p)}
  self.config=self.d/'config.json';self.config.write_text(json.dumps(self.cfg))
 def run_case(self,preload=False):
  script='''import json,sys,types
from pathlib import Path
runtime,shadow,gate,config,preload=sys.argv[1:]
sys.path[:0]=[runtime,shadow];sys.path.append(gate)
import build_stage2 as c
c.caucasus_directory=lambda:Path(gate)
if preload=='yes':
 m=types.ModuleType('caucasus_seed_gate');m.__file__=str(Path(shadow)/'caucasus_seed_gate.py');sys.modules['caucasus_seed_gate']=m
try:
 b=c.caucasus_binding(json.loads(Path(config).read_text()),lambda:None)
 assert not any(x in sys.modules for x in ('caucasus_seed_gate','caucasus_effective_snapshot','caucasus_stage2_validation','caucasus_stage2_binding'))
 b2=c.caucasus_binding(json.loads(Path(config).read_text()),lambda:None)
 assert not any(x in sys.modules for x in ('caucasus_seed_gate','caucasus_effective_snapshot','caucasus_stage2_validation','caucasus_stage2_binding'))
 print('ok',Path(b.__file__).resolve(),Path(b2.__file__).resolve())
except Exception as e:
 print(type(e).__name__,str(e));sys.exit(7)
'''
  return subprocess.run([sys.executable,'-I','-c',script,str(RUNTIME),str(self.shadow),str(self.gate),str(self.config),'yes' if preload else 'no'],capture_output=True,text=True,env={k:v for k,v in os.environ.items() if not k.upper().startswith('PYTHON')})
 def test_shadow_earlier_than_pinned_is_not_executed(self):
  r=self.run_case();self.assertEqual(r.returncode,0,r.stdout+r.stderr);self.assertIn(str(GATE/'caucasus_stage2_binding.py'),r.stdout);self.assertFalse(self.marker.exists())
 def test_timestamp_valid_stale_pyc_is_not_executed(self):
  self.gate=self.d/'pinned';shutil.copytree(GATE,self.gate,ignore=shutil.ignore_patterns('__pycache__'))
  target=self.gate/'caucasus_stage2_validation.py';original=target.read_bytes();st=target.stat();payload=('from pathlib import Path\nPath('+repr(str(self.marker))+').write_text("stale")\n').encode();self.assertLess(len(payload)+2,len(original));evil=payload+b'#'+b'x'*(len(original)-len(payload)-2)+b'\n';self.assertEqual(len(evil),len(original))
  target.write_bytes(evil);os.utime(target,ns=(st.st_atime_ns,st.st_mtime_ns));py_compile.compile(str(target),doraise=True,invalidation_mode=py_compile.PycInvalidationMode.TIMESTAMP)
  target.write_bytes(original);os.utime(target,ns=(st.st_atime_ns,st.st_mtime_ns))
  r=self.run_case();self.assertEqual(r.returncode,0,r.stdout+r.stderr);self.assertFalse(self.marker.exists())
 def test_preloaded_foreign_dependency_rejected(self):
  r=self.run_case(True);self.assertEqual(r.returncode,7,r.stdout+r.stderr);self.assertIn('Caucasus dependency already loaded',r.stdout);self.assertFalse(self.marker.exists())
if __name__=='__main__':unittest.main()
