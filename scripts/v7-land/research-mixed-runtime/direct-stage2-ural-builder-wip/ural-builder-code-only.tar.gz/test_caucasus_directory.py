import tempfile,unittest
from pathlib import Path
from unittest import mock
import build_stage2 as c
class CaucasusDirectory(unittest.TestCase):
 def setUp(self):self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.root=Path(self.t.name)
 def test_sibling_layout(self):
  runtime=self.root/'project'/'runtime';runtime.mkdir(parents=True);target=runtime.parent/'caucasus-audit';target.mkdir()
  with mock.patch.object(c,'HERE',runtime):self.assertEqual(c.caucasus_directory(),target.resolve())
 def test_repository_layout(self):
  runtime=self.root/'scripts'/'v7-recovery'/'land'/'stage2';runtime.mkdir(parents=True);target=self.root/'scripts'/'caucasus-audit';target.mkdir()
  with mock.patch.object(c,'HERE',runtime):self.assertEqual(c.caucasus_directory(),target.resolve())
 def test_ambiguous_or_missing_fails(self):
  runtime=self.root/'scripts'/'v7-recovery'/'land'/'stage2';runtime.mkdir(parents=True)
  with mock.patch.object(c,'HERE',runtime):
   with self.assertRaisesRegex(ValueError,'missing or ambiguous'):c.caucasus_directory()
   (runtime.parent/'caucasus-audit').mkdir();(self.root/'scripts'/'caucasus-audit').mkdir()
   with self.assertRaisesRegex(ValueError,'missing or ambiguous'):c.caucasus_directory()
 def test_actual_scratch_layout(self):
  expected=(c.HERE.parent/'caucasus-audit').resolve()
  if not expected.is_dir():self.skipTest('sibling Caucasus source directory not assembled')
  self.assertEqual(c.caucasus_directory(),expected)
if __name__=='__main__':unittest.main()
