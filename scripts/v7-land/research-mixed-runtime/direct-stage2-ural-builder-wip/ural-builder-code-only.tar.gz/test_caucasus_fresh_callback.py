"""Bounded gate callback test; source derivation is deliberately mocked."""
import copy,functools,hashlib,tempfile,unittest
from pathlib import Path
from unittest import mock
import build_stage2 as core
import contracts
from test_direct_contracts import CrosswalkTests
class GateFreshCallback(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.d=Path(self.t.name);self.request=self.d/'request';self.request.write_bytes(b'request')
  sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();directory=core.caucasus_directory();self.cfg={'code_sha256':{n:sha(directory/n) for n in core.CAUCASUS_CODE}}
  for name in ('recipe','hydro','author'):
   p=self.d/name;p.write_text(name);self.cfg[name]={'path':str(p),'sha256':sha(p)}
  self.reqsha=sha(self.request);self.binding=core.caucasus_binding(self.cfg,lambda:None);self.fixture=CrosswalkTests('test_full_crosswalk_and_tampers');self.fixture.setUp()
  prov=self.fixture.snapshot['routes'][0]['provenance'];prov['checker_sha256']='b'*64;prov['contract_sha256']='c'*64;self.fixture.seed['region_traces'][0]['input_trace'][1]['route_provenance']=copy.deepcopy(prov)
  self.source={'schema':'caucasus-source-seed-gate-v1','snapshot_sha256':'s'};self.effective={'original_snapshot_sha256':'s'};self.trace={'source_derivation':{'source_gate':self.source,'effective_snapshot':self.effective}}
  self.gate=dict(self.source,request_sha256=self.reqsha,seed_producer_executed=True,seed_producer_sha256='p',seed_worker_sha256=None,effective_snapshot=self.effective)
 def fake_validate(self,validator,seed,groups,entity,metric,**kwargs):
  result=validator(self.fixture.snapshot,seed,groups,entity,metric,guard=kwargs['guard']);return result,self.trace
 def run_binding(self,validator):
  with mock.patch.object(self.binding.validation,'validate',side_effect=self.fake_validate):
   return self.binding.validate_seed(self.cfg,self.request,self.reqsha,self.gate,'p',validator,self.fixture.seed,self.fixture.groups,self.fixture.codes,self.fixture.metric,guard=lambda:None)
 def test_authenticated_fresh_callback_accepts_new_proof(self):
  validator=functools.partial(contracts.validate_selected_seed_decisions,fresh_closure_proofs=True);result,_=self.run_binding(validator);self.assertEqual(result,self.fixture.snapshot['land_baseline_policy'])
 def test_default_historical_callback_does_not_accept_new_proof(self):
  with self.assertRaisesRegex(ValueError,'route source/provenance'):self.run_binding(contracts.validate_selected_seed_decisions)
 def test_changed_gate_report_rejected(self):
  self.gate['seed_producer_sha256']='wrong';validator=functools.partial(contracts.validate_selected_seed_decisions,fresh_closure_proofs=True)
  with self.assertRaisesRegex(ValueError,'independently derived'):self.run_binding(validator)
if __name__=='__main__':unittest.main()
