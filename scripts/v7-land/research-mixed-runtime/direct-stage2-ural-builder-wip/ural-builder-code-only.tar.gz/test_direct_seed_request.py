import copy,unittest
import orchestrate_stage2 as o
class DirectSeedRequest(unittest.TestCase):
 def setUp(self):
  self.i={k:{'path':'/p/'+k,'sha256':'a'*64} for k in ('snapshot','resolution','physical_rows','physical_runs','physical_report','component_rows','component_runs','component_manifest','closure_checker','terminal_checker','closure_contract','seed_builder','seed_kernel')}
  self.g={'width':8,'height':4,'west':-180,'north':90,'step':45}
 def test_exact_v2_and_optional_sources(self):
  i=copy.deepcopy(self.i);i['terminal_checker']={'path':'/p/terminal','sha256':'b'*64};i['panama_osm_archive']={'path':'/p/osm','sha256':'c'*64}
  q=o.direct_seed_request(self.g,i,4);self.assertEqual(q,{'schema':'worldatlas-stage2-seed-direct-request-v2','grid':self.g,'inputs':i,'controls':{'strip_rows':4}})
 def test_reject_missing_extra_and_invalid_pins(self):
  i=copy.deepcopy(self.i);del i['resolution']
  with self.assertRaises(ValueError):o.direct_seed_request(self.g,i,4)
  i=copy.deepcopy(self.i);i['worker']={'path':'/p','sha256':'a'*64}
  with self.assertRaises(ValueError):o.direct_seed_request(self.g,i,4)
  i=copy.deepcopy(self.i);i['snapshot']['sha256']='x'*64
  with self.assertRaises(ValueError):o.direct_seed_request(self.g,i,4)
 def test_no_supervisor_or_process_memory_controls(self):
  q=o.direct_seed_request(self.g,self.i,4);self.assertEqual(set(q['controls']),{'strip_rows'})
  for n in (0,-1,True,1.5):
   with self.assertRaises(ValueError):o.direct_seed_request(self.g,self.i,n)
 def test_still_rejects_fresh_outer_config(self):
  # The helper alone does not enable execution or bypass the unresolved gates.
  from test_direct_outer import Outer
  t=Outer('test_rejects_fresh_seed_until_direct_seed_is_implemented');t.setUp()
  try:t.test_rejects_fresh_seed_until_direct_seed_is_implemented()
  finally:t.doCleanups()
if __name__=='__main__':unittest.main()
