"""Bounded direct seed/core linkage checks; no map execution."""
import copy,hashlib,json,tempfile,unittest
from pathlib import Path
from unittest import mock
import build_stage2 as c
import direct_seed
class DirectCoreBinding(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.d=Path(self.t.name);self.w=self.d/'work';(self.w/'derived').mkdir(parents=True);(self.w/'requests').mkdir();(self.w/'seed-output').mkdir()
  self.manifest=self.w/'derived'/'manifest.json';self.manifest.write_text('{}');self.request=self.w/'requests'/'seed.json';self.archive=self.d/'archive';self.archive.write_bytes(b'archive');self.report=self.w/'seed-output'/'report.json';self.report.write_text('{}')
  pin=lambda p:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
  names=('decision_snapshot','physical_rows','physical_runs','physical_report','component_rows','component_runs','component_manifest','closure_checker','terminal_checker','closure_contract','seed_builder','seed_kernel')
  inputs={n:{'path':'/absolute/'+n,'sha256':format(i+1,'064x')} for i,n in enumerate(names)};inputs['panama_osm_archive']=pin(self.archive)
  self.grid={'width':8,'height':4,'west':-180,'north':90,'step':45};self.controls={'minimum_memory_kib':0};self.outer={'grid':self.grid,'policy_id':'p','policy_version':'1','controls':self.controls,'seed_controls':{'strip_rows':2},'inputs':inputs}
  op=self.d/'outer.json';op.write_text(json.dumps(self.outer));self.outer_pin=pin(op)
  self.resolution={'path':str(self.d/'resolution'),'sha256':'e'*64};self.cfg={'orchestration':{'outer_config_sha256':self.outer_pin['sha256'],'derived_manifest':{'path':str(self.manifest),'sha256':'f'*64}},'policy_id':'p','policy_version':'1','controls':self.controls,'inputs':{'resolution_report':self.resolution},'seed_code_files':{'rasterizer':inputs['seed_builder'],'rasterizer_kernel':inputs['seed_kernel']}}
  expected={dst:inputs[src] for dst,src in (('snapshot','decision_snapshot'),('physical_rows','physical_rows'),('physical_runs','physical_runs'),('physical_report','physical_report'),('component_rows','component_rows'),('component_runs','component_runs'),('component_manifest','component_manifest'),('closure_checker','closure_checker'),('terminal_checker','terminal_checker'),('closure_contract','closure_contract'),('seed_builder','seed_builder'),('seed_kernel','seed_kernel'),('panama_osm_archive','panama_osm_archive'))};expected['resolution']=self.resolution
  self.q=direct_seed.request(self.grid,expected,2);self.request.write_text(json.dumps(self.q));self.db={'request':pin(self.request),'panama_osm_archive':inputs['panama_osm_archive'],'outer_config':self.outer_pin};self.derived={'seed_request_sha256':self.db['request']['sha256']};self.paths={'seed_report':self.report};self.seed={'ok':True}
  self.pins={core:self.q['inputs'][seed]['sha256'] for seed,core in (('snapshot','decision_snapshot'),('resolution','resolution_report'),('physical_rows','physical_rows'),('physical_runs','physical_runs'),('physical_report','physical_report'),('component_rows','component_rows'),('component_runs','component_runs'),('component_manifest','component_manifest'))}
 def check(self):
  with mock.patch.object(direct_seed,'verify_result',return_value=(self.q,self.seed)),mock.patch.object(direct_seed,'verify_panama_source',return_value={'verified':True}),mock.patch.object(direct_seed,'verify_ural_source',return_value=None):return c.verify_direct_binding(self.db,self.derived,self.cfg,self.paths,self.pins,self.grid,self.seed,lambda:None)
 def test_exact_binding(self):self.assertEqual(self.check(),self.q)
 def update_outer(self):
  op=Path(self.outer_pin['path']);op.write_text(json.dumps(self.outer));self.outer_pin['sha256']=hashlib.sha256(op.read_bytes()).hexdigest();self.cfg['orchestration']['outer_config_sha256']=self.outer_pin['sha256']
 def test_reject_omitted_caucasus_binding(self):
  self.outer['caucasus_source']={'recipe':'r'};self.update_outer()
  with self.assertRaisesRegex(ValueError,'Caucasus outer/core'):self.check()
 def test_reject_injected_caucasus_binding(self):
  self.cfg['caucasus_binding']={'config':{'recipe':'r'}}
  with self.assertRaisesRegex(ValueError,'Caucasus outer/core'):self.check()
 def test_reject_changed_caucasus_binding(self):
  self.outer['caucasus_source']={'recipe':'r'};self.update_outer();self.cfg['caucasus_binding']={'config':{'recipe':'different'}}
  with self.assertRaisesRegex(ValueError,'Caucasus outer/core'):self.check()
 def test_accept_same_caucasus_binding(self):
  self.outer['caucasus_source']={'recipe':'r'};self.update_outer();self.cfg['caucasus_binding']={'config':{'recipe':'r'}}
  self.assertEqual(self.check(),self.q)
 def test_ural_config_bound_to_outer_request(self):
  config={k:'/ural/'+k for k in ('recipe_dir','inputs_dir','helpers_dir','work_parent')}
  config.update(inventories={k:{'file':'a'*64} for k in ('recipe_dir','inputs_dir','helpers_dir')},python={'path':'/python','sha256':'b'*64},dependency_dirs=[{'path':'/deps','sha256':'c'*64}])
  self.outer['ural_source']=config;self.update_outer()
  self.q=direct_seed.request(self.grid,self.q['inputs'],2,config);self.request.write_text(json.dumps(self.q))
  self.db['request']['sha256']=hashlib.sha256(self.request.read_bytes()).hexdigest();self.derived['seed_request_sha256']=self.db['request']['sha256']
  self.assertEqual(self.check(),self.q)
  self.q=copy.deepcopy(self.q);self.q['ural_source']['inventories']['inputs_dir']['file']='f'*64
  with self.assertRaisesRegex(ValueError,'outer request mismatch'):self.check()
 def test_reject_changed_contract(self):
  self.q=copy.deepcopy(self.q);self.q['inputs']['closure_contract']['sha256']='0'*64
  with self.assertRaisesRegex(ValueError,'outer request mismatch'):self.check()
 def test_reject_changed_current_snapshot(self):
  self.pins['decision_snapshot']='0'*64
  with self.assertRaisesRegex(ValueError,'core input mismatch'):self.check()
 def test_reject_changed_archive(self):
  self.db['panama_osm_archive']={'path':str(self.archive),'sha256':'0'*64}
  with self.assertRaisesRegex(ValueError,'input hash mismatch'):self.check()
 def test_reject_wrong_marker_request(self):
  self.derived['seed_request_sha256']='0'*64
  with self.assertRaisesRegex(ValueError,'request/marker mismatch'):self.check()
 def test_reject_outer_hash_substitution(self):
  self.cfg['orchestration']['outer_config_sha256']='0'*64
  with self.assertRaisesRegex(ValueError,'outer config mismatch'):self.check()
if __name__=='__main__':unittest.main()
