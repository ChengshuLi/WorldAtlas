"""The unreviewed fresh outer mode must fail before work or output."""
import copy,json,tempfile,unittest
from pathlib import Path
from unittest import mock
import orchestrate_stage2 as outer
import build_stage2 as core
class FreshOuterGating(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.d=Path(self.t.name);self.p=self.d/'config.json'
  self.cfg=json.loads(Path('qualified-stage2-outer-20261105/config.json').read_text());self.cfg.pop('hint_max_rss_kib');self.cfg.pop('seed_handoff');self.cfg['controls']['minimum_memory_kib']=0;self.cfg['seed_controls']={'strip_rows':2};self.cfg['inputs']['panama_osm_archive']={'path':'/not-read','sha256':'a'*64}
 def write(self):self.p.write_text(json.dumps(self.cfg))
 def test_v2_config_recognized_but_not_executable(self):
  self.write();_,cfg=outer.load_config(self.p);self.assertNotIn('seed_handoff',cfg)
  with self.assertRaisesRegex(ValueError,'awaits independent review'):outer.run(self.p,self.d/'work',self.d/'output')
  self.assertFalse((self.d/'work').exists());self.assertFalse((self.d/'output').exists())
 def test_caucasus_fails_closed_before_work_even_with_review_flag(self):
  self.cfg['caucasus_source']={'recipe':{},'hydro':{},'author':{},'code_sha256':{}};self.write()
  with mock.patch.object(outer,'FRESH_DIRECT_EXECUTION_ENABLED',True):
   with self.assertRaisesRegex(ValueError,'Caucasus direct gate wiring awaits independent review'):outer.run(self.p,self.d/'work',self.d/'output')
  self.assertFalse((self.d/'work').exists())
 def test_ural_and_caucasus_are_recognized_but_ural_cannot_run(self):
  self.cfg['caucasus_source']={'recipe':{},'hydro':{},'author':{},'code_sha256':{}}
  self.cfg['ural_source']={k:'/ural/'+k for k in ('recipe_dir','inputs_dir','helpers_dir','work_parent')}
  self.cfg['ural_source'].update(inventories={k:{'file':'a'*64} for k in ('recipe_dir','inputs_dir','helpers_dir')},python={'path':'/python','sha256':'b'*64},dependency_dirs=[{'path':'/deps','sha256':'c'*64}]);self.write()
  with mock.patch.object(outer,'FRESH_DIRECT_EXECUTION_ENABLED',True),mock.patch.object(outer,'CAUCASUS_DIRECT_GATE_ENABLED',True):
   with self.assertRaisesRegex(ValueError,'Ural direct gate wiring awaits independent review'):outer.run(self.p,self.d/'work',self.d/'output')
  self.assertFalse((self.d/'work').exists());self.assertFalse((self.d/'output').exists())
 def test_missing_runtime_dependency_fails_before_work(self):
  self.cfg['caucasus_source']={'recipe':{},'hydro':{},'author':{},'code_sha256':{}};self.write()
  with mock.patch.object(outer,'FRESH_DIRECT_EXECUTION_ENABLED',True),mock.patch.object(outer,'CAUCASUS_DIRECT_GATE_ENABLED',True),mock.patch('direct_seed.check_runtime',side_effect=ValueError('missing dependency')):
   with self.assertRaisesRegex(ValueError,'missing dependency'):outer.run(self.p,self.d/'work',self.d/'output')
  self.assertFalse((self.d/'work').exists());self.assertFalse((self.d/'output').exists())
 def test_v1_cannot_claim_v2_mode(self):
  binding={'request':{'path':'/p','sha256':'a'*64},'panama_osm_archive':{'path':'/x','sha256':'b'*64}}
  for handoff,direct,derived in [({'path':'/old'},binding,{'direct_seed_binding':binding}),(None,None,{}),(None,binding,{}),({'path':'/old'},None,{'direct_seed_binding':binding})]:
   with self.assertRaisesRegex(ValueError,'seed mode'):core.validate_seed_mode(handoff,direct,derived)
  core.validate_seed_mode(None,binding,{'direct_seed_binding':binding});core.validate_seed_mode({'path':'/old'},None,{})
if __name__=='__main__':unittest.main()
