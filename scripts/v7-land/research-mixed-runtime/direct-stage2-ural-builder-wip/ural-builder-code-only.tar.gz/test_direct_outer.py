import json,tempfile,unittest
from pathlib import Path
import orchestrate_stage2 as o
class Outer(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.p=Path(self.t.name)/'config.json';self.c=json.loads(Path('qualified-stage2-outer-20261105/config.json').read_text());self.c.pop('hint_max_rss_kib');self.c['controls']['minimum_memory_kib']=0
 def load(self):self.p.write_text(json.dumps(self.c));return o.load_config(self.p)
 def test_accepts_reused_seed_direct_and_no_guardian(self):
  _,a=self.load();self.assertEqual(a['controls']['minimum_memory_kib'],0);self.assertIn('seed_handoff',a)
  self.assertFalse(hasattr(o,'require_guardian'))
 def test_rejects_host_memory_floor(self):
  self.c['controls']['minimum_memory_kib']=1
  with self.assertRaises(ValueError):self.load()
 def test_rejects_legacy_hint_limit(self):
  self.c['hint_max_rss_kib']=1
  with self.assertRaises(ValueError):self.load()
 def test_rejects_fresh_seed_until_direct_seed_is_implemented(self):
  del self.c['seed_handoff']
  with self.assertRaises(ValueError):self.load()
if __name__=='__main__':unittest.main()
