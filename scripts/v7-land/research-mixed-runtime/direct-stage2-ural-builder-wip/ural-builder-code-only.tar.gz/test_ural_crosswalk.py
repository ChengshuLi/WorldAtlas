"""Synthetic crosswalk fixtures. Manifest parts pins are test-patched, not real data."""
import copy, hashlib, json, unittest
from unittest.mock import patch
import contracts as c
import test_contracts_qualified as fixtures
from export_adapter import boundary_records, selected_regions
from regions import assemble

class UralCrosswalk(unittest.TestCase):
 def setUp(self):
  fixtures.CrosswalkTests.setUp(self)
  s=self.snapshot;s['serialization']='worldatlas-canonical-json-v1'
  b=s['mainland_boundaries'][0];b['boundary_id']=c.URAL_BOUNDARY_ID
  s['land_baseline_policy']['boundary_ids']=[c.URAL_BOUNDARY_ID]
  s['seed_regions'][0]['segments'][0]['id']=c.URAL_BOUNDARY_ID
  s['seed_regions'][0]['witnesses']=[{'lon':0.,'lat':0.2,'inside':True}]
  self.seed['region_traces'][0]['input_trace'][0]['id']=c.URAL_BOUNDARY_ID
  p=b['provenance'];p['source_refs']=[];p['source_relationships']=[]
  self.real_parts=dict(c.URAL_MANIFEST_PARTS_SHA256);self.test_parts={}
  for i,(role,(sid,digest,tile)) in enumerate(c.URAL_CONSTRUCTION_INPUTS.items()):
   ref={'source_id':sid,'version':'1'};p['source_refs'].append(ref);p['source_relationships'].append({**ref,'relationship':role})
   key='uranium/tile'+str(i)+'/manifest.json' if tile else 'uranium/source'+str(i)
   src={**ref,'sha256':digest,'r2_bucket':'raw','r2_key':key,'size_bytes':100}
   prov={}
   if tile:
    parts=[{'key':key.removesuffix('manifest.json')+'part-aa','size':10,'sha256':'1'*64},{'key':key.removesuffix('manifest.json')+'part-ab','size':20,'sha256':'2'*64}]
    prov={'full_tile_sha256':tile,'full_tile_size_bytes':30,'parts':parts}
    self.test_parts[role]=hashlib.sha256(json.dumps(parts,sort_keys=True,separators=(',',':')).encode()).hexdigest()
   s['sources'].append(src);s['source_lineage_assets'].append({**src,'kind':'raw','provider':'provider','source_uri':'https://example.org','provenance':prov})
  self.addCleanup(patch.stopall)
  patch.dict(c.URAL_MANIFEST_PARTS_SHA256,self.test_parts).start()
  # Producer's corresponding test-only pins represent the same synthetic parts.
  patch.dict('export_adapter.URAL_MANIFEST_PARTS_SHA256',self.test_parts).start()
  self.produce()
 def check(self):
  return c.validate_selected_seed_decisions(self.snapshot,self.seed,self.groups,self.codes,self.metric)
 def produce(self):
  rev,_,boundaries,sources=boundary_records(self.snapshot)
  decisions,records=selected_regions(self.snapshot,rev,boundaries)
  pins=self.seed['input_sha256'];proof=copy.deepcopy(self.seed['region_traces'][0]['input_trace'][1]['closure_proof'])
  _,trace=assemble(rev,records,decisions[0],sources,lambda *args:copy.deepcopy(proof),physical_rows_sha256=pins['physical_rows'],physical_runs_sha256=pins['physical_runs'],physical_report_sha256=pins['physical_report'],checker_sha256=pins['closure_checker'],closure_contract_sha256=pins['closure_contract'],terminal_checker_sha256=pins['terminal_checker'],guard=lambda:None)
  self.seed['region_traces']=[trace]
 def test_producer_consumer_all_seven_and_manifest_shapes(self):
  self.assertTrue(self.check());cit=self.seed['region_traces'][0]['input_trace'][0]['source_citations']
  self.assertEqual(len(cit),7);self.assertTrue(all(x['role']=='construction_input' for x in cit))
  self.assertEqual(sum('full_tile_sha256' in x for x in cit),3)
 def test_every_role_pins_source_and_hash(self):
  for i,(role,(sid,digest,tile)) in enumerate(c.URAL_CONSTRUCTION_INPUTS.items(),1):
   with self.subTest(role=role):
    src=self.snapshot['sources'][i];asset=self.snapshot['source_lineage_assets'][i]
    src['sha256']=asset['sha256']='f'*64
    with self.assertRaisesRegex(ValueError,'source pin mismatch'):self.check()
    src['sha256']=asset['sha256']=digest
    old=src['source_id'];src['source_id']=asset['source_id']='forged';p=self.snapshot['mainland_boundaries'][0]['provenance'];p['source_refs'][i-1]['source_id']='forged';p['source_relationships'][i-1]['source_id']='forged'
    with self.assertRaisesRegex(ValueError,'source pin mismatch'):self.check()
    src['source_id']=asset['source_id']=old;p['source_refs'][i-1]['source_id']=old;p['source_relationships'][i-1]['source_id']=old
 def test_roles_rejected_for_other_boundary(self):
  self.snapshot['mainland_boundaries'][0]['boundary_id']='other';self.snapshot['land_baseline_policy']['boundary_ids']=['other'];self.snapshot['seed_regions'][0]['segments'][0]['id']='other';self.seed['region_traces'][0]['input_trace'][0]['id']='other'
  with self.assertRaisesRegex(ValueError,'unsupported boundary source relationship'):self.check()
 def test_manifest_tampers_fail(self):
  for i,(role,(_,_,tile)) in enumerate(c.URAL_CONSTRUCTION_INPUTS.items(),1):
   if not tile:continue
   with self.subTest(role=role):
    p=self.snapshot['source_lineage_assets'][i]['provenance'];saved=copy.deepcopy(p)
    for mutate in (lambda x:x.update(full_tile_sha256='f'*64),lambda x:x['parts'].reverse(),lambda x:x['parts'][0].update(sha256='f'*64),lambda x:x.update(full_tile_size_bytes=31),lambda x:x['parts'][0].update(key='bad')):
     mutate(p)
     with self.assertRaisesRegex(ValueError,'Ural tile manifest'):self.check()
     p.clear();p.update(copy.deepcopy(saved))
    cit=self.seed['region_traces'][0]['input_trace'][0]['source_citations'][i-1];cit['full_tile_sha256']='f'*64
    with self.assertRaisesRegex(ValueError,'boundary citations mismatch'):self.check()
    cit['full_tile_sha256']=tile
    cit['representation']='provider_original'
    with self.assertRaisesRegex(ValueError,'boundary citations mismatch'):self.check()
    cit['representation']='manifest_of_raw_parts'
 def test_each_missing_ural_role_is_rejected(self):
  b=self.snapshot['mainland_boundaries'][0]['provenance'];cit=self.seed['region_traces'][0]['input_trace'][0]['source_citations']
  for i in range(len(c.URAL_CONSTRUCTION_INPUTS)):
   with self.subTest(index=i):
    ref=b['source_refs'].pop(i);rel=b['source_relationships'].pop(i);citation=cit.pop(i)
    with self.assertRaisesRegex(ValueError,'incomplete or duplicate Ural construction roles'):self.check()
    b['source_refs'].insert(i,ref);b['source_relationships'].insert(i,rel);cit.insert(i,citation)
 def test_single_remaining_role_is_rejected(self):
  b=self.snapshot['mainland_boundaries'][0]['provenance'];cit=self.seed['region_traces'][0]['input_trace'][0]['source_citations']
  del b['source_refs'][1:];del b['source_relationships'][1:];del cit[1:]
  with self.assertRaisesRegex(ValueError,'incomplete or duplicate Ural construction roles'):self.check()
 def test_supporting_source_can_accompany_all_ural_roles(self):
  b=self.snapshot['mainland_boundaries'][0]['provenance'];cit=self.seed['region_traces'][0]['input_trace'][0]['source_citations'];rel='local_geographic_comparison_not_terrain_or_construction_proof'
  b['source_refs'].append({'source_id':'s','version':'1'});b['source_relationships'].append({'source_id':'s','version':'1','relationship':rel})
  cit.append({'source_id':'s','version':'1','relationship':rel,'role':'supporting_research_evidence','sha256':'a'*64,'bucket':'raw','key':'s'})
  self.assertTrue(self.check())
 def test_duplicate_role_with_second_source_version_is_rejected(self):
  b=self.snapshot['mainland_boundaries'][0]['provenance'];cit=self.seed['region_traces'][0]['input_trace'][0]['source_citations']
  src=copy.deepcopy(self.snapshot['sources'][1]);asset=copy.deepcopy(self.snapshot['source_lineage_assets'][1]);src['version']=asset['version']='2'
  self.snapshot['sources'].append(src);self.snapshot['source_lineage_assets'].append(asset)
  ref=copy.deepcopy(b['source_refs'][0]);rel=copy.deepcopy(b['source_relationships'][0]);citation=copy.deepcopy(cit[0]);ref['version']=rel['version']=citation['version']='2'
  b['source_refs'].append(ref);b['source_relationships'].append(rel);cit.append(citation)
  with self.assertRaisesRegex(ValueError,'incomplete or duplicate Ural construction roles'):self.check()
 def test_production_part_pins_reject_synthetic_manifests(self):
  with patch.dict(c.URAL_MANIFEST_PARTS_SHA256,self.real_parts):
   with self.assertRaisesRegex(ValueError,'parts pin mismatch'):self.check()
 def test_role_mislabel_and_unknown_rejected(self):
  cit=self.seed['region_traces'][0]['input_trace'][0]['source_citations'][0];cit['role']='supporting_research_evidence'
  with self.assertRaisesRegex(ValueError,'boundary citations mismatch'):self.check()
  cit['role']='construction_input';self.snapshot['mainland_boundaries'][0]['provenance']['source_relationships'][0]['relationship']='unknown'
  with self.assertRaisesRegex(ValueError,'unsupported boundary source relationship'):self.check()

if __name__=='__main__':unittest.main()
