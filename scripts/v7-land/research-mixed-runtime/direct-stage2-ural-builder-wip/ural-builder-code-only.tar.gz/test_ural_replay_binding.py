import json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
import direct_seed as d

class ReplayBinding(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);self.output=self.root/'output';self.output.mkdir();self.request=self.root/'request.json';self.raw=b'{}';self.request.write_bytes(self.raw)
  self.q={'ural_source':{'sample':True},'inputs':{}};self.trace={'schema':'ural-source-replay-trace-v1','status':'verified'};self.report={'ural_source_trace':self.trace}
 def execute(self,stdout=None,rc=0):
  result=SimpleNamespace(returncode=rc,stdout=json.dumps(self.trace) if stdout is None else stdout,stderr='replay failed')
  with mock.patch.object(d,'load_request',return_value=(self.raw,self.q)),mock.patch.object(d,'verify_result',return_value=(self.q,self.report)),mock.patch.object(d,'code_check'),mock.patch.object(d,'inputs_check'),mock.patch.object(d,'require_disjoint_ural'),mock.patch.object(d.subprocess,'run',return_value=result) as run:
   value=d.verify_ural_source(self.request,self.output)
   return value,run.call_args
 def test_isolated_replay_and_whole_trace(self):
  value,call=self.execute();self.assertEqual(value,self.trace);self.assertEqual(call.args[0][1:4],['-I','-S','-B']);self.assertIn('verify_trace',call.args[0][5]);self.assertIn('check()',call.args[0][5])
 def test_reject_altered_trace_and_failed_subprocess(self):
  with self.assertRaisesRegex(ValueError,'trace mismatch'):self.execute(stdout='{}')
  with self.assertRaisesRegex(ValueError,'replay rejected'):self.execute(rc=1)
 def test_selected_boundary_cannot_omit_replay(self):
  snapshot=self.root/'snapshot.json';snapshot.write_text(json.dumps({'mainland_boundaries':[{'boundary_id':'ural_kara_coast_to_caspian'}]}))
  self.q.pop('ural_source');self.q['inputs']['snapshot']={'path':str(snapshot),'sha256':'a'*64};self.report['ural_source_trace']=None
  with self.assertRaisesRegex(ValueError,'selected Ural boundary requires source replay'):self.execute()
 def test_unselected_boundary_allows_no_replay(self):
  snapshot=self.root/'snapshot.json';snapshot.write_text(json.dumps({'mainland_boundaries':[{'boundary_id':'other'}]}))
  self.q.pop('ural_source');self.q['inputs']['snapshot']={'path':str(snapshot),'sha256':'a'*64};self.report['ural_source_trace']=None
  value,call=self.execute();self.assertIsNone(value);self.assertIsNone(call)
 def test_reject_trace_without_requested_gate(self):
  self.q.pop('ural_source')
  with self.assertRaisesRegex(ValueError,'unexpected Ural trace'):self.execute()
if __name__=='__main__':unittest.main()

class RealIsolatedReplayBootstrap(unittest.TestCase):
 def test_child_runs_isolated_and_compares_entire_trace(self):
  import hashlib,os
  from unittest.mock import patch
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);producer=root/'seed-producer-direct';producer.mkdir();output=root/'output';output.mkdir();request=root/'request';marker=root/'startup';hostile=root/'hostile';hostile.mkdir()
   (hostile/'sitecustomize.py').write_text('open('+repr(str(marker))+',"w").write("bad")')
   sources={
    'closure_client.py':'def sha(path,guard): return "digest"\n',
    'export_adapter.py':'def load_pinned_snapshot(path,digest,guard): return {}\ndef boundary_records(snapshot): return ("r","e",{}, {})\n',
    'ural_producer_config.py':'def validate_ural_relationship_scope(x): pass\ndef prepare(config,snapshot,protected,sha,guard):\n assert config == {"fixture": True}\n return {}, lambda: None\n',
    'ural_seed_source.py':'import sys\ndef verify_trace(boundaries,catalog,pin,expected):\n assert sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode\n assert expected == {"status":"verified"}\n return expected\n'}
   freeze={}
   for name,body in sources.items():
    p=producer/name;p.write_text(body);freeze[name]=hashlib.sha256(p.read_bytes()).hexdigest()
   trace={'status':'verified'};q={'ural_source':{'fixture':True},'inputs':{'snapshot':{'path':'/fixture','sha256':'a'*64}}};raw=json.dumps(q).encode();request.write_bytes(raw);report={'ural_source_trace':trace};(output/'report.json').write_text(json.dumps(report))
   with patch.object(d,'HERE',root),patch.object(d,'DIRECT_SEED_FREEZE',freeze),patch.object(d,'load_request',return_value=(raw,q)),patch.object(d,'verify_result',return_value=(q,report)),patch.object(d,'code_check'),patch.object(d,'inputs_check'),patch.object(d,'require_disjoint_ural'),patch.dict(os.environ,{'PYTHONPATH':str(hostile),'PYTHONHOME':str(hostile)}):
    self.assertEqual(d.verify_ural_source(request,output),trace)
   self.assertFalse(marker.exists())

class CaptureLocation(unittest.TestCase):
 def test_ignores_default_temp_root_inside_ural_work_parent(self):
  from unittest.mock import patch
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);builder=root/'builder';builder.mkdir();output=builder/'output';output.mkdir();request=builder/'request.json';request.write_bytes(b'{}')
   config={k:str(root/k) for k in ('recipe_dir','inputs_dir','helpers_dir','work_parent')}
   for p in config.values():Path(p).mkdir()
   dep=root/'deps';dep.mkdir();python=root/'python';python.write_text('python')
   config.update(inventories={k:{'fixture':'a'*64} for k in ('recipe_dir','inputs_dir','helpers_dir')},python={'path':str(python),'sha256':'a'*64},dependency_dirs=[{'path':str(dep),'sha256':'b'*64}])
   trace={'status':'verified'};q={'ural_source':config,'inputs':{}};report={'ural_source_trace':trace};raw=b'{}';seen=[]
   def run(cmd,**kwargs):
    seen.append(Path(kwargs['cwd']));self.assertEqual(seen[-1].parent,builder)
    return SimpleNamespace(returncode=0,stdout=json.dumps(trace),stderr='')
   with patch.object(d,'load_request',return_value=(raw,q)),patch.object(d,'verify_result',return_value=(q,report)),patch.object(d,'code_check'),patch.object(d,'inputs_check'),patch.object(d.subprocess,'run',side_effect=run),patch.object(tempfile,'tempdir',config['work_parent']):
    self.assertEqual(d.verify_ural_source(request,output),trace)
   self.assertEqual(len(seen),1)
 def test_overlapping_capture_parent_rejected_before_subprocess(self):
  from unittest.mock import patch
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);output=root/'output';output.mkdir();request=root/'request';request.write_bytes(b'{}')
   config={k:str(root/k) for k in ('recipe_dir','inputs_dir','helpers_dir','work_parent')}
   for p in config.values():Path(p).mkdir()
   dep=root/'deps';dep.mkdir();python=root/'python';python.write_text('python')
   config.update(inventories={k:{'fixture':'a'*64} for k in ('recipe_dir','inputs_dir','helpers_dir')},python={'path':str(python),'sha256':'a'*64},dependency_dirs=[{'path':str(dep),'sha256':'b'*64}])
   q={'ural_source':config,'inputs':{}};report={'ural_source_trace':{'status':'verified'}}
   with patch.object(d,'load_request',return_value=(b'{}',q)),patch.object(d,'verify_result',return_value=(q,report)),patch.object(d,'code_check'),patch.object(d,'inputs_check'),patch.object(d.subprocess,'run') as run:
    with self.assertRaisesRegex(ValueError,'overlaps Ural'):d.verify_ural_source(request,output)
    run.assert_not_called()

class RealCaptureContract(unittest.TestCase):
 def test_real_producer_preparation_accepts_output_adjacent_capture(self):
  import hashlib,sys
  from ural_producer_config import prepare
  from ural_seed_source import dependency_tree_sha256
  def sha(path,guard):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);builder=root/'builder';builder.mkdir();work=root/'ural-work';work.mkdir()
   config={'work_parent':str(work),'inventories':{}}
   for k in ('recipe_dir','inputs_dir','helpers_dir'):
    directory=root/k;directory.mkdir();f=directory/'fixture';f.write_text(k);config[k]=str(directory);config['inventories'][k]={'fixture':sha(f,None)}
   dep=root/'deps';dep.mkdir();executable=Path(sys.executable).resolve()
   config['python']={'path':str(executable),'sha256':sha(executable,None)}
   config['dependency_dirs']=[{'path':str(dep),'sha256':dependency_tree_sha256(dep)}]
   snapshot=builder/'snapshot';snapshot.write_text('{}');pin={'path':str(snapshot),'sha256':sha(snapshot,None)}
   # A default temp root equal to the replay workspace used to make this fail.
   with mock.patch.object(tempfile,'tempdir',str(work)),tempfile.TemporaryDirectory(prefix='.capture-',dir=builder) as capture:
    value,check=prepare(config,pin,[builder/'seed-work',builder/'output',Path(capture)],sha,lambda:None)
    check();self.assertEqual(value['work_parent'],str(work))
