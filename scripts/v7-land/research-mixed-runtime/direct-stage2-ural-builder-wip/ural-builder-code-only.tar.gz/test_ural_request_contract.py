from pathlib import Path
import copy, unittest
import direct_seed

class UralRequestContract(unittest.TestCase):
 def setUp(self):
  self.inputs={k:{'path':'/p/'+k,'sha256':'a'*64} for k in ('snapshot','resolution','physical_rows','physical_runs','physical_report','component_rows','component_runs','component_manifest','closure_checker','terminal_checker','closure_contract','seed_builder','seed_kernel')}
  self.grid={'width':8,'height':4,'west':-180,'north':90,'step':45}
  self.config={k:'/ural/'+k for k in ('recipe_dir','inputs_dir','helpers_dir','work_parent')}
  self.config.update(inventories={k:{'file':'a'*64} for k in ('recipe_dir','inputs_dir','helpers_dir')},python={'path':'/python','sha256':'b'*64},dependency_dirs=[{'path':'/deps','sha256':'c'*64}])
 def test_request_roundtrip(self):
  q=direct_seed.request(self.grid,self.inputs,4,self.config)
  self.assertEqual(q['ural_source'],self.config)
 def test_relative_paths_rejected(self):
  for key in ('recipe_dir','inputs_dir','helpers_dir','work_parent'):
   c=copy.deepcopy(self.config);c[key]='relative'
   with self.subTest(key=key),self.assertRaises(ValueError):direct_seed.request(self.grid,self.inputs,4,c)
  for key in ('python','dependency_dirs'):
   c=copy.deepcopy(self.config);(c[key] if key=='python' else c[key][0])['path']='relative'
   with self.subTest(key=key),self.assertRaises(ValueError):direct_seed.request(self.grid,self.inputs,4,c)
 def test_ural_source_paths_disjoint_from_outer_work(self):
  import tempfile
  from pathlib import Path
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);c=copy.deepcopy(self.config)
   for name in ('recipe_dir','inputs_dir','helpers_dir','work_parent'):
    path=root/name;path.mkdir();c[name]=str(path)
   dep=root/'deps';dep.mkdir();c['dependency_dirs'][0]['path']=str(dep)
   python=root/'python';python.write_bytes(b'python');c['python']['path']=str(python)
   direct_seed.require_disjoint_ural(c,root/'work',root/'out')
   with self.assertRaisesRegex(ValueError,'overlaps Ural'):
    direct_seed.require_disjoint_ural(c,root/'work',root/'out',[dep/'lock'])
   for path in (Path(c['recipe_dir'])/'work',Path(c['work_parent'])/'work',dep/'work',root):
    with self.subTest(path=path),self.assertRaisesRegex(ValueError,'overlaps Ural'):
     direct_seed.require_disjoint_ural(c,path,root/'out')
 def test_malformed_inventory_and_dependency_rejected(self):
  for name in ('../escape','/absolute','a//b','a/./b',''):
   c=copy.deepcopy(self.config);c['inventories']['inputs_dir']={name:'a'*64}
   with self.subTest(name=name),self.assertRaises(ValueError):direct_seed.request(self.grid,self.inputs,4,c)
  c=copy.deepcopy(self.config);c['dependency_dirs']=[]
  with self.assertRaises(ValueError):direct_seed.request(self.grid,self.inputs,4,c)
  c=copy.deepcopy(self.config);c['inventories']['inputs_dir']['file']='g'*64
  with self.assertRaises(ValueError):direct_seed.request(self.grid,self.inputs,4,c)
if __name__=='__main__':unittest.main()

class PrelockUral(unittest.TestCase):
 def test_inconsistent_request_rejected_before_any_disjoint_check(self):
  from unittest.mock import patch
  import build_stage2 as core
  with patch.object(direct_seed,'require_disjoint_ural') as protect:
   with self.assertRaisesRegex(ValueError,'pre-lock mismatch'):
    core.prelock_ural_disjoint({}, {'ural_source':{'wrong':'request'}},Path('/work'),Path('/out'))
   protect.assert_not_called()
 def test_matching_config_protects_core_lock(self):
  from unittest.mock import patch
  import build_stage2 as core
  c={'fixture':True}
  with patch.object(direct_seed,'require_disjoint_ural') as protect:
   core.prelock_ural_disjoint({'ural_source':c},{'ural_source':c},Path('/work'),Path('/out'))
   self.assertEqual(protect.call_args.args[3],[Path('/work.lock')])
