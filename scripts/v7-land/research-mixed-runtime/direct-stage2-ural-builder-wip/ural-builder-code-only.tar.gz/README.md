# Combined direct stage-2 integration: work in progress

Current status: see `handoff/STATUS.md` for the latest candidate and its limits.
`v2-runtime-freeze.sha256` is a historical 14-file baseline, not the current
Ural candidate. `ural-runtime-freeze-candidate.sha256` lists the current 17
pins enforced by `runtime/direct_seed.py`; it is unreviewed as an executable
freeze. The paragraphs below and `INTEGRATION-STATUS.md` describe historical
stages, not the current code.

Historical status: see `INTEGRATION-STATUS.md` for earlier bounded tests and
local wiring. This README describes the earlier reuse-only merge below; in the
current scratch code, fresh direct and Caucasus calls have been wired behind
disabled execution gates, not validated as a complete outer pipeline.

This is a non-published research merge, not an executable freeze or a full direct pipeline. It combines the previously reviewed reuse-only direct runtime with Caucasus core binding scaffolding from PR4 commit 24d4b51. The 69 bounded reuse-only tests passed. The merge deliberately rejects fresh-seed configurations and does not yet use the Caucasus gate; no full orchestrator or map was run.

Two explicit integration gates remain. The PR4 fcc73ff direct seed producer retains old executable allowlist hashes, so it rejects the newer v2 rasterizer and closure checkers. Updating that freeze requires independent code and test review. Also, the core currently requires selected historical route-provenance checker and contract hashes to equal the current proof's hashes. A new v2 closure proof needs an explicit separate binding which preserves historical provenance and checks the fresh proof against the exact current physical, geometry, checker, contract and terminal inputs. Do not weaken or bypass the existing validation.

The historical seed handoff remains required in this work-in-progress path. The runtime does not launch a supervisor or impose a total-process memory cap; external limits are not assessed. Core checkpoint identity and no-overwrite output are retained. Early crashes before the derived manifest need a new work path. In-process native-library failures can terminate the process. The separately verified historical seed's monitor is provenance, not an active supervisor.

The Panama selected-closure screen uses the same physical rows, runs and report hashes as the earlier qualified research stage-2 input. The report is candidate-only and does not authenticate the original producer code. The screen is not a final production-input proof. Preserve the prior checkpoint and output, and do not run a map.

Additional bounded tests exercise an unconnected v2 request constructor and fresh-proof validation. Those helpers do not enable a fresh run. The proposed fresh call must bind its exact direct producer, seed request, Panama archive, Caucasus source gate and checkpoint identity; it must not reuse historical handoff code hashes as if they described the new producer. The current 103-test combined log covers bounded fixtures only, not the real direct outer execution.
The copied v1 seed freeze is retained as source-freeze-v1-stale.txt and must not be used for this candidate. The separately reviewed v2 14-file map is v2-runtime-freeze.sha256; the unconnected invocation helper enforces those exact hashes.

The local `invoke_direct_seed` helper is deliberately not called by `run()`. It enforces the 14-file direct freeze and checks the exact request, inputs, producer report and outputs before and after the process. Bounded real-OSM fixtures exercise both water and terminal checkers on a synthetic grid. A separate synthetic fake-process test checks rejection of request, input, report and output tampering. These checks assume a trusted workspace and are not cryptographic proof of execution or a full pipeline run.
